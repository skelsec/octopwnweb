
# this class is not implemented, as currently the project uses SMB's own socks5 proxy implementation.
# if we decide to separate the DCERPC module as a separate project, we'd need to implement this!

class DCERPCSocks5Transport:
    pass