
__version__ = "0.3.9"
__banner__ = \
"""
# aiosmb %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__