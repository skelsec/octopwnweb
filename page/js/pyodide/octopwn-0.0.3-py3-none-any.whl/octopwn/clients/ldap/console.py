import asyncio
import traceback
import logging
import typing
import datetime
import copy

from octopwn.clients.base import ClientConsoleBase

from msldap.connection import MSLDAPClientConnection
from msldap.ldap_objects.common import MSLDAP_UAC
from msldap.external.asciitree.asciitree import LeftAligned
from msldap.client import MSLDAPClient
from msldap.ldap_objects import MSADUser_TSV_ATTRS
from msldap.ldap_objects.adcertificatetemplate import MSADCertificateTemplate, EX_RIGHT_CERTIFICATE_ENROLLMENT, CertificateNameFlag
from msldap.wintypes.asn1.sdflagsrequest import SDFlagsRequest
from msldap.protocol.constants import BASE, ALL_ATTRIBUTES, LEVEL
from msldap.protocol.query import escape_filter_chars

from winacl.dtyp.security_descriptor import SECURITY_DESCRIPTOR
from winacl.dtyp.ace import ACCESS_ALLOWED_OBJECT_ACE, ADS_ACCESS_MASK, AceFlags, ACE_OBJECT_PRESENCE
from winacl.dtyp.sid import SID
from winacl.dtyp.guid import GUID


class LDAPClient(ClientConsoleBase):
	def __init__(self, client_id, connection:MSLDAPClientConnection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.adinfo = None
		self.ldapinfo = None
		self.domain_name = None
		self.client:MSLDAPClient = None
		self.nologon_commands.append('login')
	
	async def start(self):
		try:
			return True, None
		except Exception as err:
			return False, err
	
	async def do_login(self, to_print=True):
		"""Connect + login"""
		try:
			self.connection = copy.deepcopy(self.original_connection)
			_, err = await self.connection.connect()
			if err is not None:
				raise err
			_, err = await self.connection.bind()
			if err is not None:
				raise err

			self.client = MSLDAPClient(None, None, connection = self.connection, keepalive = True)
			_, err = await self.client.connect()
			if err is not None:
				raise err

			await self.do_adinfo(show=False)
			
			self.logon_ok = True
			if to_print is True or to_print == '':
				await self.print('Login OK!')
			return True, None
		except Exception as e:
			if to_print is True or to_print == '':
				await self.print_exc(e)
			return None, e

	#### browser gui helper
	async def listDirectory(self, path):
		try:
			#self.adinfo.distinguishedName
			results = {}
			entries = await self.client.get_tree_plot(path, level=1)
			for dn in list(entries[path].keys()):
				ldap_filter = r'(distinguishedName=%s)' % escape_filter_chars(dn)
				async for entry, err in self.client.pagedsearch(ldap_filter, ALL_ATTRIBUTES):
					if err is not None:
						results[dn] = None
						continue
					results[dn] = entry
			results['keys'] = list(results.keys()) #stupid javascript...
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	

	#### help over!
	async def do_logout(self):
		try:
			self.logon_ok = False
			if self.client is not None:
				await self.client.disconnect()					
			return True, None
		except Exception as err:
			return False, err

	
	async def do_ldapinfo(self, show = True):
		"""Prints detailed LDAP connection info (DSA)"""
		try:
			if self.ldapinfo is None:
				self.ldapinfo = self.client.get_server_info()
			if show is True:
				for k in self.ldapinfo:
					await self.print('%s : %s' % (k, self.ldapinfo[k]))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_adinfo(self, show = True):
		"""Prints detailed Active Driectory info"""
		try:
			if self.adinfo is None:
				self.adinfo = self.client._ldapinfo
				self.domain_name = self.adinfo.distinguishedName.replace('DC','').replace('=','').replace(',','.')
			if show is True:
				await self.print(self.adinfo)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_spns(self):
		"""Fetches kerberoastable user accounts"""
		try:
			await self.do_ldapinfo(False)
			async for user, err in self.client.get_all_service_users():
				if err is not None:
					raise err
				await self.print(user.sAMAccountName)
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_asrep(self):
		"""Fetches ASREP-roastable user accounts"""
		try:
			await self.do_ldapinfo(False)
			async for user, err in self.client.get_all_knoreq_users():
				if err is not None:
					raise err
				await self.print(user.sAMAccountName)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_computeraddr(self):
		"""Fetches all computer accounts"""
		try:
			await self.do_adinfo(False)
		
			async for machine, err in self.client.get_all_machines(attrs=['sAMAccountName', 'dNSHostName']):
				if err is not None:
					raise err
					
				dns = machine.dNSHostName
				if dns is None:
					dns = '%s.%s' % (machine.sAMAccountName[:-1], self.domain_name)

				await self.print(str(dns))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_targetenum(self):
		"""Grabs all computers in the domain and puts them in the targets window"""
		try:
			await self.do_adinfo(False)

			ctr = 0
			async for machine, err in self.client.get_all_machines():
				if err is not None:
					raise err
				
				ctr += 1
				dns = machine.dNSHostName
				if dns is None:
					dns = '%s.%s' % (machine.sAMAccountName[:-1], self.domain_name)

				tid, target, _ = await self.octopwnobj.do_addtarget(
					None, 
					hostname=dns,
					dcip = self.connection.target.host, 
					to_print=False
				)
				await self.octopwnobj.do_settarget(tid, 'description', machine.description, to_print = False, to_refresh = False)
				await self.octopwnobj.do_settarget(tid, 'isdc', MSLDAP_UAC.SERVER_TRUST_ACCOUNT in machine.userAccountControl, to_print = False, to_refresh = False)
			
			await self.octopwnobj.do_refreshtargets()
			await self.print('Added %s machines to targets' % ctr)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_dump(self):
		"""Fetches ALL user and machine accounts from the domain with a LOT of attributes"""
		try:
			await self.do_adinfo(False)
			await self.do_ldapinfo(False)
			
			users_filename = 'users_%s.tsv' % datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
			await self.print('Writing users to file %s' % users_filename)
			with open(users_filename, 'w', newline='', encoding = 'utf8') as f:
				async for user, err in self.client.get_all_users():
					if err is not None:
						raise err
					f.write('\t'.join(user.get_row(MSADUser_TSV_ATTRS)))
			await self.print('Users dump was written to %s' % users_filename)
			
			users_filename = 'computers_%s.tsv' % datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
			await self.print('Writing computers to file %s' % users_filename)
			with open(users_filename, 'w', newline='', encoding = 'utf8') as f:
				async for user, err in self.client.get_all_machines():
					if err is not None:
						raise err
					f.write('\t'.join(user.get_row(MSADUser_TSV_ATTRS)))
			await self.print('Computer dump was written to %s' % users_filename)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_query(self, query, attributes = None):
		"""Performs a raw LDAP query against the server.
Secondary parameter is the requested attributes SEPARATED WITH COMMA (,)"""
		try:
			await self.do_ldapinfo(False)
			if attributes is None:
				attributes = '*'
			if attributes.find(','):
				attributes = attributes.split(',')
			logging.debug('Query: %s' % (query))
			logging.debug('Attributes: %s' % (attributes))
			async for entry, err in self.client.pagedsearch(query, attributes):
				if err is not None:
					raise err
				await self.print(entry)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_tree(self, dn = None, level = 1):
		"""Prints a tree from the given DN (if not set, the top) and with a given depth (default: 1)"""
		try:
			await self.do_ldapinfo(False)
			if level is None:
				level = 1
			level = int(level)
			if dn is not None:
				try:
					int(dn)
				except Exception as e:
					pass
				else:
					level = int(dn)
					dn = None
					
			if dn is None:
				await self.do_ldapinfo(False)
				dn = self.client._tree
			logging.debug('Tree on %s' % dn)
			tree_data = await self.client.get_tree_plot(dn, level)
			tr = LeftAligned()
			await self.print(tr(tree_data))

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_user(self, samaccountname):
		"""Feteches a user object based on the sAMAccountName of the user"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			user, err = await self.client.get_user(samaccountname)
			if err is not None:
				raise err
			if user is None:
				await self.print('User not found!')
			else:
				await self.print(user)
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_machine(self, samaccountname):
		"""Feteches a machine object based on the sAMAccountName of the machine"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			machine, err = await self.client.get_machine(samaccountname)
			if err is not None:
				raise err
			if machine is None:
				await self.print('machine not found!')
			else:
				await self.print(machine)
				####TEST
				x = SECURITY_DESCRIPTOR.from_bytes(machine.allowedtoactonbehalfofotheridentity)
				await self.print(x)
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_schemaentry(self, cn):
		"""Feteches a schema object entry object based on the DN of the object (must start with CN=)"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			schemaentry, err = await self.client.get_schemaentry(cn)
			if err is not None:
				raise err
			
			await self.print(str(schemaentry))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_allschemaentry(self):
		"""Feteches all schema object entry objects"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			async for schemaentry, err in self.client.get_all_schemaentry():
				if err is not None:
					raise err
				
				await self.print(str(schemaentry))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_changeowner(self, new_owner_sid, target_dn, target_attribute = None):
		"""Changes the owner in a Security Descriptor to the new_owner_sid on an LDAP object or on an LDAP object's attribute identified by target_dn and target_attribute. target_attribute can be omitted to change the target_dn's SD's owner"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)

			_, err = await self.client.change_priv_owner(new_owner_sid, target_dn, target_attribute = target_attribute)
			if err is not None:
				raise err
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_addprivdcsync(self, user_dn, forest = None):
		"""Adds DCSync rights to the given user by modifying the forest's Security Descriptor to add GetChanges and GetChangesAll ACE"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)

			_, err = await self.client.add_priv_dcsync(user_dn, self.adinfo.distinguishedName)
			if err is not None:
				raise err

			await self.print('Change OK!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_addprivaddmember(self, user_dn, group_dn):
		"""Adds AddMember rights to the user on the group specified by group_dn"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)

			_, err = await self.client.add_priv_addmember(user_dn, group_dn)
			if err is not None:
				raise err

			await self.print('Change OK!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_setsd(self, target_dn, sddl):
		"""Updates the security descriptor of an object"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
	
			try:
				new_sd = SECURITY_DESCRIPTOR.from_sddl(sddl)
			except Exception as e:
				await self.print('Incorrect SDDL input!')
				return False, e, Exception('Incorrect SDDL input!')
	
			_, err = await self.client.set_objectacl_by_dn(target_dn, new_sd.to_bytes())
			if err is not None:
				raise err
			await self.print('Change OK!')
			return True, None
		except Exception as e:
			await self.print('Erro while updating security descriptor!')
			await self.print_exc(e)
			return False, e
			
	async def do_getsd(self, dn):
		"""Feteches security info for a given DN"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			sec_info, err = await self.client.get_objectacl_by_dn(dn)
			if err is not None:
				raise err
			sd = SECURITY_DESCRIPTOR.from_bytes(sec_info)
			await self.print(sd.to_sddl())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_gpos(self):
		"""Feteches security info for a given DN"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			async for gpo, err in self.client.get_all_gpos():
				if err is not None:
					raise err
				await self.print(gpo)
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_laps(self):
		"""Feteches all laps passwords"""
		try:
			async for entry, err in self.client.get_all_laps():
				if err is not None:
					raise err
				pwd = '<MISSING>'
				if 'ms-Mcs-AdmPwd' in entry['attributes']:
					pwd = entry['attributes']['ms-Mcs-AdmPwd']
				await self.print('%s : %s' % (entry['attributes']['cn'], pwd))
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_groupmembership(self, dn):
		"""Feteches names all groupnames the user is a member of for a given DN"""
		try:
			await self.do_ldapinfo(False)
			await self.do_adinfo(False)
			group_sids = []
			async for group_sid, err in self.client.get_tokengroups(dn):
				if err is not None:
					raise err
				group_sids.append(group_sids)
				group_dn, err = await self.client.get_dn_for_objectsid(group_sid)
				if err is not None:
					raise err
				await self.print('%s - %s' % (group_dn, group_sid))
				
			if len(group_sids) == 0:
				await self.print('No memberships found')
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_bindtree(self, newtree):
		"""Changes the LDAP TREE for future queries. 
				 MUST be DN format eg. 'DC=test,DC=corp'
				 !DANGER! Switching tree to a tree outside of the domain will trigger a connection to that domain, leaking credentials!"""
		self.client._tree = newtree
	
	async def do_trusts(self):
		"""Feteches gives back domain trusts"""
		try:
			async for entry, err in self.client.get_all_trusts():
				if err is not None:
					raise err
				await self.print(entry.get_line())
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_adduser(self, user_dn, password):
		"""Creates a new domain user with password"""
		try:
			_, err = await self.client.create_user_dn(user_dn, password)
			if err is not None:
				raise err
			await self.print('User added')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	
	async def do_deluser(self, user_dn):
		"""Deletes the user! This action is irrecoverable (actually domain admins can do that but probably will shout with you)"""
		try:
			_, err = await self.client.delete_user(user_dn)
			if err is not None:
				raise err
			await self.print('Goodbye, Caroline.')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_changeuserpw(self, user_dn, newpass, oldpass = None):
		"""Changes user password, if you are admin then old pw doesnt need to be supplied"""
		try:
			_, err = await self.client.change_password(user_dn, newpass, oldpass)
			if err is not None:
				raise err
			await self.print('User password changed')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_unlockuser(self, user_dn):
		"""Unlock user by setting lockoutTime to 0"""
		try:
			_, err = await self.client.unlock_user(user_dn)
			if err is not None:
				raise err
			await self.print('User unlocked')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_enableuser(self, user_dn):
		"""Unlock user by flipping useraccountcontrol bits"""
		try:
			_, err = await self.client.enable_user(user_dn)
			if err is not None:
				raise err
			await self.print('User enabled')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_disableuser(self, user_dn):
		"""Unlock user by flipping useraccountcontrol bits"""
		try:
			_, err = await self.client.disable_user(user_dn)
			if err is not None:
				raise err
			await self.print('User disabled')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_addspn(self, user_dn, spn):
		"""Adds an SPN entry to the users account"""
		try:
			_, err = await self.client.add_user_spn(user_dn, spn)
			if err is not None:
				raise err
			await self.print('SPN added!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_addhostname(self, user_dn, hostname):
		"""Adds additional hostname to computer account"""
		try:
			_, err = await self.client.add_additional_hostname(user_dn, hostname)
			if err is not None:
				raise err
			await self.print('Hostname added!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_addusertogroup(self, user_dn, group_dn):
		"""Adds user to specified group. Both user and group must be in DN format!"""
		try:
			_, err = await self.client.add_user_to_group(user_dn, group_dn)
			if err is not None:
				raise err
			await self.print('User added to group!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_deluserfromgroup(self, user_dn, group_dn):
		"""Removes user from specified group. Both user and group must be in DN format!"""
		try:
			_, err = await self.client.del_user_from_group(user_dn, group_dn)
			if err is not None:
				raise err
			await self.print('User added to group!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def do_whoami(self):
		"""Whoami"""
		try:
			res, err = await self.client.whoamifull()
			if err is not None:
				raise err
			
			for x in res:
				if isinstance(res[x], str) is True:
					await self.print('%s: %s' % (x, res[x]))
				elif isinstance(res[x], dict) is True:
					for k in res[x]:
						await self.print('Group: %s (%s)' % (k,'\\'.join(res[x][k])))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e


	###########################################

	async def do_rootcas(self, to_print = True):
		"""Lists Root CA certificates"""
		try:
			cas = []
			async for ca, err in self.client.list_root_cas():
				if err is not None:
					raise err
				cas.append(ca)
				if to_print is True:
					await self.print(ca)
			return cas
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_ntcas(self, to_print = True):
		"""Lists NT CA certificates"""
		try:
			cas = []
			async for ca, err in self.client.list_ntcas():
				if err is not None:
					raise err
				cas.append(ca)
				if to_print is True:
					await self.print(ca)
			return cas
		except Exception as e:
			await self.print_exc(e)
			return False
	
	async def do_aiacas(self, to_print = True):
		"""Lists AIA CA certificates"""
		try:
			cas = []
			async for ca, err in self.client.list_aiacas():
				if err is not None:
					raise err
				cas.append(ca)
				if to_print is True:
					await self.print(ca)
			return cas
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_enrollmentservices(self, to_print=True):
		"""Lists AIA CA certificates"""
		try:
			services = []
			async for srv, err in self.client.list_enrollment_services():
				if err is not None:
					raise err
				services.append(srv)
				if to_print is True:
					await self.print(srv)
			return services
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_addcerttemplatenameflagaltname(self, certtemplatename, flags = None):
		"""Modifyies the msPKI-Certificate-Name-Flag value of the specified certificate template and enables ENROLLEE_SUPPLIES_SUBJECT_ALT_NAME bit. If 'flags' is present then it will assign that value."""
		try:
			template = None
			async for template, err in self.client.list_certificate_templates(certtemplatename):
				if err is not None:
					raise err
				break
			
			if template is None:
				raise Exception("Template could not be found!")
			
			template = typing.cast(MSADCertificateTemplate, template)
			if flags is not None:
				flags = int(flags)
			else:
				flags = int(CertificateNameFlag(template.Certificate_Name_Flag) | CertificateNameFlag.ENROLLEE_SUPPLIES_SUBJECT_ALT_NAME)

			changes = {
				'msPKI-Certificate-Name-Flag' : [('replace', [flags])]
			}
	
			_, err = await self.client.modify(template.distinguishedName, changes)
			if err is not None:
				raise err
			
			await self.print('Modify OK!')
			return True


		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_addenrollmentright(self, certtemplatename, user_dn):
		"""Grants enrollment rights to a user (by DN) for the specified certificate template."""
		try:
			user_sid, err = await self.client.get_objectsid_for_dn(user_dn)
			if err is not None:
				raise err
			
			template = None
			async for template, err in self.client.list_certificate_templates(certtemplatename):
				if err is not None:
					raise err
				break
			
			if template is None:
				raise Exception("Template could not be found!")
			template = typing.cast(MSADCertificateTemplate, template)
			new_sd = copy.deepcopy(template.nTSecurityDescriptor)
			ace = ACCESS_ALLOWED_OBJECT_ACE()
			ace.Sid = SID.from_string(user_sid)
			ace.ObjectType = GUID.from_string(EX_RIGHT_CERTIFICATE_ENROLLMENT)
			ace.AceFlags = AceFlags(0)
			ace.Mask = ADS_ACCESS_MASK.READ_PROP | ADS_ACCESS_MASK.WRITE_PROP | ADS_ACCESS_MASK.CONTROL_ACCESS
			ace.Flags = ACE_OBJECT_PRESENCE.ACE_OBJECT_TYPE_PRESENT
			new_sd.Dacl.aces.append(ace)
			_, err = await self.client.set_objectacl_by_dn(template.distinguishedName, new_sd.to_bytes(), flags=SDFlagsRequest.DACL_SECURITY_INFORMATION)
			if err is not None:
				raise err
			await self.print('SD set sucessfully')
			return True
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_certtemplates(self, name = None, to_print = True):
		"""Lists certificate templates"""
		try:
			services = await self.do_enrollmentservices(to_print=False)
			templates = []
			async for template, err in self.client.list_certificate_templates(name):
				if err is not None:
					raise err
				
				lt = None
				if template.nTSecurityDescriptor is not None:
					lt, err = await self.client.resolv_sd(template.nTSecurityDescriptor)
					if err is not None:
						raise err
				template.sid_lookup_table = lt
				for srv in services:
					if template.name in srv.certificateTemplates:
						template.enroll_services.append('%s\\%s' % (srv.dNSHostName, srv.name))

				templates.append(template)
				if to_print is True:
					await self.print(template.prettyprint())

			return templates
		except Exception as e:
			await self.print_exc(e)
			return False

	
	async def do_groupmembers(self, dn, recursive = True, to_print = True):
		"""Returns all member users in a group specified by DN"""
		try:
			res = []
			if recursive is not False or recursive != '0':
				recursive = True
			async for obj, err in self.client.get_group_members(dn, recursive=recursive):
				if err is not None:
					raise err
				if to_print is True:
					await self.print(obj.distinguishedName)
				res.append(obj)
			return res
		except Exception as e:
			await self.print_exc(e)
			return False	
	
	async def do_sid2dn(self, sid, to_print = True):
		"""Returns the DN for a given SID"""
		try:
			dn, err = await self.client.get_dn_for_objectsid(sid)
			if err is not None:
				raise err
			if to_print is True:
				await self.print(dn)
			return dn
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_dn2sid(self, dn, to_print = True):
		"""Returns the SID for a given DN"""
		try:
			sid, err = await self.client.get_objectsid_for_dn(dn)
			if err is not None:
				raise err
			if to_print is True:
				await self.print(sid)
			return sid
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_sidresolv(self, sid, to_print = True):
		"""Returns the domain and username for a given SID"""
		try:
			domain, username, err = await self.client.resolv_sid(sid)
			if err is not None:
				raise err
			res = '%s\\%s' % (domain, username)
			if to_print is True:
				await self.print(res)
			return res
		except Exception as e:
			await self.print_exc(e)
			return False

	async def do_certify(self, cmd = None, username = None):
		"""Identifies all/vulnerable certificate templates (depending on cmd)."""
		try:
			es = await self.do_enrollmentservices(to_print=False)
			if es is False:
				raise Exception('Listing enrollment Services error! %s' % es)
			if es is None:
				raise Exception('No Enrollment Services present, stopping!')
			
			templates = await self.do_certtemplates(to_print=False)
			if templates is False:
				raise Exception('Listing templates error! %s' % es)
			
			if templates is None:
				raise Exception('No templates exists!')
			
			for enrollment in es:
				await self.print(enrollment)
			
			if cmd is not None:
				if cmd.lower().startswith('vuln') is True:
					tokengroups = None
					if username is not None:
						tokengroups, err = await self.client.get_tokengroups_user(username)
						if err is not None:
							raise err

					for template in templates:
						isvuln, reason = template.is_vulnerable(tokengroups)
						if isvuln is True:
							await self.print(reason)
							await self.print(template)
			else:
				for template in templates:
					await self.print(template)

			return True
		except Exception as e:
			await self.print_exc(e)
			return False