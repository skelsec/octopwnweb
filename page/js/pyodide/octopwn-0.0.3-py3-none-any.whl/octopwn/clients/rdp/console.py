from aardwolf import logger
from aardwolf.commons.url import RDPConnectionURL
from aardwolf.commons.iosettings import RDPIOSettings
from aardwolf.commons.queuedata import *
from aardwolf.protocol.x224.constants import SUPP_PROTOCOLS
from aardwolf.extensions.RDPECLIP.protocol.formatlist import CLIPBRD_FORMAT
from aardwolf.commons.queuedata.mouse import RDP_MOUSE
from aardwolf.commons.queuedata.constants import MOUSEBUTTON, VIDEO_FORMAT
from octopwn.clients.base import ClientConsoleBase

from aardwolf.keyboard.layoutmanager import KeyboardLayoutManager
from aardwolf.utils.ducky import DuckyExecutorBase, DuckyReaderFile
from aardwolf.commons.target import RDPConnectionDialect
from aardwolf.keyboard import VK_MODIFIERS


import platform
import asyncio
import datetime

if platform.system().lower() == 'emscripten':
	from pyodide import to_js, create_proxy

class RDPClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		# the connection object is in fact a tuple of KerberosCredential and KerberosTarget
		self.nologon_commands.append('login')
		self.nologon_commands.append('duckyfile')
		self.target = self.connection[0]
		self.credential = self.connection[1]
		self.__rdpconn = None
		self.__video_task = None
		self.mouse_cb_proxy = None
		self.keyboard_cb_proxy = None
		self.paste_cb_proxy = None
		self.duckyscriptpath = None

	async def start(self):
		return True, None

	async def mouse_evt(self, x:int, y:int, button:int, press:bool, release:bool):
		#if press is True:
		#	self.print_sync('MOUSE! X: %s Y: %s BUTTON: %s PRESS: %s RELEASE: %s' % (x, y, button, press, release))
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		button = int(button)
		if button == 1:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_LEFT
		elif button == 2:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_RIGHT
		elif button == 3:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_MIDDLE
		else:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_HOVER
		
		mi = RDP_MOUSE()
		mi.xPos = x
		mi.yPos = y
		mi.button = buttontype
		mi.is_pressed = press
		await self.__rdpconn.ext_in_queue.put(mi)

	def keyboard_evt(self, keychar:str, press:bool, is_scancode:bool = False):
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		if keychar is None:
			self.print_sync('Not recognized input char: %s Skipping!' % keychar)
			return
		if is_scancode is True:
			ki = RDP_KEYBOARD_SCANCODE()
			ki.is_pressed = press
			if keychar.startswith('VK_') is True:
				ki.vk_code = keychar
			else:
				ki.keyCode = int(keychar)
		else:
			ki = RDP_KEYBOARD_UNICODE()
			ki.char = keychar
			ki.is_pressed = press
		self.__rdpconn.ext_in_queue.put_nowait(ki)
	
	async def ducky_keyboard_sender(self, scancode, is_pressed, as_char = False):
		### Callback function for the duckyexecutor to dispatch scancodes/characters to the remote end
		try:
			if as_char is False:
				ki = RDP_KEYBOARD_SCANCODE()
				ki.keyCode = scancode
				ki.is_pressed = is_pressed
				ki.modifiers = VK_MODIFIERS(0)
				await self.__rdpconn.ext_in_queue.put(ki)
			else:
				ki = RDP_KEYBOARD_UNICODE()
				ki.char = scancode
				ki.is_pressed = is_pressed
				await self.__rdpconn.ext_in_queue.put(ki)
		except Exception as e:
			await self.print_exc(e)
	
	def paste_evt(self, *args):
		# not yet used
		self.print_sync('paste! %s' % args)
	
	async def __video_data_handle(self):
		try:
			while not self.__rdpconn.disconnected_evt.is_set():
				await asyncio.sleep(0) # this is needed ot let other coroutines function in case we have too manu updates
				data = await self.__rdpconn.ext_out_queue.get()
				if data is None:
					break

				if data.type == RDPDATATYPE.VIDEO:
					if platform.system().lower() == 'emscripten':
						_, err = await self.octopwnobj.screen_handler.update_rdp_canvas(self.client_id, data.data, data.x, data.y, data.width, data.height)
						#_, err = await self.octopwnobj.screen_handler.update_rdp_canvas(self.client_id, to_js(data.data), data.x, data.y, data.width, data.height)
						if err is not None:
							raise err
					else:
						# CLI mode how to display video? :(
						await self.print("VIDEO DATA: %s" % data.data)

						
				elif data.type == RDPDATATYPE.CLIPBOARD_READY:
					await self.print("Clipboard ready!")
				elif data.type == RDPDATATYPE.CLIPBOARD_CONSUMED:
					await self.print("Clipboard data consumed by server!")
				elif data.type == RDPDATATYPE.CLIPBOARD_NEW_DATA_AVAILABLE:
					await self.print("Got clipboard event: new data is available")
				elif data.type == RDPDATATYPE.CLIPBOARD_DATA_TXT:
					await self.print("Got clipboard data:")
					await self.print(str(data.data))

			await self.print('[-] Connection terminated!')
		
		except asyncio.CancelledError:
			return
		except Exception as e:
			await self.print_exc(e)

	async def do_login(self, size = '1024x768'):
		"""Connect + login"""
		try:
			self.__rdpconn = None
			if size is None:
				size = '1024x768'
			
			width, height = size.lower().split('x')
			height = int(height)
			width = int(width)

			if platform.system().lower() == 'emscripten':
				self.mouse_cb_proxy = create_proxy(self.mouse_evt)
				self.keyboard_cb_proxy = create_proxy(self.keyboard_evt)
				self.paste_cb_proxy = create_proxy(self.paste_evt)
				_, err = await self.octopwnobj.screen_handler.create_rdp_canvas(self.client_id, '%s[%s][%sx%s]' % (self.connection[0].dialect.name, self.client_id, width, height), width, height, self.mouse_cb_proxy, self.keyboard_cb_proxy, self.paste_cb_proxy)
				if err is not None:
					raise err

			iosettings = RDPIOSettings()
			iosettings.video_width = width
			iosettings.video_height = height
			iosettings.video_bpp_min = 15 #servers dont support 8 any more :/
			iosettings.video_bpp_max = 32
			iosettings.video_out_format = VIDEO_FORMAT.RAW
			
			rdpurl = RDPConnectionURL(None, target = self.connection[0], cred = self.connection[1], proxy = self.connection[0].proxy)
			self.__rdpconn = rdpurl.get_connection(iosettings)
			
			await self.print('[+] Login started! %s' % datetime.datetime.utcnow())
			_, err = await asyncio.wait_for(self.__rdpconn.connect(), timeout=15)
			if err is not None:
				await self.__rdpconn.terminate()
				raise err
			
			self.__video_task = asyncio.create_task(self.__video_data_handle())
			self.logon_ok = True
			await self.print('[+] Login OK! %s' % datetime.datetime.utcnow())
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_logout(self):
		try:
			self.logon_ok = False
			if self.__video_task is not None:
				self.__video_task.cancel()
				self.__video_task = None
			if self.__rdpconn is not None:
				await self.__rdpconn.terminate()
			self.__rdpconn = None
			await self.print('[-] Connection terminated!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_paste(self, text):
		try:
			if self.logon_ok is False:
				raise Exception("Not logged in!")
			
			if len(text) > 16000:
				raise Exception("Too much data, currently only 16k chars accepted.")

			ki = RDP_CLIPBOARD_DATA_TXT()
			ki.datatype = CLIPBRD_FORMAT.CF_UNICODETEXT
			ki.data = text
			await self.__rdpconn.ext_in_queue.put(ki)
			await self.print("[+] Remote clipboard set!")
			return True, None
			
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_duckyexec(self):
		"""Starts ducky script. You'll need to login first!"""
		try:
			if self.duckyscriptpath is None:
				await self.print("No duckyscript file is set! Use 'duckyscriptpath' command first!")
				return True, None
			
			layout = KeyboardLayoutManager().get_layout_by_shortname(self.__rdpconn.iosettings.client_keyboard)
			executor = DuckyExecutorBase(layout, self.ducky_keyboard_sender, send_as_char = True if self.__rdpconn.target.dialect == RDPConnectionDialect.VNC else False)
			reader = DuckyReaderFile.from_file(self.duckyscriptpath, executor)
			x = asyncio.create_task(reader.parse())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_duckyfile(self, duckyscriptpath):
		"""Sets duckyscript file to use with duckyexec"""
		try:
			self.duckyscriptpath = duckyscriptpath
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		

		

	