import multiprocessing
import sys
import asyncio
import traceback
import queue
import threading
import time

from aardwolf import logger
from aardwolf.keyboard import VK_MODIFIERS
from aardwolf.commons.url import RDPConnectionURL
from aardwolf.commons.iosettings import RDPIOSettings
from aardwolf.commons.queuedata import RDPDATATYPE
from aardwolf.commons.queuedata.keyboard import RDP_KEYBOARD_SCANCODE, RDP_KEYBOARD_UNICODE
from aardwolf.commons.queuedata.mouse import RDP_MOUSE
from aardwolf.extensions.RDPECLIP.protocol.formatlist import CLIPBRD_FORMAT
from aardwolf.commons.queuedata.clipboard import RDP_CLIPBOARD_DATA_TXT
from aardwolf.commons.queuedata.constants import MOUSEBUTTON, VIDEO_FORMAT
from aardwolf.commons.target import RDPConnectionDialect

from PyQt5.QtWidgets import QApplication, QMainWindow, qApp, QLabel
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot, QThread, Qt
from PyQt5.QtGui import QPainter, QImage, QPixmap

import pyperclip


# with the help of
# https://gist.github.com/jazzycamel/8abd37bf2d60cce6e01d

class OctopwnRDPClientConsoleSettings:
	def __init__(self, iosettings:RDPIOSettings, in_queue:multiprocessing.Queue, out_queue:multiprocessing.Queue):
		self.iosettings:RDPIOSettings = iosettings
		self.in_queue:multiprocessing.Queue = in_queue
		self.out_queue:multiprocessing.Queue = out_queue
		self.mhover = True
		self.isrdp = True

class RDPImage:
	def __init__(self,x,y,image,width,height):
		self.x = x
		self.y = y
		self.image = image
		self.width = width
		self.height = height

class RDPOutThread(QObject):
	result=pyqtSignal(RDPImage)
	
	def __init__(self, parent=None, **kwargs):
		super().__init__(parent, **kwargs)
		self.settings:OctopwnRDPClientConsoleSettings = None
		self.conn = None
		self.input_evt = None
		self.in_q = None
	
	def set_settings(self, settings, in_q):
		self.settings = settings
		self.in_q = in_q
	
	@pyqtSlot()
	def start(self):
		try:
			while True:
				data = self.in_q.get()
				self.settings.out_queue.put(data)
				if data is None:
					break
		except Exception as e:
			traceback.print_exc()

class RDPInThread(QObject):
	result=pyqtSignal(RDPImage)
	
	def __init__(self, parent=None, **kwargs):
		super().__init__(parent, **kwargs)
		self.settings:OctopwnRDPClientConsoleSettings = None
		self.conn = None
		self.input_evt = None
		self.in_q = None
		self.input_handler_thread = None
		self.asyncthread:threading.Thread = None
	
	def set_settings(self, settings):
		self.settings = settings
	
	@pyqtSlot()
	def start(self):
		try:
			while True:
				data = self.settings.in_queue.get()
				if data is None:
					return
				if data.type == RDPDATATYPE.VIDEO:
					ri = RDPImage(data.x, data.y, data.data, data.width, data.height)
					self.result.emit(ri)
				elif data.type == RDPDATATYPE.CLIPBOARD_READY:
					continue
				elif data.type == RDPDATATYPE.CLIPBOARD_NEW_DATA_AVAILABLE:
					continue
				elif data.type == RDPDATATYPE.CLIPBOARD_CONSUMED:
					continue
				elif data.type == RDPDATATYPE.CLIPBOARD_DATA_TXT:
					continue
				else:
					logger.debug('Unknown incoming data: %s'% data)
		except Exception as e:
			traceback.print_exc()

class OctopwnRDPClientQTGUI(QMainWindow):
	#inputevent=pyqtSignal()

	def __init__(self, settings:OctopwnRDPClientConsoleSettings):
		super().__init__()
		self.settings = settings
		self.ducky_key_ctr = 0

		# enabling this will singificantly increase the bandwith
		self.mhover = settings.mhover
		# enabling keyboard tracking
		self.is_rdp = settings.isrdp

		# setting up the main window with the requested resolution
		self.setGeometry(0, 0, self.settings.iosettings.video_width, self.settings.iosettings.video_height)
		# this buffer will hold the current frame and will be contantly updated
		# as new rectangle info comes in from the server
		self._buffer = QImage(self.settings.iosettings.video_width, self.settings.iosettings.video_height, QImage.Format_RGB32)
		
		
		# setting up worker thread in a qthread
		# the worker recieves the video updates from the connection object
		# and then dispatches it to updateImage
		# this is needed as the RDPConnection class uses async queues
		# and QT is not async so an interface between the two worlds
		# had to be created
		
		self._in_thread=QThread()
		self._threaded=RDPInThread(result=self.updateImage)
		self._threaded.set_settings(self.settings)
		self._in_thread.started.connect(self._threaded.start)
		self._threaded.moveToThread(self._in_thread)
		#qApp.aboutToQuit.connect(self._in_thread.quit)
		self._in_thread.start()

		self.in_q = queue.Queue()
		self._out_thread=QThread()
		self._out_threaded=RDPOutThread()
		self._out_threaded.set_settings(self.settings, self.in_q)
		self._out_thread.started.connect(self._out_threaded.start)
		self._out_threaded.moveToThread(self._out_thread)
		#qApp.aboutToQuit.connect(self._out_threaded.quit)
		self._out_threaded.start()

		# setting up the canvas (qlabel) which will display the image data
		self._label_imageDisplay = QLabel()
		self._label_imageDisplay.setFixedSize(self.settings.iosettings.video_width, self.settings.iosettings.video_height)
		
		self.setCentralWidget(self._label_imageDisplay)
		
		# enabling mouse tracking
		self.setMouseTracking(True)
		self._label_imageDisplay.setMouseTracking(True)
		self.__extended_rdp_keys = {
			Qt.Key_End : 'VK_END', 
			Qt.Key_Down : 'VK_DOWN', 
			Qt.Key_PageDown : 'VK_NEXT', 
			Qt.Key_Insert : 'VK_INSERT', 
			Qt.Key_Delete : 'VK_DELETE', 
			Qt.Key_Print : 'VK_SNAPSHOT',
			Qt.Key_Home : 'VK_HOME', 
			Qt.Key_Up : 'VK_UP', 
			Qt.Key_PageUp : 'VK_PRIOR', 
			Qt.Key_Left : 'VK_LEFT',
			Qt.Key_Right : 'VK_RIGHT',
			Qt.Key_Meta : 'VK_LWIN',
			Qt.Key_Enter : 'VK_RETURN',
			Qt.Key_Menu : 'VK_LMENU',
			Qt.Key_Pause : 'VK_PAUSE',
			Qt.Key_Slash: 'VK_DIVIDE',
			Qt.Key_Period: 'VK_DECIMAL',

			#Qt.Key_Shift: 'VK_LSHIFT',
			#Qt.Key_Tab: 'VK_TAB',
			#Qt.Key_0 : 'VK_NUMPAD0',
			#Qt.Key_1 : 'VK_NUMPAD1',
			#Qt.Key_2 : 'VK_NUMPAD2',
			#Qt.Key_3 : 'VK_NUMPAD3',
			#Qt.Key_4 : 'VK_NUMPAD4',
			#Qt.Key_5 : 'VK_NUMPAD5',
			#Qt.Key_6 : 'VK_NUMPAD6',
			#Qt.Key_7 : 'VK_NUMPAD7',
			#Qt.Key_8 : 'VK_NUMPAD8',
			#Qt.Key_9 : 'VK_NUMPAD9',
		}

		self.__qtbutton_to_rdp = {
			Qt.LeftButton   : MOUSEBUTTON.MOUSEBUTTON_LEFT,
			Qt.RightButton  : MOUSEBUTTON.MOUSEBUTTON_RIGHT,
			Qt.MidButton    : MOUSEBUTTON.MOUSEBUTTON_MIDDLE,
			Qt.ExtraButton1 : MOUSEBUTTON.MOUSEBUTTON_5,
			Qt.ExtraButton2 : MOUSEBUTTON.MOUSEBUTTON_6,
			Qt.ExtraButton3 : MOUSEBUTTON.MOUSEBUTTON_7,
			Qt.ExtraButton4 : MOUSEBUTTON.MOUSEBUTTON_8,
			Qt.ExtraButton5 : MOUSEBUTTON.MOUSEBUTTON_9,
			Qt.ExtraButton6 : MOUSEBUTTON.MOUSEBUTTON_10,
		}
	
	def closeEvent(self, event):
		self.connectionClosed()
		event.accept()
	
	def connectionClosed(self):
		self.in_q.put(None)
		self._in_thread.quit()
		self.close()
	
	def updateImage(self, event):
		if event.width == self.settings.iosettings.video_width and event.height == self.settings.iosettings.video_height:
			self._buffer = event.image
		else:
			with QPainter(self._buffer) as qp:
				qp.drawImage(event.x, event.y, event.image, 0, 0, event.width, event.height)
		
		pixmap01 = QPixmap.fromImage(self._buffer)
		pixmap_image = QPixmap(pixmap01)
		self._label_imageDisplay.setPixmap(pixmap_image)
		self._label_imageDisplay.setAlignment(Qt.AlignCenter)
		self._label_imageDisplay.setScaledContents(True)
		self._label_imageDisplay.setMinimumSize(1,1)
		self._label_imageDisplay.show()
	

	def send_key(self, e, is_pressed):
		# https://doc.qt.io/qt-5/qt.html#Key-enum
		#print(self.keyevent_to_string(e))

		if e.key()==(Qt.Key_Control and Qt.Key_V):
			ki = RDP_CLIPBOARD_DATA_TXT()
			ki.datatype = CLIPBRD_FORMAT.CF_UNICODETEXT
			ki.data = pyperclip.paste()
			self.in_q.put(ki)
		
		modifiers = VK_MODIFIERS(0)
		qt_modifiers = QApplication.keyboardModifiers()
		if bool(qt_modifiers & Qt.ShiftModifier) is True and e.key() != Qt.Key_Shift:
			modifiers |= VK_MODIFIERS.VK_SHIFT
		if bool(qt_modifiers & Qt.ControlModifier) is True and e.key() != Qt.Key_Control:
			modifiers |= VK_MODIFIERS.VK_CONTROL
		if bool(qt_modifiers & Qt.AltModifier) is True and e.key() != Qt.Key_Alt:
			modifiers |= VK_MODIFIERS.VK_MENU
		if bool(qt_modifiers & Qt.KeypadModifier) is True and e.key() != Qt.Key_NumLock:
			modifiers |= VK_MODIFIERS.VK_NUMLOCK
		if bool(qt_modifiers & Qt.MetaModifier) is True and e.key() != Qt.Key_Meta:
			modifiers |= VK_MODIFIERS.VK_WIN

		ki = RDP_KEYBOARD_SCANCODE()
		ki.keyCode = e.nativeScanCode()
		ki.is_pressed = is_pressed
		if sys.platform == "linux":
			#why tho?
			ki.keyCode -= 8
		ki.modifiers = modifiers

		if e.key() in self.__extended_rdp_keys.keys():
			ki.vk_code = self.__extended_rdp_keys[e.key()]

		#print('SCANCODE: %s' % ki.keyCode)
		#print('VK CODE : %s' % ki.vk_code)
		#print('TEXT    : %s' % repr(e.text()))
		self.in_q.put(ki)

	def send_mouse(self, e, is_pressed, is_hover = False):
		if is_hover is True and self.settings.mhover is False:
			# is hovering is disabled we return immediately
			return
		buttonNumber = MOUSEBUTTON.MOUSEBUTTON_HOVER
		if is_hover is False:
			buttonNumber = self.__qtbutton_to_rdp[e.button()]

		mi = RDP_MOUSE()
		mi.xPos = e.pos().x()
		mi.yPos = e.pos().y()
		mi.button = buttonNumber
		mi.is_pressed = is_pressed if is_hover is False else False

		self.in_q.put(mi)
	
	def keyPressEvent(self, e):
		self.send_key(e, True)

	def keyReleaseEvent(self, e):
		self.send_key(e, False)
	
	def mouseMoveEvent(self, e):
		self.send_mouse(e, False, True)

	def mouseReleaseEvent(self, e):
		self.send_mouse(e, False)

	def mousePressEvent(self, e):
		self.send_mouse(e, True)
	
class QTGuiRDPStarter(multiprocessing.Process):
	def __init__(self, settings):
		multiprocessing.Process.__init__(self)
		self.settings = settings
	
	def run(self):
		app = QApplication(sys.argv)
		qtclient = OctopwnRDPClientQTGUI(self.settings)
		qtclient.show()
		window = QMainWindow()
		window.show()
		app.exec_()
		qApp.quit()