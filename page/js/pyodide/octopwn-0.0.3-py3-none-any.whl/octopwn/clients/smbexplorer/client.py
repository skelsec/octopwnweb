import os
import shlex
import ntpath
import asyncio
import fnmatch
import traceback
import copy
import platform
from functools import reduce

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from aiosmb.commons.interfaces.machine import SMBMachine
from aiosmb.commons.interfaces.share import SMBShare
from aiosmb.commons.interfaces.directory import SMBDirectory
from aiosmb.commons.interfaces.file import SMBFile
from aiosmb.dcerpc.v5.common.service import SMBServiceStatus
from aiosmb.examples.smbpathcompleter import SMBPathCompleter
from aiosmb.dcerpc.v5.interfaces.icprmgr import ICPRRPC
from aiosmb.dcerpc.v5.connection import DCERPC5Connection
from aiosmb.dcerpc.v5.common.connection.authentication import DCERPCAuth
from aiosmb.dcerpc.v5.interfaces.endpointmgr import EPM
from asysocks.client import SocksTunnelError

from pypykatz.alsadecryptor.asbmfile import SMBFileReader
from pypykatz.registry.aoffline_parser import OffineRegistry
from pypykatz.alsadecryptor.asbmfile import SMBFileReader
from pypykatz.apypykatz import apypykatz

class FileSystem():

	def __init__(self,filePath=None):
		self.children = []
		if filePath != None:
			try:
				self.name, child = filePath.split("\\", 1)
				self.children.append(FileSystem(child))
			except (ValueError):
				self.name = filePath

	def addChild(self, filePath):
		try:
			thisLevel, nextLevel = filePath.split("\\", 1)
			try:
				print(self.name)
				if thisLevel == self.name:
					thisLevel, nextLevel = nextLevel.split("\\", 1)
			except (ValueError):
				self.children.append(FileSystem(nextLevel))
				return
			for child in self.children:
				if thisLevel == child.name:
					child.addChild(nextLevel)
					return
			self.children.append(FileSystem(nextLevel))
		except (ValueError):
			self.children.append(FileSystem(filePath))

	def getChildren(self):
		return self.children

	def printAllChildren(self, depth = -1):
		depth += 1
		print("\t"*depth + "Name: "+ self.name)
		if len(self.children) > 0:
			print("\t"*depth +"{ Children:")
			for child in self.children:
				child.printAllChildren(depth)
			print("\t"*depth + "}")
			
	def makeDict(self):
		if len(self.children) > 0:
			dictionary = {self.name:[]}
			for child in self.children:
				dictionary[self.name].append(child.makeDict())
			return dictionary
		else:
			return self.name


class SMBExplorer(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.machine: SMBMachine = None
		self.is_anon = False
		self.no_dce = False
		self.nologon_commands.append('login')
		self.nologon_commands.append('no_dce')
		self.shares = {} #name -> share
		#self.filesystem:FileSystem = None
		self.filesystem = {}
		self.fileinfo = {} #unc, entrytype
	
	async def start(self):
		return True, None

	async def _on_close(self):
		await self.do_logout()
	
	async def do_login(self):
		"""Connect + login"""
		try:
			self.connection = copy.deepcopy(self.original_connection)
			_, err = await self.connection.login()
			if err is not None:
				raise err
			self.machine = SMBMachine(self.connection, print_cb=self.print)
			#self.filesystem = FileSystem('\\\\%s\\' % self.connection.target.get_hostname())
			await self.do_shares(show = False)
			self.logon_ok = True
			await self.print('Login success')
			return True, None
		
		except SocksTunnelError as e:
			await self.print_exc(e.innerexception)
			return None, e

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_shares(self, show = True):
		"""Lists available shares"""
		try:
			if self.machine is None:
				await self.print('Not logged in! Use "login" first!')
				return False, Exception('Not logged in!')
			self.filesystem['%s' % self.connection.target.get_hostname_or_ip()] = {}
			async for share, err in self.machine.list_shares():
				if err is not None:
					raise err
				self.shares[share.name] = share
				#self.filesystem.addChild('\\\\%s' % self.connection.target.get_hostname() + '\\\\' + share.name)
				self.filesystem['%s' % self.connection.target.get_hostname_or_ip()][share.name] = {}
				self.fileinfo[share.unc_path] = 'share'
				if show is True:
					await self.print(share.name)
			return True, None
		except Exception as e:
			if show is True:
				await self.print_exc(e)
			return None, e

	async def do_fs(self, show = True):
		try:
			await self.print(str(self.fileinfo))
			await self.print(self.filesystem)
			#await self.print(str(self.filesystem.makeDict()))
		except Exception as e:
			if show is True:
				await self.print_exc(e)
			return None, e

	#async def do_unc(self):
	#	for k in self.filesystem:

	
	async def do_list(self, unc, show = True):
		try:
			ukey = unc.split('\\')[2:]
			await self.print(ukey)
			if self.machine is None:
				await self.print('Not logged in! Use "login" first!')
				return False, Exception('Not logged in!')
			if unc not in self.fileinfo:
				await self.print('Path %s not found! ' % unc)
				return False, Exception('Not logged in!')
			elif self.fileinfo[unc] == 'dir' or self.fileinfo[unc] == 'share':
				cd = reduce(dict.get, ukey, self.filesystem) 
				d = SMBDirectory.from_uncpath(unc)
				#if self.fileinfo[unc] == 'share':
				#	d = SMBDirectory.from_uncpath(unc)
				async for entry, entrytype, err in d.list_gen(self.connection):
					if err is not None:
						raise err
					if entrytype == 'dir':
						cd[entry.name] = {}
					else:
						cd[entry.name] = None
					#self.filesystem.addChild(entry.unc_path)
					self.fileinfo[entry.unc_path] = entrytype
			return True, None
		except Exception as e:
			if show is True:
				await self.print_exc(e)
			return None, e

	async def do_logout(self):
		self.logon_ok = False
		if self.machine is not None:
			await self.machine.close()
		self.machine = None

		if self.connection is not None:
			try:
				await self.connection.terminate()
			except Exception as e:
				logger.exception('connection.close')
		self.connection = None
		return True, None



