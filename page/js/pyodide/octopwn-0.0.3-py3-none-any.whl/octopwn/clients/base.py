
# this is a modified version of AIOCMD http://github.com/KimiNewt/aiocmd

import inspect
import asyncio
import traceback
import shlex
import copy
import os
import shutil
from octopwn.common.utils import chunker, hexdump

from prompt_toolkit.completion.nested import NestedCompleter
from prompt_toolkit.completion import WordCompleter

class ClientConsoleBase:
	def __init__(self, client_id:int, connection, cmd_q, msg_queue, prompt, octopwnobj, settings = None):
		self.prompt = prompt
		self.octopwnobj = octopwnobj
		self.settings = settings
		self.ATTR_START = 'do_'
		self.doc_header = ""
		self.aliases = {"?": "help", "exit": "quit"}
		self.cmd_q = cmd_q
		self.client_id = client_id
		self.connection = connection
		self.original_connection = copy.deepcopy(connection)
		self.msg_queue = msg_queue
		self.nologon_commands = ['?', 'help', 'q', 'quit', 'exit']
		self.logon_ok = False
	
	def load_settings(self, settings):
		self.settings = settings
		
	def to_dict(self):
		return {}

	def make_completer(self):
		return NestedCompleter({com: self._completer_for_command(com) for com in self.command_list()})
	
	def _completer_for_command(self, command):
		if not hasattr(self, "_%s_completions" % command):
			return WordCompleter([])
		return getattr(self, "_%s_completions" % command)()
	
	def _get_command(self, command):
		if command in self.aliases:
			command = self.aliases[command]
		return getattr(self, self.ATTR_START + command)

	def _get_command_args(self, command):
		args = [param for param in inspect.signature(self._get_command(command)).parameters.values()
				if param.default == param.empty]
		kwargs = [param for param in inspect.signature(self._get_command(command)).parameters.values()
				  if param.default != param.empty]
		return args, kwargs

	def _get_command_usage(self, command, args, kwargs):
		return ("%s %s %s" % (command,
							  " ".join("<%s>" % arg for arg in args),
							  " ".join("[%s]" % kwarg for kwarg in kwargs),
							  )).strip()
	
	async def _run_single_command(self, command, args):
		fullcmd = shlex.join([command] + args)
		await self.print('>>> %s' % fullcmd)
		if 'any' not in self.nologon_commands:
			if self.logon_ok is False and command.lower() not in self.nologon_commands:
				await self.print("Command '%s' can\'t be executed without login first!" % command )
				return
		try:
			command_real_args, command_real_kwargs = self._get_command_args(command)
		except Exception as e:
			await self.print("Unknown command '%s'" % command )
			return
		if len(args) < len(command_real_args) or len(args) > (len(command_real_args)
															  + len(command_real_kwargs)):
			await self.print("Bad command args. Usage: %s" % self._get_command_usage(command, command_real_args,
																		  command_real_kwargs))
			return

		try:
			com_func = self._get_command(command)
			if asyncio.iscoroutinefunction(com_func):
				await com_func(*args)
			else:
				com_func(*args)
			return
		except (asyncio.CancelledError):
			raise
		except Exception as ex:
			await self.print("Command %s failed: %s Exc: %s" % (command, traceback.format_tb(ex.__traceback__), ex))

	def command_list(self):
		return [attr[len(self.ATTR_START):]
				for attr in dir(self) if attr.startswith(self.ATTR_START)] + list(self.aliases.keys())

	async def do_help(self, command = None):
		"""Displays help menu"""
		if command is None:
			await self.print()
			if self.doc_header is not None and len(self.doc_header) >0 :
				await self.print(self.doc_header)
				await self.print("=" * len(self.doc_header))
			await self.print("Command list")
			await self.print('Use "help <command>" to get more info on the specific command')
			await self.print()
			cmdmaxlen = max([len(x) for x in self.command_list()]) + 2
			for command in sorted(self.command_list()):
				command_doc = self._get_command(command).__doc__
				if command_doc is None:
					command_doc = ''
				command_doc = command_doc.split('\n',1)[0]
				await self.print('%s%s%s' % (command, ' '*(cmdmaxlen - len(command)), command_doc))
			await self.print()

			#await self.print()
			#await self.print(self.doc_header)
			#await self.print("=" * len(self.doc_header))
			#await self.print()
			#
			#get_usage = lambda command: self._get_command_usage(command, *self._get_command_args(command))
			#max_usage_len = max([len(get_usage(command)) for command in self.command_list()])
			#for command in sorted(self.command_list()):
			#	command_doc = self._get_command(command).__doc__
			#	await self.print(("%-" + str(max_usage_len + 2) + "s%s") % (get_usage(command), command_doc or ""))
		else:
			try:
				self._get_command(command)
			except:
				await self.print('Command not found "%s"' % command)
				return
			alias = self.aliases.get(command, None)
			docstr = self._get_command(command).__doc__
			command_real_args, command_real_kwargs = self._get_command_args(command)
			command_params = self._get_command_usage(command, command_real_args, command_real_kwargs)
			await self.print('Command: "%s"' % command)
			if alias is not None:
				await self.print('Alias  : "%s"' % alias)
			
			await self.print('Usage  : "%s"' % command_params)
			if docstr is None or len(docstr) == 0:
				await self.print("No documentation provided currently.")
				return
			
			await self.print("Help")
			await self.print(docstr)
			await self.print()
	
	async def do_quit(self):
		try:
			if hasattr(self, 'do_logout') is True:
				await self.do_logout()
			if self.client_id != 0:
				await self.octopwnobj.do_switchclient(0)
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_pwd(self):
		"""Prints the path of the current working dir"""
		try:
			await self.print(os.getcwd())
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_lls(self, path = None):
		"""Lists files and folders in given path. Default: current workdir"""
		try:
			for item in os.listdir(path):
				await self.print(item)
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_lcp(self, src, dst):
		"""Copies file from src to dst."""
		try:
			shutil.copy2(src, dst)
			await self.print('File copied!')
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_lmove(self, src, dst):
		"""Moves files and folders from src to dst."""
		try:
			shutil.move(src, dst)
			await self.print('File copied!')
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def do_lcat(self, filepath):
		"""Prints !TEXT! file contents to current window"""
		try:
			with open(filepath, 'r') as f:
				for line in f:
					await self.print(line.strip())
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def do_lxxd(self, filepath):
		"""Prints hex contents of the file to the current window"""
		try:
			offset = 0
			with open(filepath, 'r') as f:
				while True:
					data = f.read(1024)
					if data == b'':
						break
					await self.print_hex(data, offset=offset)
					offset += len(data)
		except Exception as e:
			traceback.print_exc()
			return None, e

	def print_sync(self, msg = '', store_file = False):
		asyncio.create_task(self.print(msg))

	async def print(self, msg = ''):
		msg = str(msg)
		for line in msg.split('\n'):
			await self.msg_queue.put((self.client_id, str(line)))
	
	async def print_table(self, lines, separate_head=True):
		"""Prints a formatted table given a 2 dimensional array"""
		#Count the column width
		widths = []
		for line in lines:
				for i,size in enumerate([len(x) for x in line]):
						while i >= len(widths):
								widths.append(0)
						if size > widths[i]:
								widths[i] = size
		
		#Generate the format string to pad the columns
		print_string = ""
		for i,width in enumerate(widths):
				print_string += "{" + str(i) + ":" + str(width) + "} | "
		if (len(print_string) == 0):
				return
		print_string = print_string[:-3]
		
		#Print the actual data
		for i,line in enumerate(lines):
				await self.print(print_string.format(*line))
				if (i == 0 and separate_head):
						await self.print("-"*(sum(widths)+3*(len(widths)-1)))

	async def print_hex(self, data, offset = 0):
		await self.print(hexdump(data, offset=offset))
	
	def print_exc_sync(self, err:Exception, with_tb = True, extra_msg = ''):
		asyncio.create_task(self.print_exc(err, with_tb, extra_msg))

	async def print_exc(self, err:Exception, with_tb = True, extra_msg = ''):
		if with_tb is False:
			await self.print('Error: %s Exception: %s' % (extra_msg, err))
			return
		
		await self.print('Error: %s Exception: %s' % (extra_msg, err))
		for lines in traceback.format_tb(err.__traceback__):
			for line in lines.split('\n'):
				await self.print('Traceback: %s' % line)


	async def change_prompt(self, newprompt):
		self.prompt = newprompt
		await self.octopwnobj.client_changeprompt_cb(self.client_id, newprompt)

	async def __run_core(self):
		try:
			while True:
				try:
					command = await self.cmd_q.get()
					if command is None:
						await self.do_quit()
					cmd = shlex.split(command)
					await self._run_single_command(cmd[0], cmd[1:])
				except Exception as e:
					await self.print_exc(e)
					continue
		except Exception as e:
			await self.print_exc(e)
			return False, e
	
	async def run(self):
		try:
			if hasattr(self, 'start') is True:
				#additional setup might be needed for the child
				_, err = await self.start()
				if err is not None:
					raise err
			core_task = asyncio.create_task(self.__run_core())
			return core_task, None
			
		except Exception as e:
			await self.print_exc(e)
			return False, e
