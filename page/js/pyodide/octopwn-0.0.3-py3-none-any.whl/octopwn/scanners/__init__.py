from octopwn.scanners.smbos import SMBFingerScanner
from octopwn.scanners.smbfile import SMBFileScanner
from octopwn.scanners.smbadmin import SMBAdminScanner
from octopwn.scanners.smbsession import SMBSessionScanner
from octopwn.scanners.smbiface import SMBIfaceScanner
from octopwn.scanners.smbprotocol import SMBProtocolScanner
from octopwn.scanners.smbprintnightmare import SMBPrintnightmareScanner
from octopwn.scanners.rdpscreen import RDPScreenshotScanner
from octopwn.scanners.rdplogin import RDPLoginScanner
from octopwn.scanners.rdpcap import RDPCapScanner
from octopwn.scanners.jackdaw import JackdawScanner
from octopwn.scanners.krb5userenum import KRB5UserEnum
from octopwn.scanners.smbregdump import SMBRegdumpScanner


OCTOPWN_SCANNER_TABLE = {
	'SMBFINGER': SMBFingerScanner,
	'SMBFILE': SMBFileScanner,
	'SMBADMIN': SMBAdminScanner,
	'SMBSESSION': SMBSessionScanner,
	'SMBPRINTNIGHTMARE': SMBPrintnightmareScanner,
	'SMBIFACE': SMBIfaceScanner,
	'SMBPROTO': SMBProtocolScanner,
	'RDPSCREEN': RDPScreenshotScanner,
	'RDPLOGIN': RDPLoginScanner,
	'RDPCAP': RDPCapScanner,
	'JACKDAW': JackdawScanner,
	'KRB5USER': KRB5UserEnum,
	'SMBREGDUMP': SMBRegdumpScanner,
}