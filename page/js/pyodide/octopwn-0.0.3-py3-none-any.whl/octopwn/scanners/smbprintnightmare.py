import traceback
import asyncio
import os
import copy
import platform

from aiosmb.commons.connection.target import SMBTarget
from aiosmb.commons.connection.credential import SMBAuthProtocol
from aiosmb.commons.connection.url import SMBConnectionURL
from octopwn.common.utils import isint
from octopwn.clients.scannerbase import ScannerConsoleBase
from aiosmb.examples.smbprintnightmareenum import SMBPrintnightmareEnum
from aiosmb.examples.scancommons.targetgens import ListTargetGen, FileTargetGen

class SMBPrintnightmareScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'credential': (int, None),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'authtype': (str, 'NTLM'),
			'workercount' : (int,100),
			'output_type' : (str, 'tsv'),
			'proxy': (int, None),
			'resultsfile': (str, 'smb_scan_printnightmare_%s.tsv' % os.urandom(4).hex())
		}

		self.ext_result_q = None

		self.enumerator_task = None
		self.monitor_task = None
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			await self.print('Pyodide detected, setting default proxy to "WSNET 0"')
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			self.monitor_task.cancel()
			await self.print('Scan stopped!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self):
		try:
			current_percent = 0.0
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				outfile = open(self.params['resultsfile'][1], 'a', newline = '')
			
			while True:
				await asyncio.sleep(0)
				data = await self.ext_result_q.get()
				if data.otype == 'finished':
					break
				elif data.otype == 'result':
					x = data.to_tsv()
					if x is not None:
						if outfile is not None:
							outfile.write(x + '\r\n')
						else:
							await self.print(x.replace('\t', '|'))
				elif data.otype == 'progress':
					if data.obj.total_targets is not None and data.obj.total_targets > 0:
						percent = round((data.obj.total_finished / data.obj.total_targets)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (data.obj.total_targets, data.obj.total_finished, percent))
							current_percent = percent
			
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if outfile is not None:
				outfile.close()


	async def do_scan(self):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			if self.params['credential'][1] is None:
				await self.print("No credential set! Not starting scan")
				return False, None

			self.target_gens = []
			target = SMBTarget('999.999.999.999')
			if self.params['proxy'][1] is not None:
				tproxy = copy.deepcopy(self.octopwnobj.proxies[int(self.params['proxy'][1])])
				tproxy.wsnet_reuse = True
				target = tproxy.get_smb_proxy(target, self.octopwnobj.proxies)
			
			authtype = SMBAuthProtocol(self.params['authtype'][1])
			credential = self.octopwnobj.credentials[self.params['credential'][1]].get_smb_cred(authtype, target)
			smb_url = SMBConnectionURL(None, credential, target)
			# await self.print(smb_url)

			self.ext_result_q = asyncio.Queue()
			self.monitor_task = asyncio.create_task(self.__monitor_queue())

			for target in self.params['targetfiles'][1]:
				self.target_gens.append(FileTargetGen(target))
			
			self.target_gens.append(ListTargetGen(self.params['targets'][1]))


			self.enumerator = SMBPrintnightmareEnum(
				smb_url, 
				worker_count = self.params['workercount'][1], 
				output_type = 'tsv', 
				out_file = None, 
				show_pbar = False,
				ext_result_q=self.ext_result_q,
			)
			self.enumerator.target_gens = self.target_gens
			self.scan_running = True

			self.enumerator_task = asyncio.create_task(self.enumerator.run())

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e