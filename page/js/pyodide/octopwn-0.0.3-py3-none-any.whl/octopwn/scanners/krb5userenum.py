import traceback
import asyncio
import os
import copy
import platform

from minikerberos.common.spn import KerberosSPN
from minikerberos.security import KerberosUserEnum
from octopwn.clients.scannerbase import ScannerConsoleBase
from aiosmb.examples.scancommons.targetgens import ListTargetGen, FileTargetGen

class EnumResult:
	def __init__(self, otype, result):
		self.otype = otype
		self.result = result

class KRB5UserEnum(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'target' : (str, None),
			'usernames' : (list, []),
			'usernamefiles' : (list, []),
			'realm' : (str, None),
			'workercount' : (int, 10),
			'proxy': (int, None),
			'resultsfile': (str, 'krb5userenum_%s.tsv' % os.urandom(4).hex())
		}

		self.enumerator_task = None
		self.monitor_task = None
		self.results_ctr = 0
		self.total_ctr = 0
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			await self.print('Pyodide detected, setting default proxy to "WSNET 0"')
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False

	async def __targetgen(self, targetqueue, username_gens):
		try:
			ctr = 0
			for targetgen in username_gens:
				async for uid, username, err in targetgen.generate():
					if err is not None:
						raise err
					ctr += 1
					await targetqueue.put((uid, username))
			return ctr, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def __enumexecutor(self, target, targetqueue, resultqueue):
		try:
			while True:
				data = await targetqueue.get()
				if data is None:
					break
				uid, username = data
				spn = KerberosSPN()
				spn.domain = self.params['realm'][1]
				spn.username = username
				try:
					test = KerberosUserEnum(target, spn)
					res = await test.run()
					if res is True:
						await resultqueue.put(EnumResult('result', (uid, str(spn))))
				except Exception as e:
					await resultqueue.put(EnumResult('enumerror', e))


		except Exception as e:
			await self.print_exc(e)
			await resultqueue.put(EnumResult('error', e))
			return None, e

	async def __progress_printer(self):
		try:
			while True:
				await asyncio.sleep(2)
				if self.total_ctr is None or self.total_ctr == 0:
					await self.print('Enumerating... %s usernames' % self.results_ctr)
				else:
					await self.print('Enumerating... %s/%s (%%%s)' % (self.results_ctr, self.total_ctr, round((self.results_ctr/self.total_ctr)*100, 2)))
		except Exception as e:
			await self.print_exc(e)
			return

	async def __enumerator(self, target, username_gens):
		try:
			self.results_ctr = 0
			self.total_ctr = 0
			resultqueue = asyncio.Queue()
			targetqueue = asyncio.Queue()

			progress_task = asyncio.create_task(self.__progress_printer())
			monitor_task = asyncio.create_task(self.__monitor_queue(resultqueue))
			enumexecutor_tasks = []
			usergen_task = asyncio.create_task(self.__targetgen(targetqueue, username_gens))
			for _ in range(self.params['workercount'][1]):
				enumexecutor_tasks.append(asyncio.create_task(self.__enumexecutor(target, targetqueue, resultqueue)))
			self.total_ctr, err = await usergen_task #waiting for generators to finish
			if err is not None:
				raise err
			for _ in range(self.params['workercount'][1]):
				await targetqueue.put(None)
			await asyncio.wait(enumexecutor_tasks )
			await resultqueue.put(EnumResult('finished', None))
			await monitor_task


		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			progress_task.cancel()
			monitor_task.cancel()
			usergen_task.cancel()
			for t in enumexecutor_tasks:
				t.cancel()
	
	async def __monitor_queue(self, ext_result_q):
		try:
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				outfile = open(self.params['resultsfile'][1], 'a', newline = '')
			while True:
				await asyncio.sleep(0)
				data = await ext_result_q.get()
				if data.otype == 'finished':
					break
				elif data.otype == 'result':
					_, x = data.result
					if x is not None:
						self.results_ctr = 0
						if outfile is not None:
							outfile.write(x + '\r\n')
							outfile.flush()
						else:
							await self.print(x.replace('\t', '|'))
			
			await self.print('[+] Enum finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
			if outfile is not None:
				outfile.close()


	async def do_scan(self):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			if self.params['realm'][1] is None:
				await self.print("Realm must be set!")
				return
			
			if self.params['target'][1] is None:
				await self.print("Target must be set! (eg. the DC)")
				return

			username_gens = []
			target = copy.deepcopy(self.octopwnobj.targets[int(self.params['target'][1])])
			kerberostarget = target.get_kerberos_target()
			if self.params['proxy'][1] is not None:
				tproxy = copy.deepcopy(self.octopwnobj.proxies[int(self.params['proxy'][1])])
				tproxy.wsnet_reuse = True
				kerberostarget = tproxy.get_kerberos_proxy(kerberostarget, self.octopwnobj.proxies)
			
			
			for target in self.params['usernamefiles'][1]:
				username_gens.append(FileTargetGen(target))
			
			username_gens.append(ListTargetGen(self.params['usernames'][1]))
			self.enumerator_task = asyncio.create_task(self.__enumerator(kerberostarget, username_gens))
			self.scan_running = True
			await self.print('[+] Enum started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	