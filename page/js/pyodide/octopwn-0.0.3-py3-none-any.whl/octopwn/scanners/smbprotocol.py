import asyncio
import copy
import os
import platform

from octopwn.clients.scannerbase import ScannerConsoleBase
from aiosmb.commons.connection.target import SMBTarget
from aiosmb.commons.connection.credential import SMBCredential, SMBAuthProtocol, SMBCredentialsSecretType
from aiosmb.commons.connection.url import SMBConnectionURL
from aiosmb.examples.smbprotocolenum import SMBProtocolEnum
from aiosmb.examples.scancommons.targetgens import ListTargetGen, FileTargetGen

class SMBProtocolScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.params = {
			'workercount' : (int,100),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'timeout' : (int,5),
			'only_signing' : (bool, False),
			'proxy': (int, None),
			'resultsfile': (str, 'smb_scan_protocol_%s.tsv' % os.urandom(4).hex())
		}
		self.ext_result_q = None
		self.enumerator_task = None
		self.monitor_task = None
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			self.monitor_task.cancel()
			await self.print('[!] Scan stopped!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self):
		try:
			current_percent = 0.0
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				outfile = open(self.params['resultsfile'][1], 'a', newline = '')
			
			while True:
				await asyncio.sleep(0)
				data = await self.ext_result_q.get()
				if data.otype == 'finished':
					break
				elif data.otype == 'progress':
					if data.obj.total_targets is not None and data.obj.total_targets > 0:
						percent = round((data.obj.total_finished / data.obj.total_targets)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (data.obj.total_targets, data.obj.total_finished, percent))
							current_percent = percent
				elif data.otype == 'result':
					x = data.to_tsv()
					if x is not None:
						if outfile is not None:
							outfile.write(x + '\r\n')
						else:
							await self.print(x.replace('\t', '|'))
				#await self.print(data)
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if outfile is not None:
				outfile.close()

	async def do_scan(self):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			self.target_gens = []
			target = SMBTarget('999.999.999.999')
			if self.params['proxy'][1] is not None:
				tproxy = copy.deepcopy(self.octopwnobj.proxies[int(self.params['proxy'][1])])
				tproxy.wsnet_reuse = True
				target = tproxy.get_smb_proxy(target, self.octopwnobj.proxies)
			cred = SMBCredential(
					username = 'dummy',
					domain = 'dummy',
					secret = 'dummy',
					secret_type = SMBCredentialsSecretType.PASSWORD,
					authentication_type = SMBAuthProtocol.NTLM,
					settings = {},
					target = target
				)
			smb_url = SMBConnectionURL(None, cred, target)

			for target in self.params['targetfiles'][1]:
				self.target_gens.append(FileTargetGen(target))
			
			self.target_gens.append(ListTargetGen(self.params['targets'][1]))

			self.ext_result_q = asyncio.Queue()
			self.monitor_task = asyncio.create_task(self.__monitor_queue())
			self.enumerator = SMBProtocolEnum(
				smb_url,
				worker_count = self.params['workercount'][1],
				timeout = self.params['timeout'][1], 
				only_signing = self.params['only_signing'][1],
				show_pbar = False, 
				ext_result_q = self.ext_result_q, 
				output_type = 'tsv', 
				out_file = None
			)
		
			self.enumerator.target_gens = self.target_gens
			self.enumerator_task = asyncio.create_task(self.enumerator.run())
			self.scan_running = True
			await self.print('[+] Scan started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	