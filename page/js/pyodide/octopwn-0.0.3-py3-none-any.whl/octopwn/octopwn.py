from __future__ import unicode_literals
import traceback
import asyncio
import shlex
import typing
import os
import gzip
import ipaddress
import platform
import copy
from typing import Dict, Tuple, List, Any

from asysocks import logger as sockslogger
from minikerberos import logger as kerblogger
from aiosmb.examples.smbpathcompleter import SMBPathCompleter
from aiosmb.commons.connection.credential import SMBAuthProtocol
from aiosmb.commons.connection.target import SMBConnectionDialect, SMBConnectionProtocol
from msldap.commons.target import LDAPProtocol
from aardwolf.commons.credential import RDPAuthProtocol
from aardwolf.commons.target import RDPConnectionDialect
from msldap.commons.url import MSLDAPURLDecoder
from msldap.commons.target import LDAPProtocol
from msldap.commons.credential import LDAPAuthProtocol


from aiosmb.commons.connection.target import SMBTarget
from aiosmb.commons.connection.credential import SMBAuthProtocol
from aiosmb.commons.connection.url import SMBConnectionURL

from minikerberos.common.target import KerberosTarget, KerberosSocketType
from minikerberos.common.creds import KerberosCredential, KerberosSecretType
from minikerberos.common.url import KerberosClientURL



from octopwn import logger
from octopwn._version import __banner__
from octopwn.clients.ldap.console import LDAPClient
from octopwn.common.utils import gtt
from octopwn.clients.base import ClientConsoleBase
from octopwn.common.credential import Credential
from octopwn.common.target import Target
from octopwn.common.proxy import Proxy, ProxyChain
from octopwn.common.clientconfig import ClientConfig, ClientConfigBase, ScannerConfig, UtilsConfig, ServerConfig
from octopwn.common.session import OctoPwnSessionFile
from octopwn.clients.smb.console import SMBClient
from octopwn.clients.kerberos.console import KerberosClient
from octopwn.clients.rdp.console import RDPClient
from octopwn.clients.smbexplorer.client import SMBExplorer
from octopwn.clients.netcat.console import NetCatClient
from octopwn.scanners import OCTOPWN_SCANNER_TABLE
from octopwn.servers import OCTOPWN_SERVER_TABLE
from octopwn.utils import OCTOPWN_UTIL_TABLE

from octopwn.common.screenhandler import ScreenHandlerBase, ScreenHandlerPromptToolkitApplication


from aiosmb import logger as smblogger
from msldap import logger as ldaplogger


SMB_CLIENT_TYPES = ['SMB', 'SMB2', 'SMB3', 'SMBQ']
LDAP_CLIENT_TYPES = ['LDAP', 'LDAPS']
KERBEROS_CLIENT_TYPES = ['KERBEROS']


class OctoPwnInteractive(ClientConsoleBase):
	def __init__(self, screen_handler:ScreenHandlerBase, work_dir:str = None, periodic_save:bool = True):
		ClientConsoleBase.__init__(self, 0, None, None, None, 'MAIN', self)
		self.aliases['q'] = 'quit'
		self.aliases['s'] = 'switchclient'
		self.aliases['ap'] = 'addproxy'
		self.aliases['at'] = 'addtarget'
		self.aliases['st'] = 'settarget'
		self.aliases['ac'] = 'addcred'
		self.aliases['cc'] = 'createclient'
		self.aliases['cs'] = 'createscanner'
		self.aliases['cu'] = 'createutil'
		self.aliases['cl'] = 'createserver'
		#self.aliases['ccu'] = 'createclienturl'
		self.nologon_commands.append('any')
		self.prompt = '>>> '

		self.screen_handler:ScreenHandlerBase = screen_handler
		self.work_dir = work_dir
		self.periodic_save = periodic_save

		self.out_file = None
		self.session_file = None
		self.restore_clients:Dict[int, ClientConfigBase] = {}
		self.restore_clientmessages:Dict[int, List[str]] = {}
		
		self.__save_task = None
		self.main_stopped_evt = None
		
		self.clients:Dict[int, Tuple[ClientConfigBase, ClientConsoleBase]] = {}
		self.client_messages = {}
		self.__current_client = None
		self.__current_client_id = 0
		self.__client_msg_queue = None
		self.client_ctr = 1
		
		self.__file_handle = None
		if self.work_dir is not None:
			self.out_file = os.path.join(self.work_dir, 'octopwn.log')
			self.session_file = os.path.join(self.work_dir, 'octopwn.session')
			self.__file_handle = open(self.out_file, 'a')

		self.dcip = None #automatically gets added on target creation
		self.realm = None #automatically gets added on target creation
		self.credentials:Dict[int, Credential] = {}
		self.targets:Dict[int, Target] = {}
		self.proxies:Dict[int, Proxy] = {}

		self.current_credid = 0
		self.current_targetid = 0
		self.current_proxyid = 0
		self.current_client_ctr = 1 # must start at one!

		self.scannertypes_hint = ['smbfile', 'smbfinger', 'smbadmin', 'smbsession', 'smbiface', 'smbproto', 'rdpscreen']
		self.clienttypes_hint = ['smb', 'smb2', 'smb3', 'smbq', 'ldap', 'ldaps', 'kerberos']
		self.utiltypes_hint = ['pypykatz']

	def _cs_completions(self):
		return self._createscanner_completions()

	def _createscanner_completions(self):
		return SMBPathCompleter(get_current_dirs = self.getscannerhints)
	
	def getscannerhints(self):
		return self.scannertypes_hint
	
	def _cc_completions(self):
		return self._createclient_completions()

	def _createclient_completions(self):
		return SMBPathCompleter(get_current_dirs = self.getclienthints)
	
	def getclienthints(self):
		return self.clienttypes_hint
	
	def _cu_completions(self):
		return self._createutil_completions()

	def _createutil_completions(self):
		return SMBPathCompleter(get_current_dirs = self.getutilhints)
	
	def getutilhints(self):
		return self.utiltypes_hint
	
	async def print(self, msg = ''):
		"""
		this is to hook the parent class' print.
		should only be used by this class
		"""
		await self.print_main_window(msg)
	
	def cwd(self, new_rootpath):
		"""Changes the root directory (!not workdir!) It is useful for file downloads"""
		os.chdir(new_rootpath)
	
	@staticmethod
	def load(filename, screen_handler:ScreenHandlerBase, work_dir:str = None, periodic_save:bool = True):
		# restores the object from a TOML file
		with gzip.open(filename, 'rb') as f:
			session = OctoPwnSessionFile.from_toml(f.read().decode())

		if os.path.exists(session.work_dir) is False:
			print('The work directory referenced in the session file doesn\'t exists. Using current path as work directory.')
			session.work_dir = './'
		res = OctoPwnInteractive(screen_handler, work_dir = session.work_dir if work_dir is None else work_dir, periodic_save=periodic_save)
		res.dcip = session.dcip
		res.realm = session.realm
		for tid in session.proxies:
			res.proxies[tid] = session.proxies[tid]
			res.current_proxyid += 1
		for tid in session.credentials:
			res.credentials[tid] = session.credentials[tid]
			res.current_credid += 1
		for tid in session.targets:
			res.targets[tid] = session.targets[tid]
			res.current_targetid += 1
		
		for tid in session.clients:
			if tid == 0:
				continue
			res.restore_clients[tid] = session.clients[tid][0]
		
		for tid in session.messagebuffers:
			res.restore_clientmessages[int(tid)]= session.messagebuffers[tid]
		return res

	async def __periodic_save(self):
		try:
			while True:
				await asyncio.sleep(10)
				try:
					if self.__file_handle is not None:
						self.__file_handle.flush()
						self.__file_handle.close()
						self.__file_handle = open(self.out_file, 'a')

					if self.session_file is not None:
						self.do_save(sessionfilename = self.session_file+'.temp', to_print=False)
					#await self.__client_msg_queue.put((0,'Session saved!'))
				
				except Exception as e:
					await self.__client_msg_queue.put((0,'Save failed! Reason: %s' % traceback.format_tb(e.__traceback__)))

		except Exception as e:
			await self.print_exc(e)
		
	async def print_main_window(self, msg:str, store_file:bool = True):
		await self.screen_handler.print_main_window(msg)
		
		if self.__current_client_id == 0:
			self.client_messages[self.__current_client_id].append(msg)
		if self.__file_handle is not None and store_file is True:
			now = gtt()
			for line in msg.split('\n'):
				line = line.strip()
				outline = '0 [%s] %s\r\n' % (now, line)
				self.__file_handle.write(outline)
	
	def prettyclient(self, credid, targetid):
		target = self.targets[int(targetid)]
		cred = self.credentials[int(credid)]
		domain = cred.domain
		if cred.domain is None:
			domain = '.'
		return '%s\\%s@%s' % (domain, cred.username, target.get_hostname_or_ip())
	
	async def do_winsetup(self, to_print = True):
		"""Automatically adds target and creds. (Windows only)
Please note that creds will only be useful when selecting SSPI-NTLM or SSPI-KERBEROS auth
"""
		try:
			from winacl.functions.highlevel import get_logon_info
			import socket
			if to_print is True:
				await self.print_main_window('Setting default credentials and DC')
			logoninfo = get_logon_info()
			ud = '%s\\%s' % (logoninfo['domain'], logoninfo['username'])
			hostname = '%s.%s' % (logoninfo['logonserver'], logoninfo['dnsdomainname'])
			#dcip = socket.gethostbyname(hostname)
			await self.do_addcred(ud, '<SSPI>', 'SSPI')
			await self.do_addtarget(hostname, None,  None, hostname, hostname)

			return True, None
		except Exception as e:
			if to_print is True:
				await self.print_exc(e, extra_msg='Setting default credentials and DC. Is this a domin-joined PC?')
			return None, e
	
	def do_quit(self):
		"""Exits application"""
		self.screen_handler.abort(None)
	
	def do_save(self, sessionfilename = None, to_print = True):
		"""Saves current session as file"""
		session = OctoPwnSessionFile(self)
		if sessionfilename is None or len(sessionfilename)==0:
			sessionfilename = self.session_file
		with gzip.open(sessionfilename, 'wb') as f:
			f.write(session.to_toml().encode())
		
		if to_print is True:
			self.print_sync('Session saved!')
	
	async def do_exctest(self):
		try:
			raise Exception('TEST')
		except Exception as e:
			await self.print_exc(e, extra_msg='Setting default credentials and DC. Is this a domin-joined PC?')

	def get_credid(self):
		t = self.current_credid
		self.current_credid += 1
		return t
	
	def get_targetid(self):
		t = self.current_targetid
		self.current_targetid += 1
		return t
	
	def get_proxyid(self):
		t = self.current_proxyid
		self.current_proxyid += 1
		return t
	
	def get_clientid(self, force_cid:int = None):
		if isinstance(force_cid, int) is False:
			if isinstance(force_cid, str) and len(force_cid) > 0:
				force_cid = int(force_cid)
			else:
				force_cid = None

		if force_cid is None:
			t = self.current_client_ctr
			self.current_client_ctr += 1
		else:
			t = force_cid
			if t < self.current_client_ctr:
				self.current_client_ctr += 1
			else:
				self.current_client_ctr = t + 1
		return t

	async def do_changeworkdir(self, dirpath):
		try:
			self.work_dir = dirpath
			if self.__file_handle is not None:
				self.__file_handle.flush()
				self.__file_handle.close()
			self.out_file = os.path.join(self.work_dir, 'octopwn.log')
			self.session_file = os.path.join(self.work_dir, 'octopwn.session')
			self.__file_handle = open(self.out_file, 'a')
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to chenge workdir!')

	async def do_log(self, filename = None):
		"""Changes (or creates) the current log file"""
		try:
			oldlogfile = self.out_file
			if filename is None or len(filename) == 0:
				filename = 'octopwn.log'
				if self.work_dir is not None:
					filename = os.path.join(self.work_dir, filename)
			self.out_file = filename
			if self.__file_handle is not None:
				self.__file_handle.close()
			
			self.__file_handle = open(self.out_file, 'a')

		except Exception as e:
			self.print_exc(e, extra_msg='Failed to chenge log file!')
			self.out_file = oldlogfile
			if self.out_file is not None:
				self.__file_handle = open(self.out_file, 'a')
	
	
	async def do_refreshcreds(self):
		"""Refreshes the credentials window"""
		try:
			await self.screen_handler.refresh_credentials()
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to refresh credentials')

	async def addcredential_obj(self, credential:Credential):
		try:
			tid = self.get_credid()
			self.credentials[tid] = credential
			await self.print('New credential added! ID: %s' % tid)
			await self.screen_handler.credential_added(tid, credential)
			await self.do_refreshcreds()
			return tid, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add credential')
			return None, e

	async def do_addcred(self, username_with_domain:str, secret:str, secrettype:str = 'password', certfile:str = None, keyfile:str = None):
		"""Adds a new credential
WARINIG: special characters need to be correctly escaped!
You can double-check the correct value with the 'describe' command

Parameters:
  username_with_domain (str): Example: TEST\\\\Administrator
  secret (str)    : Authentication secret. Value depends on 'secrettype'
  secrettype (str): Type of secret specified in 'secret'. Dafult: password

Accepted values for 'secrettype':
  PASSWORD : the 'secret' is a plaintext password
  NT       : the 'secret' is an NT hash of a plaintext password
  RC4      : the 'secret' is an NT hash of a plaintext password
  AES(XXX) : the 'secret' is a long-term kerberos key of type AES.
             XXX can be omitted or '128' or '256'
  KEYTAB   : the 'secret' is a path to a .keytab file
  CCACHE   : the 'secret' is a path to a .ccache file
  PFX/P12  : the 'username_with_domain' is an alternative domain/user 
                 (if not needed, just use '' -empty string-)
             'secret' is the password for the file 
			 'certfile' must be pointing to the .pem/.p12 file
  PEM:     : the 'username_with_domain' is an alternative domain/user 
                  (if not needed, just use '' -empty string-)
             'secret' is the password for the file 
             'certfile' must be pointing to the .pem file
             'keyfile' must be pointing to the .pem file
  CERTSTORE: -notyet- 
  
"""
		try:
			domain = None
			username = username_with_domain
			if username_with_domain.find('\\') != -1:
				domain, username = username_with_domain.split('\\', 1)
			cred = Credential(username, secret, secrettype, domain, certfile = certfile, keyfile = keyfile)
			tid, err = await self.addcredential_obj(cred)
			if err is not None:
				raise err

			return tid, cred, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add credential')
			return None, None, e
	
	async def do_refreshtargets(self):
		"""Refreshes the targets window"""
		try:
			await self.screen_handler.refresh_targets()
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to refresh targets')

	async def addtarget_obj(self, target:Target, to_print=True):
		try:
			tid = self.get_targetid()
			self.targets[tid] = target
			if to_print is True:
				await self.print('New target added! ID: %s' % tid)
			await self.screen_handler.target_added(tid, target)
			await self.do_refreshtargets()
			return tid, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add target')
			return None, e

	async def do_addtarget(self, ip, port = None, dcip = None, realm = None, hostname=None, to_print=True):
		"""Adds a new target.
Warning! 'hostname' and 'dcip' is mandatory for kerberos authentication!

Parameters:
  ip (str): Type of the object to describe
  port (int): Port of the destination service. Optional.
  dcip (str): IP address of the Domain Controller. Optional.
  realm (str): Realm of the host. Optional
  hostname (str): Hostname of target. Preferably FQDN. Optional.
"""
		try:
			if ip == '':
				ip = None
			if to_print == '':
				to_print = False
			if port == '':
				port = None
			if hostname == '':
				hostname = None
			if dcip == '':
				dcip = None
			if realm == '':
				realm = None
			if dcip is None:
				dcip = self.dcip
			if realm is None:
				realm = self.realm
			if ip is None and hostname is None:
				raise Exception('Either IP or Hostname must be supplied!')
			try:
				ipaddress.ip_address(ip)
			except:
				if hostname is None:
					hostname = ip
					ip = hostname
			target = Target(ip, hostname, port, dcip, realm)
			tid, err = await self.addtarget_obj(target, to_print)
			if err is not None:
				raise err

			return tid, target, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add target')
			return None, None, e
	
	async def do_dcip(self, dcip = None, to_print=True):
		"""Gets or sets the IP address of the domain controller which will be used while adding targets"""
		try:
			if dcip is not None and dcip != '':
				self.dcip = dcip
			if to_print is True:
				await self.print("Default DC IP: %s" % self.dcip)
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to set dcip')
			return None, e

	async def do_realm(self, realm = None, to_print=True):
		"""Gets or sets the default realm which will be used while adding targets"""
		try:
			if realm is not None and realm != '':
				self.realm = realm
			if to_print is True:
				await self.print("Default realm: %s" % self.realm)
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to set realm')
			return None, e
		

	async def do_deltarget(self, tid):
		"""Removes target from targets list"""
		try:
			self.targets[int(tid)].hidden = True
			await self.do_refreshtargets()

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to delete target')
			return None, e
	
	async def do_delcred(self, tid):
		"""Removes credential from credentials list"""
		try:
			self.credentials[int(tid)].hidden = True
			await self.do_refreshcreds()

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to delete credential')
			return None, e
	
	async def do_settarget(self, targetid:int, param:str, value:Any, to_print:bool = True, to_refresh:bool = True):
		"""Changes an arbitrary variable on the given target. 
This is useful to change parameters (especially the 'dcip') after target has been created.

Parameters:
  targetid (int): ID of the Target object to be changed
  param (str): Name of the variable of the Target object to be changed
  value (any): The updated value
"""
		try:
			targetid = int(targetid)
			if targetid not in self.targets:
				await self.print('Unknown targetid!')
				return
			
			if not hasattr(self.targets[targetid], param):
				await self.print('Target doesn\'t have attribute named "%s"' % param)
				return
			setattr(self.targets[targetid], param, value)
			if to_print is True:
				await self.print('Updated target looks like this: %s' % self.targets[targetid].__dict__)
			if to_refresh is True:
				await self.do_refreshtargets()

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to change target param!')
		
	
	async def do_refreshproxyies(self):
		"""Refreshes the proxy window"""
		try:
			await self.screen_handler.refresh_proxies()
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to refresh proxies')
	
	async def do_refresh(self):
		try:
			await self.do_refreshtargets()
			await self.do_refreshcreds()
			await self.do_refreshproxyies()
			await self.do_refreshclients()
		except Exception as e:
			await self.print_exc(e)

	async def do_describe(self, cmd:str, tid:int, to_print:bool=True):
		"""Prints data about the object (cred or target or proxy)
Parameters:
  cmd (str): Type of the object to describe
  tid (str): ID of the object to describe

Accepted values for 'cmd':
  CRED  : The 'tid' references a Credential object
  TARGET: The 'tid' references a Target object
  PROXY : The 'tid' references a Proxy or Proxychain object
"""
		try:
			res = None
			cmd = cmd.lower()
			tid = int(tid)
			if cmd.startswith('cred') is True:
				if tid not in self.credentials:
					raise Exception('Credential with id "%s" not found' % tid)
				res = str(self.credentials[tid])
			elif cmd.startswith('target') is True:
				if tid not in self.targets:
					raise Exception('Target with id "%s" not found' % tid)
				res = str(self.targets[tid])
			elif cmd.startswith('proxy') is True:
				if tid not in self.proxies:
					raise Exception('Proxy with id "%s" not found' % tid)
				res = str(self.proxies[tid])
			else:
				res = "Unknown object type '%s'." % cmd
			
			if to_print is True:
				await self.print(res)

			return res, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Describe failed')
			return None, e

	async def addproxy_obj(self, proxy:Proxy):
		try:
			tid = self.get_proxyid()
			self.proxies[tid] = proxy
			await self.print('New proxy added! ID: %s' % tid)
			await self.screen_handler.proxy_added(tid, proxy)
			await self.do_refreshproxyies()

			return tid, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add proxy')
			return None, e
	
	async def do_addproxy(self, ptype:str, ip:str, port:int, agentid:str = None):
		"""Adds a new proxy
Parameters:
  ptype   (str): Proxy protocol type
  ip      (str): IP of the proxy server
  port    (int): Port of the proxy server
  agentid (str): Agentid. Optional.

Accepted values for 'ptype':
  SOCKS5
  SOCKS4
  SOCKS4A
  HTTP
  HTTPS
  WSNET
  WSSNET
  WSNETWS
"""
		try:
			if agentid == '':
				agentid = None
			target = Proxy(ptype, ip, port, agentid=agentid)
			tid, err = await self.addproxy_obj(target)
			if err is not None:
				raise err
			return tid, target, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add proxy')
			return None, None, e
	
	async def do_addproxychain(self, chainid:int, proxyid:int):
		"""Adds a proxy to a proxy chain
Parameters:
  chainid (int): ID of the Proxychain object
  proxyid (int): ID of the Proxy to be added to the chain
"""
		try:
			chainid = int(chainid)
			proxyid = int(proxyid)
			if chainid not in self.proxies:
				await self.print('Chain doesnt exist!')
				return False, None
			if proxyid not in self.proxies:
				await self.print('Proxy doesnt exist!')
				return False, None
			chain = self.proxies[chainid]
			if chain.ptype.upper() != 'CHAIN':
				await self.print('Selected chain is in fact a proxy!')
				return False, None
			chain.chain.append(proxyid)
			await self.do_refreshproxyies()
			await self.print('Proxy "%s" has been added to chain "%s"' % (chainid, proxyid))
			return True, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add proxy to chain!')
			return None, e
	
	async def do_createchain(self, description:str = None):
		"""Creates a new Proxy chain"""
		try:
			pid = self.get_proxyid()
			self.proxies[pid] = ProxyChain(description)
			await self.do_refreshproxyies()
			await self.print('Chain "%s" has been created' % pid)
			return pid, self.proxies[pid], None
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to add proxy to chain!')
			return None, None, e
	
	async def do_refreshclients(self):
		"""Refreshes the clients window"""
		try:
			await self.screen_handler.refresh_clients()
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to refresh clients')

	async def do_createscanner(self, scannertype:str, description:str = None, force_cid:int = None):
		"""Creates a new scanner instance.
Parameters:
  scannertype (str): Scanner type

Accepted values for 'scannertype':
  SMBFINGER : Scans targets for OS type and version
  SMBFILE   : Enumerates all shares/folders/files on targets
  SMBADMIN  : Tries to guess wether the user is admin on the targets
  SMBSESSION: Enumerates smb sessions on the target
  SMBPRINTNIGHTMARE: Checks if target is vulnerable to printnightmare
  SMBIFACE  : Enumerates all network interfaces on target
  SMBPROTO  : SMB protocol and NTLM signing flags enum
  RDPSCREEN : RDP screenshot scanner
  RDPLOGIN  : RDP login scanner
  RDPCAP    : RDP capabilities scanner
"""
		try:
			scannertype = scannertype.upper()
			if scannertype not in OCTOPWN_SCANNER_TABLE:
				await self.print('CreateScanner: Unknown scanner type %s' % scannertype)
				return None, Exception('CreateScanner: Unknown scanner type %s' % scannertype)

			scannerobj = OCTOPWN_SCANNER_TABLE[scannertype]
			clid = self.get_clientid(force_cid)
			clientname = '[SCANNER/%s]' % scannertype
			prompt = '[%s][%s] '% (clid, scannertype)
			cmd_q = asyncio.Queue()
			client = scannerobj(clid, None, cmd_q, self.__client_msg_queue, prompt, self)
			client_settings = ScannerConfig(scannertype, clientname, client.make_completer(), description)
			client.load_settings(client_settings)
			_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
			if err is not None:
				raise err

			client_task, err = await client.run()
			if err is not None:
				raise err
				
			self.client_messages[clid] = []
			self.clients[clid] = (client_settings, client)
			await self.print('New scanner "%s" created with ID "%s"' % (scannertype, clid))
			await self.do_refreshclients()
			return clid, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Create client failed!')
			return None, e

	async def do_createserver(self, stype:str, description:str = None, force_cid:int = None):
		"""Creates a new server instance.
Parameters:
  stype (str): Server type

Accepted values for 'ctype':
  LLMNR : LLMNR
  NBTNS : NBTNS
  MDNS  : MDNS

"""
		try:
			utype = stype.upper()
			if utype not in OCTOPWN_SERVER_TABLE:
				raise Exception('Unknwon util type "%s"' % utype)
			
			serverobj = OCTOPWN_SERVER_TABLE[utype]
			clid = self.get_clientid(force_cid)
			clientname = '[SERVER/%s]' % utype
			prompt = '[%s][%s] '% (clid, utype)
			cmd_q = asyncio.Queue()
			client = serverobj(clid, None, cmd_q, self.__client_msg_queue, prompt, self)
			client_settings = ServerConfig(utype, clientname, client.make_completer(), description)
			client.load_settings(client_settings)
			_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
			if err is not None:
				raise err
			client_task, err = await client.run()
			if err is not None:
				raise err
				
			self.client_messages[clid] = []
			self.clients[clid] = (client_settings, client)
			await self.print('New util "%s" created with ID "%s"' % (utype, clid))
			await self.do_refreshclients()
			return clid, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Create util failed!')
			return None, e
		

	async def do_createutil(self, utype:str, description:str = None, force_cid:int = None):
		"""Creates a new utility instance.
Parameters:
  utype (str): Utility type

Accepted values for 'ctype':
  PYPYKATZ : LSASS parsing and cryptographic functions
  DPAPI    : Decryptor functions for DPAPI
  JACKDAW  : Jackdaw

"""
		try:
			utype = utype.upper()
			if utype not in OCTOPWN_UTIL_TABLE:
				raise Exception('Unknwon util type "%s"' % utype)
			
			utilobj = OCTOPWN_UTIL_TABLE[utype]
			clid = self.get_clientid(force_cid)
			clientname = '[UTIL/%s]' % utype
			prompt = '[%s][%s] '% (clid, utype)
			cmd_q = asyncio.Queue()
			client = utilobj(clid, None, cmd_q, self.__client_msg_queue, prompt, self)
			client_settings = UtilsConfig(utype, clientname, client.make_completer(), description)
			client.load_settings(client_settings)
			_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
			if err is not None:
				raise err
			
			client_task, err = await client.run()
			if err is not None:
				raise err
				
			self.client_messages[clid] = []
			self.clients[clid] = (client_settings, client)
			await self.print('New util "%s" created with ID "%s"' % (utype, clid))
			await self.do_refreshclients()
			return clid, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Create util failed!')
			return None, e

	async def do_getdescription(self, otype:str, oid:str, to_print:bool = True):
		"""This is just for a test..."""
		try:
			otype = otype.lower()
			oid = int(oid)
			res = ''
			if otype.startswith('tar') is True:
				target = self.targets[oid]
				res = target.description
			elif otype.startswith('cre') is True:
				cred = self.credentials[oid]
				res = cred.description
			elif otype.startswith('pro') is True:
				proxy = self.proxies[oid]
				res = proxy.description
			elif otype.startswith('cli') is True:
				client_settings = self.clients[oid][0]
				res = client_settings.description
			else:
				raise Exception('Unknown object type! %s' % otype)
			
			if to_print is True:
				if res is not None:
					await self.print(res)
				else:
					await self.print('empty')
			return res, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Change description failed!')
			return None, e
		
	async def do_changedescription(self, otype:str, oid:str, description:str):
		"""Changes the description text for client/target/credential/proxy"""
		try:
			otype = otype.lower()
			oid = int(oid)
			if otype.startswith('tar') is True:
				target = self.targets[oid]
				target.description = description
				await self.do_refreshtargets()
			elif otype.startswith('cre') is True:
				cred = self.credentials[oid]
				cred.description = description
				await self.do_refreshcreds()
			elif otype.startswith('pro') is True:
				proxy = self.proxies[oid]
				proxy.description = description
				await self.do_refreshproxyies()
			elif otype.startswith('cli') is True:
				client_settings = self.clients[oid][0]
				client_settings.description = description
				await self.do_refreshclients()
			else:
				raise Exception('Unknown object type! %s' % otype)

			return True, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Change description failed!')
			return None, e

	async def do_createclient(self, ctype:str, atype:str, credid:int, targetid:int, proxyid:int = None, description:str = None, force_cid:int = None):
		"""Creates a new client of a specific type and authentication method. 
You must create at least one Credential and one Target before using this, 
Proxy is optional.

Parameters:
  ctype    (str): Client type
  atype    (str): Authentication type
  credid   (int): ID of the Credential which will be used for authentication
  targetid (int): ID of the Target which will be used to connect to.
  proxyid  (int): ID of the Proxy to be used to reach the target

Accepted values for 'ctype':
  SMB  : SMB client, defaults to SMB3 (on pyodide SMB2)
  SMB2 : SMB client which uses version 2 of the SMB protocol
  SMB3 : SMB client which uses version 3 of the SMB protocol
  SMBQ : SMB client which uses version 2 + connection layer is QUIC
  LDAP : LDAP client
  LDAPS: LDAP client which will use SSL/TLS
  KERBEROS: Kerberos client
  RDP: RDP client
  VNC: VNC client
  NC/NETCAT: Netcat TCP client

Accepted values for 'atype':
  Accepted values depends on the client type and the Credential used!
  For SMB:
    NTLM: Uses the NTLM authentication protocol.
        Compatible credential types:
          Password/NT/RC4
    KERBEROS: Uses the Kerberos authentication protocol.
        Compatible credential types:
          Password/NT/RC4/AES/AES128/AES256/PFX/CERTFILE/CERTSTORE/PEM/KEYTAB/CCACHE
    SSPI: Uses the integrated auth on Windos.

  For LDAP and LDAPS:
    SIMPLE: Uses plaintext auth method
        Compatible credential types:
          Password
    SICILY: Uses SICILY (old NTLM) auth method
        Compatible credential types:
          Password/NT/RC4
    NTLM: Uses the GSSAPI/NTLM authentication protocol.
        Compatible credential types:
          Password/NT/RC4
    KERBEROS: Uses the GSSAPI/Kerberos authentication protocol.
        Compatible credential types:
          Password/NT/RC4/AES/AES128/AES256/PFX/CERTFILE/CERTSTORE/PEM/KEYTAB/CCACHE
    SSPI: Uses the integrated auth on Windos.

  For Kerberos (standalone client):
        Compatible credential types:
          Password/NT/RC4/AES/AES128/AES256/PFX/CERTFILE/CERTSTORE/PEM/KEYTAB/CCACHE
  For RDP:
    Generic rule: for RDP you will need to have plaintext password.
    If not using Password then the client will attempt logging in via
    restricted mode, but this isn't always allowed

	PLAIN: Uses the old RDP protocol with plaintext password
    NTLM: Uses the CREDSSP/NTLM authentication protocol.
        Compatible credential types:
          Password/NT/RC4
    KERBEROS: Uses the CREDSSP/Kerberos authentication protocol.
        Compatible credential types:
          Password/NT/RC4/AES/AES128/AES256/PFX/CERTFILE/CERTSTORE/PEM/KEYTAB/CCACHE
  For VNC:
    For VNC you will need to have plaintext password, or no password

	PLAIN: Uses the DES based authentication as described in the RFC
	NONE: Tries to authenticate without password
  For NetCat:
    NONE: must be set to none
"""
		try:			
			timeout = 5
			if platform.system().lower() == 'emscripten' and (proxyid == '' or proxyid is None):
				# automatically adding wsnet proxy if user forgot to add it
				proxyid = 0
				timeout = 10
			if proxyid == '':
				proxyid = None
			if proxyid is not None:
				proxyid = int(proxyid)
			
			targetid = int(targetid)
			if credid is None or ( isinstance(credid, str) and credid.upper().startswith('ANON') is True):
				credid = None
			else:
				credid = int(credid)

			if credid not in self.credentials and credid is not None:
				await self.print('Unknown credid!')
				return None, Exception('Unknown credid!')
			credential = None
			if credid is not None:
				credential = self.credentials[credid]
			if targetid not in self.targets:
				await self.print('Unknown targetid!')
				return None, Exception('Unknown targetid!')
			target = self.targets[targetid]
			proxy = None
			if proxyid is not None and proxyid not in self.proxies:
				await self.print('Unknown proxyid!')
				return None, Exception('Unknown proxyid!')
			if proxyid is not None:
				proxy = self.proxies[proxyid]
			
			
			ctype = ctype.upper()
			atype = atype.upper().replace('-','_')
			if ctype.startswith('SMB'):
				if ctype != 'SMBEXPLORER':
					if ctype == 'SMBQ':
						proto = SMBConnectionDialect.SMB2
						connproto = SMBConnectionProtocol.QUIC
					else:
						if ctype == 'SMB':
							ctype = 'SMB2' # only use SMB3 when explicitly asked for!
						proto = SMBConnectionDialect(ctype)
						connproto = SMBConnectionProtocol.TCP
				else:
					proto = SMBConnectionDialect.SMB2
					connproto = SMBConnectionProtocol.TCP
				
				smbtarget = target.get_smb_target(proxy, timeout)
				smbtarget.protocol = connproto
				smbtarget.update_dialect(proto)

				if proxy is not None:
					smbtarget = proxy.get_smb_proxy(smbtarget, self.proxies)
				
				if ctype != 'SMBEXPLORER':
					connection = credential.get_smb_connection(SMBAuthProtocol(atype), smbtarget)
					clientname = '[SMB/%s] %s@%s' % (atype, credential.to_simple_line(), target.to_line())
					clid = self.get_clientid(force_cid)
					prompt = '[%s][SMB] %s'% (clid, self.prettyclient(credid, targetid))
					cmd_q = asyncio.Queue()
					client = SMBClient(clid, connection, cmd_q, self.__client_msg_queue, prompt, self)
				else:
					connection = credential.get_smb_connection(SMBAuthProtocol(atype), smbtarget)
					clientname = '[SMBEXPLORER/%s] %s@%s' % (atype, credential.to_simple_line(), target.to_line())
					clid = self.get_clientid(force_cid)
					prompt = '[%s][SMBEXPLORER] '% (clid, self.prettyclient(credid, targetid))
					cmd_q = asyncio.Queue()
					client = SMBExplorer(clid, connection, cmd_q, self.__client_msg_queue, prompt, self)
				client_settings = ClientConfig(ctype, atype, targetid, credid, proxyid, clientname, client.make_completer(), description)
				_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
				if err is not None:
					raise err

				client_task, err = await client.run()
				if err is not None:
					raise err
				
				self.client_messages[clid] = []
				self.clients[clid] = (client_settings, client)
				
			elif ctype in LDAP_CLIENT_TYPES:
				if ctype == 'LDAP':
					ldapprotocol = LDAPProtocol.TCP
				elif ctype == 'LDAPS':
					ldapprotocol = LDAPProtocol.SSL
				
				ldaptarget = target.get_ldap_target(proxy, timeout, ldapprotocol)
				if proxy is not None:
					ldaptarget = proxy.get_ldap_proxy(ldaptarget, self.proxies)

				connection = credential.get_ldap_connection(atype, ldaptarget)

				clientname = '[%s/%s] %s@%s' % (ctype, atype, credential.to_simple_line(), target.to_line())
				clid = self.get_clientid(force_cid)
				prompt = '[%s][%s] %s'% (clid, ctype, self.prettyclient(credid, targetid))
				cmd_q = asyncio.Queue()
				client = LDAPClient(clid, connection, cmd_q, self.__client_msg_queue, prompt, self)
				client_settings = ClientConfig(ctype, atype, targetid, credid, proxyid, clientname, client.make_completer(), description)
				_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
				if err is not None:
					raise err

				client_task, err = await client.run()
				if err is not None:
					raise err
				
				self.client_messages[clid] = []
				self.clients[clid] = (client_settings, client)

			elif ctype in KERBEROS_CLIENT_TYPES:
				kerberostarget = target.get_kerberos_target(proxy, timeout)
				if proxy is not None:
					kerberostarget = proxy.get_kerberos_proxy(kerberostarget, self.proxies)
				kerberoscredential = credential.get_kerberos_cred()
				connection = (kerberostarget, kerberoscredential)
				clientname = '[%s/%s] %s@%s' % (ctype, atype.upper(), credential.to_simple_line(), target.to_line())
				clid = self.get_clientid(force_cid)
				prompt = '[%s][%s] %s'% (clid, ctype, self.prettyclient(credid, targetid))
				cmd_q = asyncio.Queue()
				client = KerberosClient(clid, connection, cmd_q, self.__client_msg_queue, prompt, self)
				client_settings = ClientConfig(ctype, atype, targetid, credid, proxyid, clientname, client.make_completer(), description)
				_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
				if err is not None:
					raise err

				client_task, err = await client.run()
				if err is not None:
					raise err
				
				self.client_messages[clid] = []
				self.clients[clid] = (client_settings, client)
			
			elif ctype in ['RDP', 'VNC']:
				if ctype == 'RDP':
					ctarget = target.get_rdp_target(proxy, timeout)
					ctarget.dialect = RDPConnectionDialect.RDP
					if proxy is not None:
						ctarget = proxy.get_rdp_proxy(ctarget, self.proxies)
					ccredential = credential.get_rdp_cred(RDPAuthProtocol(atype), ctarget)

				else:
					ctarget = target.get_vnc_target(proxy, timeout)
					ctarget.dialect = RDPConnectionDialect.VNC
					if proxy is not None:
						ctarget = proxy.get_rdp_proxy(ctarget, self.proxies)
					ccredential = credential.get_vnc_cred(RDPAuthProtocol(atype), ctarget)
				
				connection = (ctarget, ccredential)
				clientname = '[%s/%s] %s@%s' % (ctype, atype.upper(), credential.to_simple_line(), target.to_line())
				clid = self.get_clientid(force_cid)
				prompt = '[%s][%s] %s' % (clid, ctype, self.prettyclient(credid, targetid))
				cmd_q = asyncio.Queue()
				client = RDPClient(clid, connection, cmd_q, self.__client_msg_queue, prompt, self)
				client_settings = ClientConfig(ctype, atype, targetid, credid, proxyid, clientname, client.make_completer(), description)
				_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
				if err is not None:
					raise err

				client_task, err = await client.run()
				if err is not None:
					raise err
				
				self.client_messages[clid] = []
				self.clients[clid] = (client_settings, client)
			
			elif ctype in ['NC', 'NETCAT']:
				ctarget = copy.deepcopy(target)
				if ctarget.port is None:
					raise Exception('NetCat requires a target with port specified! Create a new target for the port you wish to connect to!')
				ctarget.proxy = None
				if proxy is not None:
					ctarget.proxy = proxy.get_generic_proxy(ctarget, ctarget.port, self.proxies)
				
				connection = [ctarget, None]
				clientname = '[%s/%s] %s@%s' % (ctype, atype.upper(), '', target.to_line())
				clid = self.get_clientid(force_cid)
				prompt = '[%s][%s] %s' % (clid, ctype, targetid)
				cmd_q = asyncio.Queue()
				client = NetCatClient(clid, connection, cmd_q, self.__client_msg_queue, prompt, self)
				client_settings = ClientConfig(ctype, atype, targetid, credid, proxyid, clientname, client.make_completer(), description)
				_, err = await self.screen_handler.create_client_window(clid, prompt, client_settings, client)
				if err is not None:
					raise err

				client_task, err = await client.run()
				if err is not None:
					raise err
				
				self.client_messages[clid] = []
				self.clients[clid] = (client_settings, client)

			else:
				await self.print('CreateClient: Unknown client type %s' % ctype)
				return None, Exception('CreateClient: Unknown client type %s' % ctype)
			
			await self.print('New client "%s" created with ID "%s"' % (ctype, clid))
			await self.do_refreshclients()

			return clid, None

		except Exception as e:
			await self.print_exc(e, extra_msg='Create client failed!')
			return None, e



	async def do_switchclient(self, client_id:int):
		"""Changes the current clinet INPUT and OUTPUT window to another one"""
		try:
			if self.screen_handler.multi_window_support is True:
				await self.print('SwitchClient is not supported on multi-window supporting screens.')
				return
			client_id = int(client_id)
			if client_id not in self.clients:
				await self.print('Unknown client!')
				return
			await self.print('Switching to client %s' % client_id)
			if client_id == 0:
				# main menu
				self.__current_client_id = 0
				self.__current_client_settings = None
				self.__current_client = None
				await self.screen_handler.clear_main_window()
				self.screen_handler.input_area.completer = self.make_completer()
				msg = '\n'.join(self.client_messages[self.__current_client_id])
				await self.print(msg)
				await self.screen_handler.set_input_dialog_title(0, 'PROMPT')
				await self.screen_handler.set_message_dialog_title(self.__current_client_id, 'MAIN')
			else:
				self.__current_client_settings, self.__current_client = self.clients[client_id]
				self.__current_client_id = client_id
				self.screen_handler.input_area.completer = self.__current_client_settings.completer
				await self.screen_handler.clear_main_window()
				msg = '\n'.join(self.client_messages[self.__current_client_id])
				await self.print(msg)
				await self.screen_handler.set_input_dialog_title(self.__current_client_id, self.__current_client.prompt)
				await self.screen_handler.set_message_dialog_title(self.__current_client_id, self.__current_client_settings.clientname)
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to switch to client %s' % client_id)
		
	def get_ldap_url(self, cid, tid, proto:LDAPProtocol = LDAPProtocol.TCP, authtype:str = 'NTLM', pid:int = None, wsnet_reuse:bool = False, timeout:int = 5):
		"""Creates a valid LDAP url object using the credential/target/proxy id and uth types supplied"""
		try:
			target = self.targets[tid]
			cred = self.credentials[cid]
			proxy = None
			if pid is not None:
				proxy = copy.deepcopy(self.proxies[pid])
				proxy.wsnet_reuse = wsnet_reuse

			ldaptarget = target.get_ldap_target(proxy, timeout, proto)
			if proxy is not None:
				ldaptarget = proxy.get_ldap_proxy(ldaptarget, self.proxies)
			
			ldapcredential = cred.get_ldap_cred(authtype, ldaptarget)
			ldap_url = MSLDAPURLDecoder(None, ldapcredential, ldaptarget)
			return ldap_url, None
		except Exception as e:
			return None, e
	
	def get_smb_url_dummy(self, cid, authtype:SMBAuthProtocol = SMBAuthProtocol.NTLM ,pid = None, wsnet_reuse = False, timeout = 5):
		"""Retruns an SMB url object with invalid target, but working credentials. This can act as a template for creating actual targets on-demand during scan"""
		try:
			cred = self.credentials[cid]
			proxy = None
			if pid is not None:
				proxy = copy.deepcopy(self.proxies[pid])
				proxy.wsnet_reuse = wsnet_reuse

			target = SMBTarget('999.999.999.999')
			target.timeout = timeout

			if proxy is not None:
				tproxy = copy.deepcopy(proxy)
				tproxy.wsnet_reuse = True
				target = tproxy.get_smb_proxy(target, self.proxies)
			
			credential = cred.get_smb_cred(authtype, target)
			smb_url = SMBConnectionURL(None, credential, target)
			return smb_url, None
		
		except Exception as e:
			return None, e
	
	def get_smb_url(self, cid:int, tid:int, authtype:SMBAuthProtocol = SMBAuthProtocol.NTLM, pid:int = None, wsnet_reuse:bool = False, timeout = 5):
		"""Creates a valid SMB url object using the credential/target/proxy id and uth types supplied"""
		try:
			target = self.targets[tid].get_smb_target(timeout=timeout)
			cred = self.credentials[cid]
			proxy = None
			if pid is not None:
				proxy = copy.deepcopy(self.proxies[pid])
				proxy.wsnet_reuse = wsnet_reuse

			if proxy is not None:
				tproxy = copy.deepcopy(proxy)
				tproxy.wsnet_reuse = True
				target = tproxy.get_smb_proxy(target, self.proxies)
			
			credential = cred.get_smb_cred(authtype, target)
			smb_url = SMBConnectionURL(None, credential, target)
			return smb_url, None
		
		except Exception as e:
			return None, e
	
	def get_kerberos_url(self, cid:int, tid:int, pid:int = None, wsnet_reuse:bool = False, timeout:int= 5):
		"""Creates a valid Kerberos url object using the credential/target/proxy id and uth types supplied"""
		try:
			target = self.targets[tid].get_kerberos_target(timeout=timeout)
			cred = self.credentials[cid]
			proxy = None
			if pid is not None:
				proxy = copy.deepcopy(self.proxies[pid])
				proxy.wsnet_reuse = wsnet_reuse

			if proxy is not None:
				tproxy = copy.deepcopy(proxy)
				tproxy.wsnet_reuse = True
				target = tproxy.get_kerberos_proxy(target, self.proxies)
			
			credential = cred.get_kerberos_cred()
			kerberos_url = KerberosClientURL(target, credential)
			return kerberos_url, None
		
		except Exception as e:
			return None, e

	async def do_winauto(self):
		try:
			if platform.system() != 'Windows':
				raise Exception('auto mode only works on windows!')
			from winacl.functions.highlevel import get_logon_info
			logon = get_logon_info()
			if logon['domain'] == '' or logon['logonserver'] == '':
				if logon['domain'] == '':
					logon['domain'] = os.environ['USERDOMAIN']
				if logon['logonserver'] == '':
					logon['logonserver'] = os.environ['LOGONSERVER'].replace('\\','')

				if logon['domain'] == '' or logon['logonserver'] == '':
					raise Exception("Failed to find user's settings! Is this a domain user?")
			
			await self.do_dcip(logon['logonserver'])
			await self.do_realm(logon['domain'])
			await self.do_addtarget(logon['logonserver'])

			user = '%s\\%s' % (logon['domain'], logon['username'])
			await self.do_addcred(user, '<CURRENT>', 'SSPI')
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_wsnetauto(self):
		"""Sets DC/realm and credential using WSNET"""
		try:
			if platform.system() != 'Emscripten':
				raise Exception('This mode only works in the browser!')
			from wsnet.pyodide.clientinfo import WSNETClientInfo
			ig = WSNETClientInfo()
			logon, err = await ig.get_info()
			if err is not None:
				raise err
			
			await self.do_dcip(logon.logonserver)
			await self.do_realm(logon.domain)
			await self.do_addtarget(logon.logonserver)

			user = logon.username
			if logon.domain is not None and logon.domain != '':
				user = '%s\\%s' % (logon.domain, logon.username)
			
			await self.do_addcred(user, '<CURRENT>', 'WSNET')
		
		except Exception as e:
			await self.print_exc(e)
			return None, e
		

	async def client_changeprompt_cb(self, client_id, newprompt):
		try:
			if self.screen_handler.multi_window_support is False:
				if client_id == self.__current_client_id:
					await self.screen_handler.set_input_dialog_title(client_id, '%s' % newprompt)
			else:
				await self.screen_handler.set_input_dialog_title(client_id, '%s' % newprompt)
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to change to client prompt %s' % client_id)

	def input_handler(self, in_buffer, clientid = None):
		try:
			if isinstance(in_buffer, str):
				cmd = in_buffer
			else:
				#print(in_buffer)
				cmd = in_buffer.text
			if cmd == '':
				return False

			if clientid is not None:
				if cmd[0] == '!' or clientid == 0:
					if cmd[0] == '!':
						cmd = cmd[1:]
					if len(cmd) < 1:
						return False
					command, *args = shlex.split(cmd)
					asyncio.create_task(self.clients[0][1]._run_single_command(command, args))
					return False
				
				self.clients[clientid][1].cmd_q.put_nowait(cmd)
				return False

			else:
				if cmd[0] == '!' or self.__current_client_id == 0:
					if cmd[0] == '!':
						cmd = cmd[1:]
					if len(cmd) < 1:
						return False
					command, *args = shlex.split(cmd)
					asyncio.create_task(self.clients[0][1]._run_single_command(command, args))
					return False
				elif self.__current_client is not None:
					#because this function can't be async :((((((((
					self.__current_client.cmd_q.put_nowait(cmd)
				
				else:
					self.print_sync('Unknown command %s' % cmd)

			return False #false signals that the text area should be cleared
		except Exception as e:
			self.print_exc_sync(e, extra_msg='input_handler')
	

	async def __handle_client_msg_in(self):
		try:
			while True:
				client_id, msg = await self.__client_msg_queue.get()
				try:					
					if client_id not in self.client_messages:
						await self.print_main_window('ClientID %s not recognized as a valid client!' % repr(client_id))
						continue
					self.client_messages[client_id].append(msg)
					if self.__file_handle is not None:
						outline = '%s [%s] %s\r\n' % (client_id, gtt(), msg)
						self.__file_handle.write(outline)
					if self.screen_handler.multi_window_support is False and client_id == self.__current_client_id:
						await self.print_main_window(msg)
						#self.message_area.document._cursor_position += 1
					else:
						_, err = await self.screen_handler.print_client_msg(client_id, msg)
						if err is not None:
							raise err
				except Exception as e:
					traceback.print_exc()
					await self.print_main_window('Failed to parse client message. Reason: %s' % e)
		
		except Exception as e:
			await self.print_main_window('ERROR! __handle_client_msg_in is dead now. Reason: %s' % e)
			return None, e
	
	async def run(self):
		try:
			#logger.setLevel(1)
			#authlogger.setLevel(100)
			kerblogger.setLevel(100)
			smblogger.setLevel(100)
			ldaplogger.setLevel(100)
			self.main_stopped_evt = asyncio.Event()
			self.__client_msg_queue = asyncio.Queue()
			self.clients[0] = (None, self)
			self.__current_client = self
			self.client_messages[0] = []

			screen_task, err = await self.screen_handler.run(self, self.input_handler)
			if err is not None:
				raise err
			
			asyncio.create_task(self.__handle_client_msg_in())
			for ctid in self.restore_clients:
				clientconfig = self.restore_clients[ctid]
				if clientconfig.config_type == 'NORMAL':
					clientconfig = typing.cast(ClientConfig, clientconfig)
					tid, err = await self.do_createclient(
						clientconfig.connection_type,
						clientconfig.authentication_type,
						clientconfig.credential_id,
						clientconfig.target_id,
						clientconfig.proxy_id,
						clientconfig.description,
						force_cid=int(ctid)
					)
					if err is not None:
						raise err

				elif clientconfig.config_type == 'SCANNER':
					clientconfig = typing.cast(ScannerConfig, clientconfig)
					tid, err = await self.do_createscanner(clientconfig.scanner_type, clientconfig.description, force_cid=int(ctid))
					if err is not None:
						raise err
					
					self.clients[tid][1].load_config(clientconfig)
				
				elif clientconfig.config_type == 'SERVER':
					clientconfig = typing.cast(ServerConfig, clientconfig)
					tid, err = await self.do_createserver(clientconfig.scanner_type, clientconfig.description, force_cid=int(ctid))
					if err is not None:
						raise err
					
					self.clients[tid][1].load_config(clientconfig)
				
				elif clientconfig.config_type == 'UTILS':
					clientconfig = typing.cast(UtilsConfig, clientconfig)
					tid, err = await self.do_createutil(clientconfig.scanner_type, clientconfig.description, force_cid=int(ctid))
					if err is not None:
						raise err

					self.clients[tid][1].load_config(clientconfig)
				else:
					await self.print_main_window('Unknown client config! %s' % clientconfig.config_type)
			
			for tid in self.restore_clientmessages:
				self.client_messages[tid] = self.restore_clientmessages[tid]
				if self.screen_handler.multi_window_support is True:
					# here we have to re-print the client messages
					if tid in self.restore_clientmessages:
						try:
							_, err = await self.screen_handler.print_client_msg(tid, '\n'.join(self.restore_clientmessages[tid]))
							if err is not None:
								raise err
						except Exception as e:
							await self.print_exc(e)
							await self.print('Failed to restore messages for tid "%s"' % tid)
					else:
						if tid != 0:
							await self.print("resote client non-existent tid which is not zero!!!")

			self.screen_handler.input_area.completer = self.make_completer()
			await self.do_refresh()
			if self.periodic_save is True:
				self.__save_task = asyncio.create_task(self.__periodic_save())
			
			return self.main_stopped_evt, None
		except Exception as e:
			traceback.print_exc()
			return None, e

	

async def amain(args):
	try:
		screen = ScreenHandlerPromptToolkitApplication()
		if args.sessionfile is not None:
			console = OctoPwnInteractive.load(args.sessionfile, screen)
		else:
			if args.no_outfile is True:
				args.workdir = None
			console = OctoPwnInteractive(screen, args.workdir)
		octopwn_stopped_evt, err = await console.run()
		if err is not None:
			raise err
		await octopwn_stopped_evt.wait()
	except Exception as e:
		traceback.print_exc()

def main():
	import argparse
	import logging
	
	parser = argparse.ArgumentParser(description='Octopwn')
	parser.add_argument('-n', '--no-outfile', action='store_true', help='Disable output file creation. Pls dont use this.')
	parser.add_argument('-w', '--workdir', default='./', help='Directory to save output files to.')
	parser.add_argument('-s', '--sessionfile', help='Reload saved session')
	
	args = parser.parse_args()
	asyncio.run(amain(args))

if __name__ == '__main__':
	main()