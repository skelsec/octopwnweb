from typing import Dict, List, Tuple
import copy
from aiosmb.commons.connection.proxy import SMBProxy, SMBProxyType
from aiosmb.commons.connection.target import SMBTarget
from asysocks.common.constants import SocksServerVersion
from asysocks.common.clienturl import SocksClientURL
from minikerberos.common.proxy import KerberosProxy
from minikerberos.common.target import KerberosTarget
from msldap.commons.target import MSLDAPTarget
from msldap.commons.proxy import MSLDAPProxy, MSLDAPProxyType
from aardwolf.commons.target import RDPTarget, RDPConnectionProtocol
from aardwolf.commons.proxy import RDPProxy, RDPProxyType



class Proxy:
	def __init__(self, ptype:str, ip:str, port:int = None, username:str = None, password:str = None, agentid:str = None, wsreuse:bool = False, description:str = None):
		self.ptype = ptype #socks4,socks5, socks4a, http
		self.ip = ip
		self.port = port
		self.username = username
		self.password = password
		self.agentid = agentid
		self.wsnet_reuse = wsreuse
		self.description = description
	
	def __str__(self):
		t = ''
		for k in self.__dict__:
			t += '%s: %s\r\n' % (k, self.__dict__[k])
		return t
	
	@staticmethod
	def from_dict(d:dict):
		ptype = d['ptype']
		ip = d['ip']
		port = None
		if 'port' in d:
			port = int(d['port'])

		username = None
		if 'username' in d:
			username = d['username']
		
		password = None
		if 'password' in d:
			password = d['password']
		
		agentid = None
		if 'agentid' in d:
			agentid = d['agentid']
		
		description = None
		if 'description' in d:
			description = d['description']

		return Proxy(ptype, ip, port, username, password, agentid, description)
	
	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	def to_line(self):
		return "(%s) %s:%s" % (self.ptype, self.ip, self.port)
	
	def to_asysocks(self, endpoint_ip, endpoint_port):
		p = SocksClientURL()
		p.version = SocksServerVersion(self.ptype.upper())
		p.server_ip = self.ip
		p.server_port = int(self.port)
		p.endpoint_ip = endpoint_ip
		p.endpoint_port = int(endpoint_port)
		p.agentid = self.agentid
		p.wsnet_reuse = self.wsnet_reuse
		return p
	
	def get_smb_proxy(self, target:SMBTarget, octoproxies):
		proxy = SMBProxy()
		proxy.auth = None
		proxy.type = SMBProxyType(self.ptype.upper())
		proxy.target = [self.to_asysocks(target.get_ip(), int(target.port)).get_target()]

		target.proxy = proxy

		return target
	
	def get_ldap_proxy(self, target:MSLDAPTarget, octoproxies):
		proxy = MSLDAPProxy()
		proxy.auth = None
		proxy.type = MSLDAPProxyType(self.ptype.upper())
		proxy.target = [self.to_asysocks(target.host, int(target.port)).get_target()]

		target.proxy = proxy

		return target
	
	def get_kerberos_proxy(self, target:KerberosTarget, octoproxies):
		target.proxy = KerberosProxy([self.to_asysocks(target.ip, int(target.port)).get_target()], None, type='SOCKS')
		return target
	
	def get_rdp_proxy(self, target:RDPTarget, octoproxies):
		proxy = RDPProxy()
		proxy.auth = None
		proxy.type = RDPProxyType.ASYSOCKS
		proxy.target = [self.to_asysocks(target.get_ip(), int(target.port)).get_target()]

		target.proxy = proxy

		return target
	
	def get_generic_proxy(self, hostname_or_ip:str, port:int, octoproxies):
		return [self.to_asysocks(hostname_or_ip, int(port)).get_target()]
	
class ProxyChain:
	def __init__(self, description:str = None):
		self.ptype = 'CHAIN'
		self.chain = []
		self.wsnet_reuse = False
		self.description = description
	
	def __str__(self):
		t = 'ProxyChain'
		for item in self.chain:
			t += '%s: %s\r\n' % (item, str(item))
		return t
	
	@staticmethod
	def from_dict(d:dict):
		ptype = d['ptype']
		chain = []
		if 'chain' in d:
			chain = d['chain']
		
		description = None
		if 'description' in d:
			description = d['description']

		res = ProxyChain(description)
		res.chain = chain
		return res
	
	def to_line(self):
		return "(%s) [%s]" % (self.ptype, ','.join([str(cid) for cid in self.chain]))
	
	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	def resolve_proxies(self, octoproxies:Dict[int, Proxy]) -> Tuple[List[Proxy], Proxy]:
		proxies = []
		for chain in self.chain:
			proxies.append(copy.deepcopy(octoproxies[int(chain)]))
		
		asyproxies = []
		for i, proxy in enumerate(proxies[:-1]):
			asyproxies.append(proxy.to_asysocks(proxies[i+1].ip, proxies[i+1].port).get_target())

		proxies[-1] = copy.deepcopy(proxies[-1])
		proxies[-1].wsnet_reuse = self.wsnet_reuse
		return asyproxies, proxies[-1]

	def get_smb_proxy(self, target:SMBTarget, octoproxies:Dict[int, Proxy]):
		asyproxies, last_proxy = self.resolve_proxies(octoproxies)
		asyproxies.append(last_proxy.to_asysocks(target.get_ip(), int(target.port)).get_target())
		
		proxy = SMBProxy()
		proxy.auth = None
		proxy.type = SMBProxyType(SMBProxyType.SOCKS5) # here the type doesnt matter because it's a chain that already contains all types
		proxy.target = asyproxies

		target.proxy = proxy

		return target
	
	def get_ldap_proxy(self, target:MSLDAPTarget, octoproxies:Dict[int, Proxy]):
		asyproxies, last_proxy = self.resolve_proxies(octoproxies)
		asyproxies.append(last_proxy.to_asysocks(target.host, int(target.port)).get_target())

		proxy = MSLDAPProxy()
		proxy.auth = None
		proxy.type = MSLDAPProxyType.SOCKS5
		proxy.target = asyproxies

		target.proxy = proxy

		return target
	
	def get_kerberos_proxy(self, target:KerberosTarget, octoproxies:Dict[int, Proxy]):
		asyproxies, last_proxy = self.resolve_proxies(octoproxies)
		asyproxies.append(last_proxy.to_asysocks(target.ip, int(target.port)).get_target())

		target.proxy = KerberosProxy(asyproxies, None, type='SOCKS')
		return target
	
	def get_rdp_proxy(self, target:RDPTarget, octoproxies:Dict[int, Proxy]):
		asyproxies, last_proxy = self.resolve_proxies(octoproxies)
		asyproxies.append(last_proxy.to_asysocks(target.ip, int(target.port)).get_target())

		proxy = RDPProxy()
		proxy.type = RDPProxyType.ASYSOCKS
		proxy.target = asyproxies

		target.proxy = proxy

		return target

	def get_generic_proxy(self, hostname_or_ip:str, port:int, octoproxies:Dict[int, Proxy]):
		asyproxies, last_proxy = self.resolve_proxies(octoproxies)
		asyproxies.append(last_proxy.to_asysocks(hostname_or_ip, int(port)).get_target())
		return asyproxies
