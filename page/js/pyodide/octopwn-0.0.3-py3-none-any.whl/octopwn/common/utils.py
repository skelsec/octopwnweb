from email.mime import base
import platform
import datetime
import ipaddress
import os


def gtt():
	return datetime.datetime.utcnow().isoformat(' ', 'seconds')

def don(x, default='-'):
	if x is not None:
		return str(x)
	return default

def isint(x):
	try:
		x = int(x)
		return True
	except:
		return False

def isip(x):
	try:
		ipaddress.ip_address(x)
		return True
	except:
		return False
	
def isipnet(x):
	try:
		ipaddress.ip_network(x)
		return True
	except:
		return False

def chunker(seq, size):
	return (seq[pos:pos + size] for pos in range(0, len(seq), size))

# https://gist.github.com/ImmortalPC/c340564823f283fe530b
def hexdump(src, length=16, sep='.', offset = 0):
	"""
	Pretty printing binary data blobs
	:param src: Binary blob
	:type src: bytearray
	:param length: Size of data in each row
	:type length: int
	:param sep: Character to print when data byte is non-printable ASCII
	:type sep: str(char)
	:param offset: Start offset of the data to print
	:type offset: int
	:return: str
	"""
	result = []

	for i in range(0, len(src), length):
		subSrc = src[i:i+length]
		hexa = ''
		isMiddle = False
		for h in range(0,len(subSrc)):
			if h == length/2:
				hexa += ' '
			h = subSrc[h]
			if not isinstance(h, int):
				h = ord(h)
			h = hex(h).replace('0x', '')
			if len(h) == 1:
				h = '0'+h
			hexa += h+' '
		hexa = hexa.strip(' ')
		text = ''
		for c in subSrc:
			if not isinstance(c, int):
				c = ord(c)
			if 0x20 <= c < 0x7F:
				text += chr(c)
			else:
				text += sep
		result.append(('%08X:  %-'+str(length*(2+1)+1)+'s  |%s|') % (i+offset, hexa, text))

	return '\n'.join(result)


def create_table(lines, separate_head=True):
	"""Creates a formatted table given a 2 dimensional array"""
	#Count the column width
	widths = []
	for line in lines:
			for i,size in enumerate([len(x) for x in line]):
					while i >= len(widths):
							widths.append(0)
					if size > widths[i]:
							widths[i] = size
	   
	#Generate the format string to pad the columns
	print_string = ""
	for i,width in enumerate(widths):
			print_string += "{" + str(i) + ":" + str(width) + "} | "
	if (len(print_string) == 0):
			return
	print_string = print_string[:-3]
	
	res = []
	#Print the actual data
	for i,line in enumerate(lines):
			res.append(print_string.format(*line))
			if (i == 0 and separate_head):
					res.append("-"*(sum(widths)+3*(len(widths)-1)))
	return '\n'.join(res)

def create_random_file(basename = None, ext = 'txt'):
	if basename is None:
		return '%s.%s' % (os.urandom(4).hex(), ext)
	return '%s_%s.%s' % (basename, os.urandom(4).hex(), ext)

def create_random_filepath(basedir = None, basename = None, ext = 'txt'):
	filename = create_random_file(basename, ext)
	if basedir is not None:
		filepath = '%s/%s' % (basedir, basename)
	
	else:
		filepath = filename
		if platform.system() == 'Emscripten':
			filepath = '/volatile/%s' % filename
	
	return filepath

def sizeof_fmt(num, suffix="B"):
    for unit in ["", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi"]:
        if abs(num) < 1024.0:
            return f"{num:3.1f}{unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f}Yi{suffix}"