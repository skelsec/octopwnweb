import base64
from aiosmb.commons.connection.target import SMBTarget
from aiosmb.commons.connection.authbuilder import AuthenticatorBuilder as SMBAuthBuilder
from aiosmb.connection import SMBConnection
from msldap.commons.credential import MSLDAPCredential, LDAPAuthProtocol
from msldap.commons.target import MSLDAPTarget
from msldap.connection import MSLDAPClientConnection
from minikerberos.common.creds import KerberosCredential, KerberosSecretType
from aiosmb.commons.connection.credential import SMBCredential, SMBAuthProtocol, SMBCredentialsSecretType
from aardwolf.commons.credential import RDPCredentialTypes, RDPCredentialsSecretType, RDPAuthProtocol, RDPCredential
from aardwolf.commons.target import RDPTarget

class Credential:
	def __init__(self, username:str, secret:str, stype:str, domain:str = None, certfile:str = None, keyfile:str = None, hidden:bool = False, certfiledata:str=None, keyfiledata:str=None, description:str = None):
		self.domain = domain
		self.username = username
		self.stype = stype #password/nt/rc4/aes/kirbi/...
		self.secret = secret
		self.hidden = hidden
		self.certfile = certfile
		self.keyfile = keyfile
		self.certfiledata = certfiledata
		self.keyfiledata = keyfiledata
		self.description = description

		if self.stype.lower() in ['pw', 'pass', 'password']:
			self.stype = 'password'
		
		if self.stype.lower() in ['pfx', 'p12']:
			if self.certfile is not None and self.certfiledata is None:
				with open(self.certfile, 'rb') as f:
					self.certfiledata = base64.b64encode(f.read()).decode()
			
			if self.keyfile is not None and self.keyfiledata is None:
				with open(self.keyfile, 'rb') as f:
					self.keyfiledata = base64.b64encode(f.read()).decode()
		
		### TODO: keytab/ccache/kirbi load!!!!

	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	def __str__(self):
		t = ''
		for k in self.__dict__:
			t += '%s: %s\r\n' % (k, self.__dict__[k])
		return t
	
	@staticmethod
	def from_dict(d:dict):
		username = d['username']
		secret = d['secret']
		stype = d['stype']
		hidden = d['hidden']
		domain = d.get('domain', None)
		certfile = d.get('certfile', None)
		keyfile = d.get('keyfile', None)
		certfiledata = d.get('certfiledata', None)
		keyfiledata = d.get('keyfiledata', None)
		description = d.get('description', None)

		return Credential(username, secret, stype, domain, certfile, keyfile, hidden, certfiledata, keyfiledata, description)

	def to_line(self, truncate = True):
		domain = self.domain
		if self.domain is None:
			domain = '.'
		secret = self.secret
		if truncate is True and len(secret) > 10:
			secret = self.secret[:4] + '<REDACTED>' + self.secret[-4:]
		return '(%s) %s\\%s:%s' % (self.stype, domain, self.username, secret)
	
	def to_simple_line(self):
		domain = self.domain
		if self.domain is None:
			domain = '.'
		secret = self.secret
		if len(secret) > 10:
			secret = self.secret[:4] + '<REDACTED>' + self.secret[-4:]
		return '%s\\%s:%s' % (domain, self.username, secret)
	
	def get_smb_cred(self, authtype:SMBAuthProtocol, target:SMBTarget = None, settings:dict = None):
		stype = None

		if target is not None:
			if target.domain is None:
				target.domain = self.domain
		
		dbstype = self.stype.upper()
		if dbstype in ['PW', 'PASSWORD', 'PASS']:
			stype = SMBCredentialsSecretType.PASSWORD
		elif dbstype in ['AES', 'AES128', 'AES256']:
			stype = SMBCredentialsSecretType.AES
		elif dbstype in ['KEYTAB']:
			stype = SMBCredentialsSecretType.KEYTAB
		elif dbstype in ['KIRBI']:
			stype = SMBCredentialsSecretType.KIRBI
		elif dbstype in ['PFX', 'P12']:
			stype = SMBCredentialsSecretType.PFXSTR
			altdomain = None
			altname = None
			if self.domain is not None and self.domain != '':
				altdomain = self.domain
			if self.username is not None and self.username != '':
				altname = self.username
			return SMBCredential(
				username = self.certfiledata,
				domain = self.domain,
				secret = self.secret,
				secret_type = stype,
				authentication_type = authtype,
				settings = settings,
				target = target,
				altname = altname,
				altdomain = altdomain
			)

		elif dbstype in ['PEM']:
			stype = SMBCredentialsSecretType.PEM
		elif dbstype in ['RC4', 'NT']:
			stype = SMBCredentialsSecretType.NT
		
		if authtype in [SMBAuthProtocol.SSPI_NTLM, SMBAuthProtocol.SSPI_KERBEROS]:	
			self.username = '<CURRENT>'
			self.secret = '<CURRENT>'
			stype = SMBCredentialsSecretType.NONE
		
		if authtype in [SMBAuthProtocol.WSNET_NTLM, SMBAuthProtocol.WSNET_KERBEROS]:	
			self.username = '<CURRENT>'
			self.secret = '<CURRENT>'
			stype = SMBCredentialsSecretType.NONE

		if stype is None:
			raise Exception('Couldnt figure out correct stype for customcred!')
		
		
		return SMBCredential(
			username = self.username,
			domain = self.domain,
			secret = self.secret,
			secret_type = stype,
			authentication_type = authtype,
			settings = settings,
			target = target
		)
	
	def get_smb_connection(self, authtype:SMBAuthProtocol, target:SMBTarget):
		credential = self.get_smb_cred(authtype,target)
		gssapi = SMBAuthBuilder.to_spnego_cred(credential, target)
		return SMBConnection(gssapi, target)
	
	def get_ldap_connection(self, authtype:str, target:MSLDAPTarget = None, settings:dict = None):
		credential = self.get_ldap_cred(authtype, target, settings)
		return MSLDAPClientConnection(target, credential)
	
	def get_ldap_cred(self, authtype:str, target:MSLDAPTarget = None, settings:dict = None):
		authproto = None
		authtype = authtype.upper()
		dbstype = self.stype.upper()
		if authtype in ['NTLM', 'SICILY']:
			if dbstype in ['PW', 'PASSWORD', 'PASS']:
				authproto = LDAPAuthProtocol.NTLM_PASSWORD
			elif dbstype == 'NT':
				authproto = LDAPAuthProtocol.NTLM_NT
		elif authtype == 'KERBEROS':
			if dbstype in ['PW', 'PASSWORD', 'PASS']:
				authproto = LDAPAuthProtocol.KERBEROS_PASSWORD
			elif dbstype in ['AES', 'AES128', 'AES256']:
				authproto = LDAPAuthProtocol.KERBEROS_AES
			elif dbstype in ['KEYTAB']:
				authproto = LDAPAuthProtocol.KERBEROS_KEYTAB
			elif dbstype in ['KIRBI']:
				authproto = LDAPAuthProtocol.KERBEROS_KIRBI
			elif dbstype in ['PFX', 'P12']:
				authproto = LDAPAuthProtocol.KERBEROS_PFXSTR
				altdomain = None
				altname = None
				if self.domain is not None and self.domain != '':
					altdomain = self.domain
				if self.username is not None and self.username != '':
					altname = self.username
				return MSLDAPCredential(
					domain = self.domain, 
					username = self.certfiledata, 
					password = self.secret, 
					auth_method = authproto, 
					settings = settings, 
					etypes = None, 
					encrypt = False, 
					altname = altname, 
					altdomain = altdomain
				)
			elif dbstype in ['PEM']:
				authproto = LDAPAuthProtocol.KERBEROS_PEM
			elif dbstype in ['NT', 'RC4']:
				authproto = LDAPAuthProtocol.KERBEROS_NT
		elif authtype == 'SSPI_NTLM':
			authproto = LDAPAuthProtocol.SSPI_NTLM
		elif authtype == 'SSPI_KERBEROS':
			authproto = LDAPAuthProtocol.SSPI_KERBEROS
		elif authtype == 'WSNET_NTLM':
			authproto = LDAPAuthProtocol.WSNET_NTLM
		elif authtype == 'WSNET_KERBEROS':
			authproto = LDAPAuthProtocol.WSNET_KERBEROS
		
		if authproto is None:
			raise Exception('Couldnt figure out correct stype for customcred!')
		
		return MSLDAPCredential(
			domain= self.domain, 
			username= self.username, 
			password = self.secret, 
			auth_method = authproto,
			settings = settings, 
			etypes = None, 
			encrypt = False
		)
	
	def get_kerberos_cred(self):
		stype = None
		dbstype = self.stype.upper()
		if dbstype in ['PW', 'PASSWORD', 'PASS']:
			kc = KerberosCredential()
			kc.domain = self.domain
			kc.username = self.username
			kc.add_secret(KerberosSecretType.PASSWORD, self.secret)
			return kc
		elif dbstype in ['RC4', 'NT']:
			kc = KerberosCredential()
			kc.domain = self.domain
			kc.username = self.username
			kc.add_secret(KerberosSecretType.RC4, self.secret)
			return kc
		elif dbstype in ['AES', 'AES128', 'AES256']:
			kc = KerberosCredential()
			kc.domain = self.domain
			kc.username = self.username
			kc.add_secret(KerberosSecretType.AES, self.secret)
			return kc
		elif dbstype in ['KEYTAB']:
			kc = KerberosCredential.from_keytab(self.secret)
			kc.domain = self.domain
			kc.username = self.username
			return kc
		elif dbstype in ['KIRBI']:
			kc = KerberosCredential.from_kirbi(self.secret, principal=self.username, realm=self.domain)
			return kc
		elif dbstype in ['PFX', 'P12']:
			# at this point it's just a b64 encoded string...
			kc = KerberosCredential.from_pfx_string(self.certfiledata, self.secret, username=self.username, domain=self.domain)
			return kc
		elif dbstype in ['PEM']:
			kc = KerberosCredential.from_pem_file(self.username, self.secret)
			return kc
		elif dbstype in ['SSPI', 'WSNET']:
			return None
		
		if stype is None:
			raise Exception('Couldnt figure out correct stype for customcred!')
	
	def get_rdp_cred(self, authtype:RDPAuthProtocol, target:RDPTarget = None, settings:dict = None):
		stype = None
		dbstype = self.stype.upper()
		if dbstype in ['PW', 'PASSWORD', 'PASS']:
			stype = RDPCredentialsSecretType.PASSWORD
		
		if authtype == RDPAuthProtocol.NTLM:
			if dbstype in ['RC4', 'NT']:
				stype = RDPCredentialsSecretType.NT

		if stype is None:
			raise Exception('Couldnt figure out correct stype for customcred!')
		
		if target is not None:
			if target.domain is None:
				target.domain = self.domain
		
		return RDPCredential(
			username = self.username,
			domain = self.domain,
			secret = self.secret,
			secret_type = stype,
			authentication_type = authtype,
			settings = settings,
			target = target
		)

	def get_vnc_cred(self, authtype:RDPAuthProtocol, target:RDPTarget = None, settings:dict = None):
		stype = None
		dbstype = self.stype.upper()
		if dbstype in ['PW', 'PASSWORD', 'PASS']:
			stype = RDPCredentialsSecretType.PASSWORD
		else:
			raise Exception('VNC only supports PASSWORD auth or None')
		
		secret = self.secret
		username = self.username

		if (self.secret is None or len(self.secret) == 0) and self.username is not None:
			secret = self.username
			username = None
		
		return RDPCredential(
			username = username,
			domain = None,
			secret = secret,
			secret_type = stype,
			authentication_type = authtype,
			settings = settings,
			target = target
		)
