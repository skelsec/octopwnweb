
class ClientConfigBase:
	def __init__(self, config_type:str, clientname:str, completer, description = None):
		self.config_type = config_type
		self.clientname = clientname
		self.completer = completer
		self.description = description
	
	def to_dict(self):
		raise NotImplementedError()

class ClientConfig(ClientConfigBase):
	def __init__(self, connection_type:str, authentication_type:str, target_id:int, credential_id:int, proxy_id:int, clientname, completer, description = None):
		ClientConfigBase.__init__(self, 'NORMAL', clientname, completer, description)
		self.connection_type = connection_type
		self.authentication_type = authentication_type
		self.target_id = target_id
		self.credential_id = credential_id
		self.proxy_id = proxy_id
		
	def to_dict(self):
		return {
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'connection_type' : self.connection_type,
			'authentication_type' : self.authentication_type,
			'target_id' : self.target_id,
			'credential_id' : self.credential_id,
			'proxy_id' : self.proxy_id,
			'description' : self.description,
		}
	
	@staticmethod
	def from_dict(d:dict):
		connection_type = d['connection_type']
		authentication_type = d['authentication_type']
		target_id = int(d['target_id'])
		credential_id = None
		if 'credential_id' in d:
			credential_id = int(d['credential_id'])
		proxy_id = None
		if 'proxy_id' in d:
			proxy_id = d['proxy_id']
		
		description = None
		if 'description' in d:
			description = d['description']

		return ClientConfig(connection_type, authentication_type, target_id, credential_id, proxy_id, '', None, description)

class ScannerConfig(ClientConfigBase):
	def __init__(self, scanner_type:str, clientname, completer, description = None):
		ClientConfigBase.__init__(self, 'SCANNER', clientname, completer, description)
		self.scanner_type = scanner_type
		self.params = {}
	
	def to_dict(self):
		return {
			'scanner_type' : self.scanner_type,
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'params' : self.params,
			'description' : self.description,
		}
	
	@staticmethod
	def from_dict(d:dict):
		scanner_type = None
		if 'scanner_type' in d:
			scanner_type = d['scanner_type']
		clientname = None
		if 'clientname' in d:
			clientname = d['clientname']
		
		description = None
		if 'description' in d:
			description = d['description']
		
		res = ScannerConfig(scanner_type, clientname, None, description)
		if 'params' in d:
			res.params = d['params']
		
		return res

class ServerConfig(ClientConfigBase):
	def __init__(self, scanner_type:str, clientname, completer, description = None):
		ClientConfigBase.__init__(self, 'SERVER', clientname, completer, description)
		self.scanner_type = scanner_type
		self.params = {}
	
	def to_dict(self):
		return {
			'scanner_type' : self.scanner_type,
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'params' : self.params,
			'description' : self.description,
		}
	
	@staticmethod
	def from_dict(d:dict):
		scanner_type = None
		if 'scanner_type' in d:
			scanner_type = d['scanner_type']
		clientname = None
		if 'clientname' in d:
			clientname = d['clientname']
		
		description = None
		if 'description' in d:
			description = d['description']
		
		res = ServerConfig(scanner_type, clientname, None, description)
		if 'params' in d:
			res.params = d['params']
		
		return res

class UtilsConfig(ClientConfigBase):
	def __init__(self, scanner_type:str, clientname, completer, description = None):
		ClientConfigBase.__init__(self, 'UTILS', clientname, completer, description)
		self.scanner_type = scanner_type
		self.params = {}
	
	def to_dict(self):
		return {
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'scanner_type' : self.scanner_type,
			'description': self.description,
			'params' : self.params,
		}
	
	@staticmethod
	def from_dict(d:dict):
		scanner_type = None
		if 'scanner_type' in d:
			scanner_type = d['scanner_type']
		
		description = None
		if 'description' in d:
			description = d['description']
		
		clientname = '???'
		if 'clientname' in d:
			clientname = d['clientname']

		res = UtilsConfig(scanner_type, clientname, None, description)
		if 'params' in d:
			res.params = d['params']
		return res