
import ipaddress
from aiosmb.commons.connection.target import SMBTarget, SMBConnectionProtocol
from msldap.commons.target import MSLDAPTarget, LDAPProtocol
from minikerberos.common.target import KerberosTarget, KerberosSocketType
from aardwolf.commons.target import RDPTarget, RDPConnectionProtocol

class Target:
	def __init__(self, ip:str, hostname:str = None, port:int = None, dcip:str = None, realm:str = None, hidden:bool = False, description:str=None):
		self.hostname = hostname
		self.ip = ip
		self.port = port
		self.dcip = dcip #for kerberos auth
		self.realm = realm
		self.hidden = hidden
		self.description = description
		self.isdc = None
	
	def __str__(self):
		t = ''
		for k in self.__dict__:
			t += '%s: %s\r\n' % (k, self.__dict__[k])
		return t

	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	@staticmethod
	def from_dict(d:dict):
		ip = None
		if 'ip' in d:
			ip = d['ip']
		hostname = None
		if 'hostname' in d:
			hostname = d['hostname']

		port = None
		if 'port' in d:
			port = d['port']
		
		dcip = None
		if 'dcip' in d:
			dcip = d['dcip']

		t = Target(ip, hostname, port, dcip)
		
		description = None
		if 'description' in d:
			t.description = d['description']
		
		isdc = None
		if 'isdc' in d:
			t.is_dc = bool(d['isdc'])
		
		hidden = False
		if 'hidden' in d:
			t.hidden = bool(d['hidden'])


		return t

	def get_hostname_or_ip(self):
		if self.hostname is not None:
			return self.hostname
		return self.ip

	def get_ip_or_hostname(self):
		if self.ip is not None:
			return self.ip
		return self.hostname

	def to_line(self):
		t = '%s' % self.get_hostname_or_ip()
		if self.port is not None:
			t += ':%s' % self.port
		if self.isdc is True:
			t += ' (DC)'
		return t

	def to_compact(self):
		def noem(x):
			if x is None or x == '':
				return None
			return x

		ip = noem(self.ip)
		host = noem(self.hostname)
		if host is None:
			addr = ip
		else:
			addr = host
			if ip is not None:
				addr += ' [%s]' % ip
		
		if self.port is not None:
			addr += ':%s' % self.port
		
		if self.isdc is True:
			addr += ' (DC)'
		
		return addr

	def get_smb_target(self, proxy = None, timeout = 1, domain = None) -> SMBTarget:
		ip = self.get_ip_or_hostname()
		hostname = self.get_hostname_or_ip()
		if ip is not None:
			try:
				ipaddress.ip_address(ip)
				ip = ip
				hostname = hostname
			except:
				ip = hostname
				hostname = hostname
		if hostname is not None:
			try:
				ipaddress.ip_address(hostname)
				ip = hostname
				hostname = None
			except:
				pass

		return SMBTarget(
			ip = ip,
			hostname = hostname, 
			timeout = timeout,
			dc_ip = self.dcip, 
			domain = domain if domain is not None else self.realm, # for kerberos
			proxy = proxy,
			protocol = SMBConnectionProtocol.TCP,
			path = None
		)
	
	def get_ldap_target(self, proxy = None, timeout = 1, protocol = LDAPProtocol.TCP, port = None, domain = None) -> MSLDAPTarget:
		if port is None:
			if protocol == LDAPProtocol.TCP:
				port = 389
			elif protocol == LDAPProtocol.SSL:
				port = 636
		
		res = MSLDAPTarget(
			self.get_hostname_or_ip(), 
			port = port, 
			proto = protocol, 
			dc_ip = self.dcip,
			#tree = None, 
			proxy = proxy, 
			timeout = timeout, 
			#ldap_query_page_size = 1000, 
			#ldap_query_ratelimit = 0
		)
		res.domain = domain if domain is not None else self.realm # for kerberos
		return res
	
	def get_kerberos_target(self, proxy = None, timeout = 1) -> KerberosTarget:
		kt = KerberosTarget()
		kt.ip = self.get_ip_or_hostname()
		kt.port = 88
		kt.protocol = KerberosSocketType.TCP
		kt.proxy = proxy
		kt.timeout = timeout
		return kt

	def get_rdp_target(self, proxy = None, timeout = 1, domain = None) -> RDPTarget:
		kt = RDPTarget()
		kt.ip = self.get_ip_or_hostname()
		kt.hostname = self.get_hostname_or_ip()
		kt.domain = domain if domain is not None else self.realm # for kerberos
		kt.port = self.port
		if self.port is None:
			kt.port = 3389
		kt.protocol = RDPConnectionProtocol.TCP
		kt.dc_ip = self.dcip
		kt.proxy = proxy
		kt.timeout = timeout
		return kt

	def get_vnc_target(self, proxy = None, timeout = 1) -> RDPTarget:
		# vnc and rdp are on the same interface
		target = self.get_rdp_target()
		if self.port is None:
			target.port = 5900
		return target