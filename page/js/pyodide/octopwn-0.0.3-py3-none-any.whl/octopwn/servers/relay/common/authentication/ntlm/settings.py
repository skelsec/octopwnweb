import json
import toml

class NTLMClientSettings:
	def __init__(self, signdisable:bool = False, dropmic:bool = False, dropmic2:bool = False):
		self.signdisable:bool = signdisable
		self.dropmic:bool = dropmic
		self.dropmic2:bool = dropmic2
		self.modify_negotiate_cb = None
		self.modify_challenge_cb = None
		self.modify_authenticate_cb = None
	
	def to_dict(self):
		t = {}
		for k in self.__dict__:
			val = self.__dict__[k]
			t[k] = val
		return t
	
	@staticmethod
	def from_keyword(keyword):
		# this is specifically for parsing command-line format
		d = {
			keyword : True
		}
		return NTLMClientSettings(**d)

	@staticmethod
	def from_dict(d):
		return NTLMClientSettings(**d)
	
	@staticmethod
	def from_json(x):
		return NTLMClientSettings.from_dict(json.loads(x))
	
	@staticmethod
	def from_toml(x):
		return NTLMClientSettings.from_dict(toml.loads(x))
	
	def to_toml(self):
		return toml.dumps(self.to_dict())
	
	def to_json(self):
		return json.dumps(self.to_dict())