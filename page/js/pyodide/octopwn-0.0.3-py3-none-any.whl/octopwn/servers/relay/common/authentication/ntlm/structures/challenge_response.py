import io

from aiosmb.commons.utils.ts2dt import *
from octopwn.servers.relay.common.authentication.ntlm.structures.avpair import AVPairs, AVPAIRType

# https://msdn.microsoft.com/en-us/library/cc236648.aspx
class LMResponse:
	def __init__(self):
		self.Response = None
		
	def to_bytes(self):
		return self.Response

	@staticmethod
	def from_bytes(bbuff):
		return LMResponse.from_buffer(io.BytesIO(bbuff))

	@staticmethod
	def from_buffer(buff):
		t = LMResponse()
		t.Response = buff.read(24)
		return t

	def __repr__(self):
		t  = '== LMResponse ==\r\n'
		t += 'Response: %s\r\n' % repr(self.Response)
		return t


# https://msdn.microsoft.com/en-us/library/cc236649.aspx
class LMv2Response:
	def __init__(self):
		self.Response = None
		self.ChallengeFromClinet = None
		
		
	def to_bytes(self):
		return self.Response + self.ChallengeFromClinet

	@staticmethod
	def from_bytes(bbuff):
		return LMv2Response.from_buffer(io.BytesIO(bbuff))

	@staticmethod
	def from_buffer(buff):
		t = LMv2Response()
		t.Response = buff.read(16)
		t.ChallengeFromClinet = buff.read(8)
		return t

	def __repr__(self):
		t  = '== LMv2Response ==\r\n'
		t += 'Response: %s\r\n' % repr(self.Response)
		t += 'ChallengeFromClinet: %s\r\n' % repr(self.ChallengeFromClinet)
		return t


# https://msdn.microsoft.com/en-us/library/cc236651.aspx
class NTLMv1Response:
	def __init__(self):
		self.Response = None
		
	def to_bytes(self):
		return self.Response

	@staticmethod
	def from_bytes(bbuff):
		return NTLMv1Response.from_buffer(io.BytesIO(bbuff))

	@staticmethod
	def from_buffer(buff):
		t = NTLMv1Response()
		t.Response = buff.read(24)
		return t

	def __repr__(self):
		t  = '== NTLMv1Response ==\r\n'
		t += 'Response: %s\r\n' % repr(self.Response)
		return t


# https://msdn.microsoft.com/en-us/library/cc236653.aspx
class NTLMv2Response:
	def __init__(self):
		self.Response:bytes = None
		self.ChallengeFromClinet:NTLMv2ClientChallenge = None
		
	def to_bytes(self):
		return self.Response + self.ChallengeFromClinet.to_bytes()

	@staticmethod
	def from_bytes(bbuff):
		return NTLMv2Response.from_buffer(io.BytesIO(bbuff))

	@staticmethod
	def from_buffer(buff):
		t = NTLMv2Response()
		t.Response = buff.read(16)
		t.ChallengeFromClinet = NTLMv2ClientChallenge.from_buffer(buff)

		return t

	def __repr__(self):
		t  = '== NTLMv2Response ==\r\n'
		t += 'Response           : %s\r\n' % repr(self.Response.hex())
		t += 'ChallengeFromClinet: %s\r\n' % repr(self.ChallengeFromClinet)
		return t

# https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-nlmp/aee311d6-21a7-4470-92a5-c4ecb022a87b
class NTLMv2ClientChallenge:
	def __init__(self):
		self.RespType:int   = 1
		self.HiRespType:int = 1
		self.Reserved1:int  = 0
		self.TimeStamp:bytes  = None #bytes! because of conversion error :(
		self.Reserved2:int  = 0
		self.ChallengeFromClient:bytes = None
		self.Reserved3:int  = 0
		self.Details:AVPairs    = None #named AVPairs in the documentation
		
		self.timestamp_dt = None
		self.raw_data = b''
	
	@staticmethod
	def construct(timestamp, client_challenge, details):
		"""
		timestamp: datetime.datetime
		client_challenge: 8 bytes
		details: AVPairs object
		"""
		cc = NTLMv2ClientChallenge()
		cc.TimeStamp = datetime2timestamp(timestamp)
		cc.ChallengeFromClient = client_challenge
		cc.Details = details
		cc.timestamp_dt = timestamp
		return cc
		
	def to_bytes(self):
		t  = self.RespType.to_bytes(1 , byteorder = 'little', signed = False)
		t += self.HiRespType.to_bytes(1 , byteorder = 'little', signed = False)
		t += self.Reserved1.to_bytes(6, byteorder = 'little', signed = False)
		t += self.TimeStamp
		t += self.ChallengeFromClient
		t += self.Reserved2.to_bytes(4, byteorder = 'little', signed = False)
		t += self.Details.to_bytes()
		t += self.Reserved3.to_bytes(4, byteorder = 'little', signed = False)
		
		return t

	@staticmethod
	def from_bytes(bbuff):
		return NTLMv2ClientChallenge.from_buffer(io.BytesIO(bbuff))

	@staticmethod
	def from_buffer(buff):
		pos = buff.tell()
		cc = NTLMv2ClientChallenge()
		cc.RespType   = int.from_bytes(buff.read(1), byteorder = 'little', signed = False)
		cc.HiRespType = int.from_bytes(buff.read(1), byteorder = 'little', signed = False)
		cc.Reserved1  = int.from_bytes(buff.read(6), byteorder = 'little', signed = False)
		cc.TimeStamp  = buff.read(8)
		cc.ChallengeFromClient = buff.read(8)
		cc.Reserved2  = int.from_bytes(buff.read(4), byteorder = 'little', signed = False)
		cc.Details    = AVPairs.from_buffer(buff) #referred to as ServerName in the documentation
		cc.Reserved3 = int.from_bytes(buff.read(4), byteorder='little', signed=False)
		cc.timestamp_dt = timestamp2datetime(cc.TimeStamp)

		pos_new = buff.tell()
		buff.seek(pos)
		cc.raw_data = buff.read(pos_new - pos)
		return cc

	def __repr__(self):
		t  = '== NTLMv2ClientChallenge ==\r\n'
		t += 'RespType           : %s\r\n' % repr(self.RespType)
		t += 'TimeStamp          : %s\r\n' % repr(self.timestamp_dt)
		t += 'ChallengeFromClient: %s\r\n' % repr(self.ChallengeFromClient.hex())
		t += 'Details            : %s\r\n' % repr(self.Details)
		return t
