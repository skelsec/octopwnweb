import asyncio

class TCPClient:
	def __init__(self, raddr, rport, reader, writer):
		self.raddr = raddr
		self.rport = rport
		self.reader = reader
		self.writer = writer
		self.out_queue = asyncio.Queue()
		self.in_queue = asyncio.Queue()
