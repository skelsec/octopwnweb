import platform
import asyncio
import traceback
import os
import copy

from octopwn.servers.smb.protocol.netbios import NetBIOSTransport
from octopwn.servers.smb.protocol.tcpconnection import TCPClient
from octopwn.servers.smb.protocol.serverconnection import SMBServerConnection

from octopwn.clients.scannerbase import ScannerConsoleBase

if platform.system().lower() == 'emscripten':
	from pyodide import to_js, create_proxy

class SMBServer(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'ip': (str, '0.0.0.0'),
			'port': (int, 445),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'proxy': (int, None),
			'resultsfile': (str, 'smb_server_%s.tsv' % os.urandom(4).hex()),
		}

		self.serverproto = None
		self.servertransport = None
		self.in_queue = None
		self.server_task = None

	async def start(self):
		return True, None
	
	async def handle_client(self, reader:asyncio.StreamReader, writer: asyncio.StreamWriter):
		try:
			raddr, rport = writer.get_extra_info('peername')
			await self.log_async(20, '[TCP] Client connected from %s:%s' % (raddr, rport))
			
			client = TCPClient(raddr, rport, reader, writer)
			out_task = asyncio.create_task(self.handle_outgoing(client))
			in_task = asyncio.create_task(self.handle_incoming(client))
			nbtransport = NetBIOSTransport(client)
			connection_settings = copy.deepcopy(self.settings)
			connection_settings.log_q = self.log_q
			connection_settings.client_ip   = raddr
			connection_settings.client_port = rport
			connection_settings.gssapi.setup(self.log_q)
			server = SMBServerConnection(connection_settings, nbtransport)

			
			await nbtransport.run()
			if self.server_queue is not None:
				await self.server_queue.put(('SMB', server))
			await server.run()
			await writer.drain()
			writer.close()
			await self.log_async(10, 'SMB server terminated, closing client! %s:%s' % (raddr, rport))
		except Exception as e:
			traceback.print_exc()
			await self.log_async(99, '[TCP] handle_client %s' % str(e))
		finally:
			if out_task is not None:
				out_task.cancel()
			if in_task is not None:
				in_task.cancel()


	async def socketsetup(self):
		try:
			if platform.system() == 'Emscripten':
				from wsnet.pyodide.tcpserver import WSNetworkTCPServer
				temp = WSNetworkTCPServer(
					self.handle_client,
					self.params['ip'][1],
					self.params['port'][1],
					bindtype = 1,
					reuse_ws = False
				)
				server, err = await temp.run()
				if err is not None:
					raise err

			if self.params['proxy'][1] is None:
				server = await asyncio.start_server(self.handle_client, self.params['ip'][1], self.params['port'][1])

			else:
				raise Exception('Proxy not yet supported!')
			return server, None
		except Exception as e:
			return None, e

	async def __server(self):
		try:
			server = await self.socketsetup()
			async with server:
				await self.print('SMB Server in listening state')
				await server.serve_forever()
			return True, None
		except Exception as e:
			await self.print('SMB server terminated')
			await self.print_exc(e)
			return False, None

	async def do_serve(self):
		try:
			self.in_queue = asyncio.Queue()
			res, err = await self.socketsetup()
			if err is not None:
				raise err
			self.server_task = asyncio.create_task(self.__server())
			await self.print('Server is running!')

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_stop(self):
		try:
			if self.server_task is not None:
				self.server_task.cancel()
			await self.print('Server stopped!')
		except Exception as e:
			await self.print_exc(e)
			return None, e
	