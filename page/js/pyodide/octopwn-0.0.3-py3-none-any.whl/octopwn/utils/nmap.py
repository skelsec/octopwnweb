
import platform
from pyndiff.ndiff import Scan, IPv4Address, IPv6Address, MACAddress


from octopwn.common.utils import don
from octopwn.clients.scannerbase import ScannerConsoleBase

class NmapUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.xmlfile = None
		self.scan = Scan()

	async def do_load(self, filepath):
		try:
			self.xmlfile = filepath
			self.scan = Scan()
			self.scan.load_from_file(self.xmlfile)
			await self.print('File loaded!')
		
		except Exception as e:
			await self.print_exc(e)
			return None, e


	def get_host_addr(self, host, addrtype='any'): #ipv4, ipv6, mac, any
		"""returns the first address for the given host of given addresstype"""
		if addrtype == 'any':
			addr = self.get_host_addr(host, 'ipv4')
			if addr is None:
				addr = self.get_host_addr(host, 'ipv6')
				if addr is None:
					addr = self.get_host_addr(host, 'mac')
			return addr
		
		for address in host.addresses:
			if isinstance(address, IPv4Address) and addrtype == 'ipv4':
				return str(address)
			if isinstance(address, IPv6Address) and addrtype == 'ipv6':
				return str(address)
			if isinstance(address, MACAddress) and addrtype == 'mac':
				return str(address)
	
	def ports_per_host(self, host):
		tports = []
		addr = self.get_host_addr(host)
		for port in host.ports:
			tp = [str(addr), don(port[0]), don(port[1]), don(host.ports[port].service.name), don(host.ports[port].service.version)]
			tports.append(tp)
		return tports
	
	async def do_hosts(self, to_print = True):
		"""Lists all hostnames from scanfile"""
		try:
			hostnames = []
			for host in self.scan.hosts:
				for hostname in host.addresses:
					hostnames.append(hostname)
					if to_print is True:
						await self.print(hostname)
			
			return hostnames, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_ips(self, to_print = True):
		"""Lists all hostnames from scanfile"""
		try:
			ips = {}
			for host in self.scan.hosts:
				ip = self.get_host_addr(host, 'ipv4')
				if ip is not None:
					ips[ip] = 1
				ip = self.get_host_addr(host, 'ipv6')
				if ip is not None:
					ips[ip] = 1

			if to_print is True:
				for ip in ips:
					await self.print(ip)

			return list(ips.keys()), None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_ports(self, to_print = True):
		"""Lists all IP:PORT entries found by NMAP"""
		try:
			ports = []
			for host in self.scan.hosts:
				for res in self.ports_per_host(host):
					ports.append('%s:%s' % (res[0], res[1]))

			if to_print is True:
				for x in ports:
					await self.print(x)
			return ports, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_services(self, to_print = True):
		"""Generates a table with all services found by NMAP"""
		try:
			services = [['addr', 'port', 'protocol', 'service', 'version']]
			for host in self.scan.hosts:
				for res in self.ports_per_host(host):
					services.append(res)

			if to_print is True:
				await self.print_table(services)
			return services, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def do_addtargets(self):
		"""Populates the target list in octopwn with the IP addresses found in this scan file"""
		try:
			addrs, err = await self.do_hosts(to_print=False)
			if err is not None:
				raise err
			for addr in addrs:
				await self.octopwnobj.do_addtarget(addr)


		except Exception as e:
			await self.print_exc(e)
			return None, e
		
