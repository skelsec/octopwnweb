import traceback
import asyncio
import json

from octopwn.common.utils import hexdump, create_random_file
from octopwn.clients.scannerbase import ScannerConsoleBase
from pypykatz import logger
from pypykatz.dpapi.dpapi import DPAPI

class DPAPIUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.params = {
			'prekeys' : (list, [], "Prekey CACHE"), #simple list of prekeys
			'masterkeys': (list, [], "Decrypted Masterkey Cache"), #list of string masterkeys in "GUID,KEY(hex)" format
		}
	
	def create_dpapi_masterkeys(self) -> DPAPI:
		if len(self.params['masterkeys'][1]) == 0:
			raise Exception('No masterkeys set!')
		dpapi = DPAPI()
		for x in self.params['masterkeys'][1]:
			guid, keyhex = x.split(',')
			dpapi.masterkeys[guid] = bytes.fromhex(keyhex)
		return dpapi

	async def do_clearprekeys(self):
		"""Clears the prekey cache"""
		try:
			self.params['prekeys'][1] = []
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_clearmasterkeys(self):
		"""Clears the masterkey cache"""
		try:
			self.params['masterkeys'][1] = []
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_prekey_registry(self, systemhive, securityhive, samhive):
		"""Extraces prekeys from registry hives"""
		try:
			dpapi = DPAPI()
			dpapi.get_prekeys_form_registry_files(systemhive, securityhive, samhive)
			if len(dpapi.prekeys) == 0:
				await self.print('No prekeys found!')
			for x in dpapi.prekeys:
				self.params['prekeys'][1].append(x.hex())
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_prekey_password(self, password, usersid):
		"""Generates prekeys from users password and SID"""
		try:
			dpapi = DPAPI()
			dpapi.get_prekeys_from_password(usersid, password = password)
			if len(dpapi.prekeys) == 0:
				await self.print('No prekeys could be calculated!')
			for x in dpapi.prekeys:
				self.params['prekeys'][1].append(x.hex())
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_prekey_nt(self, nthash, usersid):
		"""Generates prekeys from users NT hash and SID"""
		try:
			dpapi = DPAPI()
			dpapi.get_prekeys_from_password(usersid, nt_hash = nthash)
			if len(dpapi.prekeys) == 0:
				await self.print('No prekeys could be calculated!')
			for x in dpapi.prekeys:
				self.params['prekeys'][1].append(x.hex())
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_minidump(self, minidumpfile, outfile):
		"""Extracts all prekeys and masterkeys from LSASS minidump"""
		try:
			dpapi = DPAPI()
			dpapi.get_masterkeys_from_lsass_dump(minidumpfile)
			dpapi.dump_masterkeys(outfile)
			dpapi.dump_pre_keys(outfile + '_prekeys')
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_masterkey(self, masterkeyfile):
		"""Decrypts masterkey file using the prekey cache"""
		try:
			if len(self.params['prekeys'][1]) == 0:
				raise Exception('No prekeys in cache! Please add prekeys!')
			dpapi = DPAPI()
			for x in self.params['prekeys'][1]:
				dpapi.prekeys[bytes.fromhex(x)] = 1
			dpapi.decrypt_masterkey_file(masterkeyfile)
			if len(dpapi.masterkeys) == 0 and len(dpapi.backupkeys) == 0:
				await self.print('Failed to decrypt the masterkeyfile!')
				return
			for x in dpapi.masterkeys:
				self.params['masterkeys'][1].append('%s,%s' % (x, dpapi.masterkeys[x].hex()))
			for x in dpapi.backupkeys:
				self.params['masterkeys'][1].append('%s,%s' % (x, dpapi.backupkeys[x].hex()))

			await self.print('Found %s masterkeys!' % (len(dpapi.masterkeys) + len(dpapi.backupkeys)))

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_credential(self, credfile):
		"""Decrypts a credential file (.cred) using cached masterkeys"""
		try:
			dpapi = self.create_dpapi_masterkeys()
			cred_blob = dpapi.decrypt_credential_file(credfile)
			await self.print(cred_blob.to_text())
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_vpol(self, vpol):
		"""Decrypts a vpol file (.vpol) using cached masterkeys"""
		try:
			dpapi = self.create_dpapi_masterkeys()
			key1, key2 = dpapi.decrypt_vpol_file(vpol)

			await self.print('VPOL key1: %s' % key1.hex())
			await self.print('VPOL key2: %s' % key2.hex())
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_vcred(self, vcredfile, vpolkey):
		"""Decrypts a vcred file (.vcred) using a corresponding VPOL key (in hex)"""
		try:
			dpapi = self.create_dpapi_masterkeys()
			dpapi.vault_keys = [bytes.fromhex(vpolkey)]
			res = dpapi.decrypt_vcrd_file(vcredfile)
			for attr in res:
				for i in range(len(res[attr])):
					if res[attr][i] is not None:
						await self.print('AttributeID: %s Key %s' % (attr.id, i))
						await self.print(hexdump(res[attr][i]))
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_securestring(self, securestring):
		"""Decrypts a securestring (in hex format or file path) using cached masterkeys"""
		try:
			dpapi = self.create_dpapi_masterkeys()
			try:
				bytes.fromhex(securestring)
			except Exception as e:
				dec_sec = dpapi.decrypt_securestring_file(securestring)
			else:
				dec_sec = dpapi.decrypt_securestring_hex(securestring)
			
			await self.print('HEX: %s' % dec_sec.hex())
			try:
				await self.print('STR: %s' % dec_sec.decode('utf-16-le'))
			except:
				await self.print('STR: ')

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_blob(self, blob):
		"""Decrypts a DPAPI BLOB (in hex format or file path) using cached masterkeys"""
		try:
			dpapi = self.create_dpapi_masterkeys()
			try:
				bytes.fromhex(blob)
			except Exception as e:
				dec_sec = dpapi.decrypt_securestring_file(blob)
			else:
				dec_sec = dpapi.decrypt_securestring_hex(blob)
			
			await self.print('HEX: %s' % dec_sec.hex())
			try:
				await self.print('STR: %s' % dec_sec.decode('utf-16-le'))
			except:
				await self.print('STR: ')
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_wifi(self, wificonfig):
		"""Decrypts a wifi config file (.xml) using a previously decrypted masterkey file"""
		try:
			dpapi = self.create_dpapi_masterkeys()
			dec_config = dpapi.decrypt_wifi_config_file(wificonfig)
			await self.print(str(dec_config))
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_chrome(self, localstate, cookies = None, logindata = None):
		"""Decrypts chrome secrets using the localstate/cookies/logindata files and a previously decrypted masterkey file"""
		try:
			dpapi = self.create_dpapi_masterkeys()

			dbpaths_inner = {
				'localstate' : localstate
			}
			if cookies is not None and cookies != '':
				dbpaths_inner['cookies'] = cookies
			if logindata is not None and logindata != '':
				dbpaths_inner['logindata'] = logindata
			dbpaths = { 'user' : dbpaths_inner}
			results = dpapi.decrypt_all_chrome(dbpaths)
			
			await self.print('Decryption OK!')
			if len(results['logins']) > 0:
				await self.print('Login data:')
				for _, url, user, passw in results['logins']:
					await self.print('User: "%s" Password: "%s" URL: %s' % (user, passw.decode(), url))
			else:
				await self.print('No login data found!')
			if len(results['fmtcookies']) > 0:
				await self.print('Cookies:')
				await self.print(str(results['fmtcookies']))
				with open(create_random_file('cookies_', 'json'), 'w') as f:
					json.dump(results['fmtcookies'], f)
			else:
				await self.print('No Cookies found!')
			
		except Exception as e:
			await self.print_exc(e)
			return None, e


	
