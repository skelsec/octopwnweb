import traceback
import asyncio
import json

from octopwn.common.utils import hexdump, create_random_file
from octopwn.clients.scannerbase import ScannerConsoleBase
from pypykatz import logger
from pypykatz.dpapi.dpapi import DPAPI

logger.setLevel(100)

class DPAPIUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
	

	async def do_prekey_registry(self, systemhive, securityhive, samhive, outfile):
		"""Extraces prekeys from registry hives, output will be written to a file"""
		try:
			dpapi = DPAPI()
			dpapi.get_prekeys_form_registry_files(systemhive, securityhive, samhive)
			dpapi.dump_pre_keys(outfile)
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_prekey_password(self, password, usersid, outfile):
		"""Generates prekeys from users password and SID"""
		try:
			dpapi = DPAPI()
			dpapi.get_prekeys_from_password(usersid, password = password)
			dpapi.dump_pre_keys(outfile)
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_prekey_nt(self, nthash, usersid, outfile):
		"""Generates prekeys from users NT hash and SID"""
		try:
			dpapi = DPAPI()
			dpapi.get_prekeys_from_password(usersid, nt_hash = nthash)
			dpapi.dump_pre_keys(outfile)
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_minidump(self, minidumpfile, outfile):
		"""Extracts all prekeys and masterkeys from LSASS minidump"""
		try:
			dpapi = DPAPI()
			dpapi.get_masterkeys_from_lsass_dump(minidumpfile)
			dpapi.dump_masterkeys(outfile)
			dpapi.dump_pre_keys(outfile + '_prekeys')
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_masterkey(self, masterkeyfile, prekey, outfile):
		"""Decrypts masterkey file using a prekeys file"""
		try:
			dpapi = DPAPI()
			dpapi.load_prekeys(prekey)
			dpapi.decrypt_masterkey_file(masterkeyfile)
			if len(dpapi.masterkeys) == 0 and len(dpapi.backupkeys) == 0:
				await self.print('Failed to decrypt the masterkeyfile!')
				return
			for t in [None, outfile]:
				dpapi.dump_masterkeys(t)

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_credential(self, decmasterkey, credfile):
		"""Decrypts a credential file (.cred) using a previously decrypted masterkey file"""
		try:
			dpapi = DPAPI()
			dpapi.load_masterkeys(decmasterkey)
			cred_blob = dpapi.decrypt_credential_file(credfile)
			await self.print(cred_blob.to_text())
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_vpol(self, decmasterkey, vpol):
		"""Decrypts a vpol file (.vpol) using a previously decrypted masterkey file"""
		try:
			dpapi = DPAPI()
			dpapi.load_masterkeys(decmasterkey)
			key1, key2 = dpapi.decrypt_vpol_file(vpol)

			await self.print('VPOL key1: %s' % key1.hex())
			await self.print('VPOL key2: %s' % key2.hex())
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_vcred(self, vcredfile, vpolkey):
		"""Decrypts a vcred file (.vcred) using a corresponding VPOL key (in hex)"""
		try:
			dpapi = DPAPI()
			dpapi.vault_keys = [bytes.fromhex(vpolkey)]
			res = dpapi.decrypt_vcrd_file(vcredfile)
			for attr in res:
				for i in range(len(res[attr])):
					if res[attr][i] is not None:
						await self.print('AttributeID: %s Key %s' % (attr.id, i))
						await self.print(hexdump(res[attr][i]))
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_securestring(self, decmasterkey, securestring):
		"""Decrypts a securestring (in hex format or file path) using a previously decrypted masterkey file"""
		try:
			dpapi = DPAPI()
			dpapi.load_masterkeys(decmasterkey)
			try:
				bytes.fromhex(securestring)
			except Exception as e:
				dec_sec = dpapi.decrypt_securestring_file(securestring)
			else:
				dec_sec = dpapi.decrypt_securestring_hex(securestring)
			
			await self.print('HEX: %s' % dec_sec.hex())
			await self.print('STR: %s' % dec_sec.decode('utf-16-le'))
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_blob(self, decmasterkey, blob):
		"""Decrypts a DPAPI BLOB (in hex format or file path) using a previously decrypted masterkey file"""
		try:
			dpapi = DPAPI()
			dpapi.load_masterkeys(decmasterkey)
			try:
				bytes.fromhex(blob)
			except Exception as e:
				dec_sec = dpapi.decrypt_securestring_file(blob)
			else:
				dec_sec = dpapi.decrypt_securestring_hex(blob)
			
			await self.print('HEX: %s' % dec_sec.hex())
			await self.print('STR: %s' % dec_sec.decode('utf-16-le'))
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_wifi(self, decmasterkey, wificonfig):
		"""Decrypts a wifi config file (.xml) using a previously decrypted masterkey file"""
		try:
			dpapi = DPAPI()
			dpapi.load_masterkeys(decmasterkey)
			dec_config = dpapi.decrypt_wifi_config_file(wificonfig)
			await self.print(str(dec_config))
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_chrome(self, decmasterkey, localstate, cookies = None, logindata = None):
		"""Decrypts chrome secrets using the localstate/cookies/logindata files and a previously decrypted masterkey file"""
		try:
			dpapi = DPAPI()
			dpapi.load_masterkeys(decmasterkey)

			dbpaths_inner = {
				'localstate' : localstate
			}
			if cookies is not None and cookies != '':
				dbpaths_inner['cookies'] = cookies
			if logindata is not None and logindata != '':
				dbpaths_inner['logindata'] = logindata
			dbpaths = { 'user' : dbpaths_inner}
			results = dpapi.decrypt_all_chrome(dbpaths)

			await self.print('Login data:')
			await self.print(str(results['user']['logins']))
			await self.print('Cookies:')
			await self.print(str(results['user']['fmtcookies']))
			with open(create_random_file('cookies_', 'json'), 'w') as f:
				json.dump(f, results['user']['fmtcookies'])
			
		except Exception as e:
			await self.print_exc(e)
			return None, e


	
