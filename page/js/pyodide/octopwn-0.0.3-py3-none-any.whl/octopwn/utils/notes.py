from octopwn.clients.scannerbase import ScannerConsoleBase

class NotesUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.params = {
			'text': (str, ''),
		}

	async def do_updatetext(self, data:str, to_print = True):
		"""Saves text in the persistent store"""
		try:
			await self.do_setparam('text', data, to_print)
			return True, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_getcontent(self, to_print = True):
		"""Returns the content"""
		try:
			data = self.params['text'][1]
			if to_print is True:
				await self.print(data)
			return self.params['text'][1], None
		except Exception as e:
			await self.print_exc(e)
			return None, e