__version__ = "0.0.3"
__banner__ = \
"""
# aesedb %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__