
__version__ = "0.0.21"
__banner__ = \
"""
# minidump %s 
# Author: Tamas Jos @skelsec (skelsecprojects@gmail.com)
""" % __version__