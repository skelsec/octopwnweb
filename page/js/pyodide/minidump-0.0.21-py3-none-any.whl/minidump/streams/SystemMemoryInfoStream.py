#!/usr/bin/env python3
#
# Author:
#  Tamas Jos (@skelsec)
#
# TODO: Not documented in MSDN :(