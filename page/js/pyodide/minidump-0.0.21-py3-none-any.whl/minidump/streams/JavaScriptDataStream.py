#!/usr/bin/env python3
#
# Author:
#  Tamas Jos (@skelsec)
#
#TODO: MSDN gives no info