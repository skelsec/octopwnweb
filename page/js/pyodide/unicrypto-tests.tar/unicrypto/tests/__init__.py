import unittest
from unicrypto.tests.aestest import *
from unicrypto.tests.destest import *
from unicrypto.tests.rc4test import *
from unicrypto.tests.tdestest import *



if __name__ == '__main__':
	unittest.main()