
__version__ = "0.3.3"
__banner__ = \
"""
# jackdaw %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__