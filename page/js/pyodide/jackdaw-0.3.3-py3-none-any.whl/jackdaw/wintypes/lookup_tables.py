

OBJECTTYPE_GUID_MAP = {
    'group': 'bf967a9c-0de6-11d0-a285-00aa003049e2',
    'domain': '19195a5a-6da0-11d0-afd3-00c04fd930c9',
    'ou': 'bf967aa5-0de6-11d0-a285-00aa003049e2',
    'user': 'bf967aba-0de6-11d0-a285-00aa003049e2',
    'groupPolicyContainer': 'f30e3bc2-9ff0-11d1-b603-0000f80367c1'
}