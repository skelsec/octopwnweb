

def hexdump(data):
	print(data)