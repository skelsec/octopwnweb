


class SocksCredential:
	def __init__(self):
		self.username = None
		self.password = None