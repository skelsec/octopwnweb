from aiosmb.commons.connection.proxy import SMBProxyType, ASYSOCKS_PROXY_TYPES
from aiosmb.network.tcp import TCPSocket
from aiosmb.network.socks import SocksProxyConnection
from aiosmb.network.multiplexornetwork import MultiplexorProxyConnection
from aiosmb.commons.connection.target import SMBConnectionProtocol

class NetworkSelector:
	def __init__(self):
		pass

	@staticmethod
	async def select(target):
		if target.proxy is None:
			if target.protocol == SMBConnectionProtocol.QUIC:
				from aiosmb.network.quic import QUICSocket
				return QUICSocket(target = target), None
			else:
				return TCPSocket(target = target), None
		elif target.proxy.type in ASYSOCKS_PROXY_TYPES:
			return SocksProxyConnection(target = target), None

		elif target.proxy.type in [SMBProxyType.MULTIPLEXOR, SMBProxyType.MULTIPLEXOR_SSL]:
			mpc = MultiplexorProxyConnection(target)
			socks_proxy, err = await mpc.connect()
			return socks_proxy, err

		else:
			return None, Exception('Cant select correct connection type!')