
		
class SMBHostInfo:
	def __init__(self):
		self.sessions = []
		self.domains = []
		self.groups = []
		self.shares = []
		self.finger_info = None
		

		