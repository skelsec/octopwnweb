
__version__ = "0.3.10"
__banner__ = \
"""
# aiosmb %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__