name = "aiowinreg"
import logging

logger = logging.getLogger(name)