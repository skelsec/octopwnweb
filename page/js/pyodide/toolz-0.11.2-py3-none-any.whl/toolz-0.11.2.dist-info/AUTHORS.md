[Matthew Rocklin](http://matthewrocklin.com)    [@mrocklin](http://github.com/mrocklin/)

[John Jacobsen](http://eigenhombre.com)         [@eigenhombre](http://github.com/eigenhombre/)

Erik Welch                                      [@eriknw](https://github.com/eriknw/)

John Crichton                                   [@jcrichton](https://github.com/jcrichton/)

Han Semaj                                       [@microamp](https://github.com/microamp/)

[Graeme Coupar](https://twitter.com/obmarg)     [@obmarg](https://github.com/obmarg/)

[Leonid Shvechikov](http://brainstorage.me/shvechikov)  [@shvechikov](https://github.com/shvechikov)

Lars Buitinck                                   [@larsmans](http://github.com/larsmans)

José Ricardo                                    [@josericardo](https://github.com/josericardo)

Tom Prince                                      [@tomprince](https://github.com/tomprince)

Bart van Merriënboer                            [@bartvm](https://github.com/bartvm)

Nikolaos-Digenis Karagiannis                    [@digenis](https://github.com/digenis/)

[Antonio Lima](https://twitter.com/themiurgo)   [@themiurgo](https://github.com/themiurgo/)

Joe Jevnik                                      [@llllllllll](https://github.com/llllllllll)

Rory Kirchner                                      [@roryk](https://github.com/roryk)

[Steven Cutting](http://steven-cutting.github.io) [@steven_cutting](https://github.com/steven-cutting)

Aric Coady                                      [@coady](https://github.com/coady)
