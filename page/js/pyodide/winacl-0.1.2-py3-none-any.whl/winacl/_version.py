

__version__ = "0.1.2"
__banner__ = \
"""
# winacl %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__